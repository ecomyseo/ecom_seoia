<?php
/**
 * Plugin Name:       SEO IA Connect
 * Plugin URI:        https://gmartos.es
 * Description:       Connects your WordPress site or WooCommerce store with the SEO IA system: SEO diagnosis of all your content and AI improvements applied only where you allow it.
 * Version:           1.0.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Ecom Experts
 * Author URI:        mailto:ecomyseo@gmail.com
 * License:           AFL-3.0
 * Text Domain:       ecom_seoconnect_wp
 * Domain Path:       /languages
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

define('ECSC_VERSION', '1.0.1');
define('ECSC_FILE', __FILE__);
define('ECSC_DIR', plugin_dir_path(__FILE__));

require_once ECSC_DIR . 'includes/class-ecsc-log.php';
require_once ECSC_DIR . 'includes/class-ecsc-signer.php';
require_once ECSC_DIR . 'includes/class-ecsc-client.php';
require_once ECSC_DIR . 'includes/class-ecsc-fields.php';
require_once ECSC_DIR . 'includes/class-ecsc-catalog.php';
require_once ECSC_DIR . 'includes/class-ecsc-history.php';
require_once ECSC_DIR . 'includes/class-ecsc-applier.php';
require_once ECSC_DIR . 'includes/class-ecsc-sync.php';
require_once ECSC_DIR . 'includes/class-ecsc-front.php';
require_once ECSC_DIR . 'includes/class-ecsc-admin.php';

/**
 * Tablas del plugin. Sin ficheros de actualización: se pasa al activar y cada vez que cambia la versión.
 */
function ecsc_instalar_tablas()
{
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $c = $wpdb->get_charset_collate();
    dbDelta("CREATE TABLE {$wpdb->prefix}ecsc_queue (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        tipo varchar(20) NOT NULL,
        id_elemento bigint(20) unsigned NOT NULL,
        fecha datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY elemento (tipo,id_elemento)
    ) $c;");
    dbDelta("CREATE TABLE {$wpdb->prefix}ecsc_history (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        tipo varchar(20) NOT NULL,
        id_elemento bigint(20) unsigned NOT NULL,
        campo varchar(40) NOT NULL,
        id_sub bigint(20) unsigned NOT NULL DEFAULT 0,
        valor_anterior longtext NOT NULL,
        valor_nuevo longtext NOT NULL,
        id_propuesta bigint(20) unsigned NOT NULL DEFAULT 0,
        modo varchar(20) NOT NULL DEFAULT '',
        fecha datetime NOT NULL,
        deshecho tinyint(1) NOT NULL DEFAULT 0,
        reportado tinyint(1) NOT NULL DEFAULT 1,
        PRIMARY KEY  (id),
        KEY fecha (fecha)
    ) $c;");
    dbDelta("CREATE TABLE {$wpdb->prefix}ecsc_nonce (
        nonce varchar(64) NOT NULL,
        fecha datetime NOT NULL,
        PRIMARY KEY  (nonce)
    ) $c;");
    update_option('ecsc_db_version', ECSC_VERSION, false);
}

function ecsc_activar()
{
    ecsc_instalar_tablas();
    if (!wp_next_scheduled('ecsc_trabajo')) {
        wp_schedule_event(time() + 60, 'ecsc_5min', 'ecsc_trabajo');
    }
}
register_activation_hook(__FILE__, 'ecsc_activar');

function ecsc_desactivar()
{
    wp_clear_scheduled_hook('ecsc_trabajo');
}
register_deactivation_hook(__FILE__, 'ecsc_desactivar');

/** Intervalo de cinco minutos para la tarea del plugin. */
function ecsc_intervalos($intervalos)
{
    $lista = is_array($intervalos) ? $intervalos : array();
    $lista['ecsc_5min'] = array('interval' => 300, 'display' => __('Every 5 minutes (SEO IA Connect)', 'ecom_seoconnect_wp'));
    return $lista;
}
add_filter('cron_schedules', 'ecsc_intervalos');

function ecsc_iniciar()
{
    load_plugin_textdomain('ecom_seoconnect_wp', false, dirname(plugin_basename(ECSC_FILE)) . '/languages');
    if (get_option('ecsc_db_version') !== ECSC_VERSION) {
        ecsc_instalar_tablas();
    }
    if (!wp_next_scheduled('ecsc_trabajo')) {
        wp_schedule_event(time() + 60, 'ecsc_5min', 'ecsc_trabajo');
    }
}
add_action('init', 'ecsc_iniciar');

/** La pasada periódica: catálogo pendiente, cambios hechos en la web y mejoras aprobadas. */
function ecsc_pasada()
{
    if (Ecsc_Client::conectado()) {
        Ecsc_Sync::trabajo(25, true);
    }
}
add_action('ecsc_trabajo', 'ecsc_pasada');

Ecsc_Sync::enganchar();
Ecsc_Front::enganchar();
Ecsc_Admin::enganchar();
