{**
 * Ecom SEO Connect - ayuda plegada (acordeon cerrado, JS propio por delegacion).
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 *}
<div class="panel esc-acordeon">
    <a href="#" class="esc-acordeon-titulo"><i class="icon-question-circle"></i> {l s='Help / how it works' d='Modules.Ecomseoconnect.Admin'}</a>
    <div class="esc-acordeon-cuerpo" style="display:none">
        <h4>{l s='How it works' d='Modules.Ecomseoconnect.Admin'}</h4>
        <p>{l s='The store is the one that asks: this module never opens a door to receive data. It sends your catalog to the SEO IA system and collects the improvements you approved in the panel.' d='Modules.Ecomseoconnect.Admin'}</p>
        <h4>{l s='Permissions' d='Modules.Ecomseoconnect.Admin'}</h4>
        <ul>
            <li><strong>{l s='Blocked' d='Modules.Ecomseoconnect.Admin'}</strong>: {l s='the field is never changed.' d='Modules.Ecomseoconnect.Admin'}</li>
            <li><strong>{l s='Suggest only' d='Modules.Ecomseoconnect.Admin'}</strong>: {l s='you see the proposal in the panel but it is never applied (default).' d='Modules.Ecomseoconnect.Admin'}</li>
            <li><strong>{l s='Apply with approval' d='Modules.Ecomseoconnect.Admin'}</strong>: {l s='applied after you approve it in the panel.' d='Modules.Ecomseoconnect.Admin'}</li>
            <li><strong>{l s='Automatic' d='Modules.Ecomseoconnect.Admin'}</strong>: {l s='applied without your approval, within the daily limit, if your plan allows it.' d='Modules.Ecomseoconnect.Admin'}</li>
        </ul>
        <h4>{l s='Protections' d='Modules.Ecomseoconnect.Admin'}</h4>
        <ul>
            <li>{l s='Every request is signed and expires in 5 minutes; an unsigned answer is ignored.' d='Modules.Ecomseoconnect.Admin'}</li>
            <li>{l s='If you changed a text after the proposal was generated, the proposal is not applied (it is marked as outdated).' d='Modules.Ecomseoconnect.Admin'}</li>
            <li>{l s='The module only knows how to write SEO texts: never prices, stock, orders, customers or files.' d='Modules.Ecomseoconnect.Admin'}</li>
            <li>{l s='Every change keeps the previous value and can be undone in «History and undo».' d='Modules.Ecomseoconnect.Admin'}</li>
        </ul>
        <h4>{l s='Keeping it up to date' d='Modules.Ecomseoconnect.Admin'}</h4>
        <p>{l s='Program the cron URL of the «Synchronization» tab every 5-10 minutes. Without cron, the module works a little every time you open the back office. Once a week it resends the whole catalog.' d='Modules.Ecomseoconnect.Admin'}</p>
        <h4>{l s='Multistore' d='Modules.Ecomseoconnect.Admin'}</h4>
        <p>{l s='Each store has its own key, permissions and security settings. Choose the store in the selector before configuring.' d='Modules.Ecomseoconnect.Admin'}</p>
    </div>
</div>
