<?php
/**
 * SEO IA Connect - título y metadescripción propios en el front.
 *
 * Solo cuando NO hay Yoast SEO ni Rank Math: entonces las mejoras se guardan en metadatos del
 * plugin y es él quien las publica. Con un plugin SEO activo, esta clase no hace nada.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_Front
{
    public static function enganchar()
    {
        add_filter('pre_get_document_title', array(__CLASS__, 'titulo'), 20);
        add_action('wp_head', array(__CLASS__, 'descripcion'), 1);
    }

    /** Valor del metadato propio para lo que se está viendo, o ''. */
    private static function valor($clave)
    {
        if (Ecsc_Fields::seo() !== 'propio') {
            return '';
        }
        if (is_singular()) {
            return (string) get_post_meta((int) get_queried_object_id(), $clave, true);
        }
        if (is_category() || is_tax()) {
            return (string) get_term_meta((int) get_queried_object_id(), $clave, true);
        }
        return '';
    }

    public static function titulo($titulo)
    {
        $propio = self::valor('_ecsc_title');
        return $propio !== '' ? $propio : $titulo;
    }

    public static function descripcion()
    {
        $d = self::valor('_ecsc_description');
        if ($d !== '') {
            echo '<meta name="description" content="' . esc_attr($d) . '">' . "\n";
        }
    }
}
