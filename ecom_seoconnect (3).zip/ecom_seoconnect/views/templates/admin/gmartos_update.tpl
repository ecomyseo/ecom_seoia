{**
 * Ecom SEO Connect - aviso de version nueva.
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 *}
<div class="alert alert-warning">
    <strong>{l s='New version available' d='Modules.Ecomseoconnect.Admin'} ({$gmartos_latest_version|escape:'html':'UTF-8'})</strong>
    · {l s='Please contact support to update.' d='Modules.Ecomseoconnect.Admin'}
</div>
