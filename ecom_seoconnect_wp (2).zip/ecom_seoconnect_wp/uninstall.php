<?php
/**
 * SEO IA Connect - desinstalación limpia: opciones, tablas, tarea programada, metadatos propios y registros.
 * Los textos que el plugin haya aplicado en la web se quedan como están.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

wp_clear_scheduled_hook('ecsc_trabajo');

$ecsc_opciones = $wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'ecsc\\_%'");
foreach (is_array($ecsc_opciones) ? $ecsc_opciones : array() as $ecsc_opcion) {
    delete_option($ecsc_opcion);
}

foreach (array('ecsc_queue', 'ecsc_history', 'ecsc_nonce') as $ecsc_tabla) {
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}{$ecsc_tabla}");
}

delete_post_meta_by_key('_ecsc_title');
delete_post_meta_by_key('_ecsc_description');
$wpdb->query("DELETE FROM {$wpdb->termmeta} WHERE meta_key IN ('_ecsc_title', '_ecsc_description')");

$ecsc_subidas = wp_upload_dir(null, false);
$ecsc_dir = trailingslashit($ecsc_subidas['basedir']) . 'ecsc-logs';
if (is_dir($ecsc_dir)) {
    $ecsc_ficheros = glob($ecsc_dir . '/{,.}[!.]*', GLOB_BRACE);
    foreach (is_array($ecsc_ficheros) ? $ecsc_ficheros : array() as $ecsc_fichero) {
        @unlink($ecsc_fichero);
    }
    @rmdir($ecsc_dir);
}
