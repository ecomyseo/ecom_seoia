<?php
/**
 * Ecom SEO Connect - todo lo que habla con la plataforma: estado, envio del catalogo por tandas
 * acotadas por TIEMPO, envio de la cola y «tiron» de cambios aprobados.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscSync
{
    const LOTE = 25;

    /** Tiendas a las que la plataforma acaba de pedir, en esta misma pasada, el catalogo completo. */
    private static $relectura = array();

    private static function link()
    {
        $l = Context::getContext()->link;
        return $l instanceof Link ? $l : new Link();
    }

    public static function urlPing($idShop)
    {
        $idLang = (int) Configuration::get('PS_LANG_DEFAULT', null, null, (int) $idShop);
        return self::link()->getModuleLink('ecom_seoconnect', 'ping', array(), null, $idLang, (int) $idShop);
    }

    public static function urlCron($idShop)
    {
        $idLang = (int) Configuration::get('PS_LANG_DEFAULT', null, null, (int) $idShop);
        return self::link()->getModuleLink('ecom_seoconnect', 'cron', array('token' => Configuration::getGlobalValue('ECOMSEOCONNECT_CRON_TOKEN')), null, $idLang, (int) $idShop);
    }

    /** Lo que la plataforma recibe en cada llamada para saber como es la tienda. */
    public static function meta($idShop, $cat = null)
    {
        $cat = $cat instanceof EscCatalog ? $cat : new EscCatalog($idShop);
        return array(
            'version_ps' => _PS_VERSION_,
            'version_modulo' => Ecom_Seoconnect::VERSION,
            'id_tienda' => (int) $idShop,
            'idiomas' => array_values($cat->idiomas()),
            'config' => $cat->configTienda(),
            'permisos' => EscApplier::permisos($idShop),
            'url_ping' => self::urlPing($idShop),
        );
    }

    public static function probar($idShop)
    {
        list($ok, $d, $err) = EscClient::llamar($idShop, 'estado', self::meta($idShop), 20);
        if ($ok) {
            Configuration::updateValue('ECOMSEOCONNECT_ESTADO', json_encode(array('fecha' => date('Y-m-d H:i:s'), 'nombre' => isset($d['nombre']) ? $d['nombre'] : '',
                'nivel' => isset($d['nivel']) ? $d['nivel'] : '', 'plan' => isset($d['plan']) ? $d['plan'] : '', 'panel' => isset($d['panel']) ? $d['panel'] : '')), false, null, (int) $idShop);
        }
        if ($ok) {
            self::atenderRelectura($idShop, $d);
            self::anotarVersion($idShop, $d);
        }
        return array($ok, $d, $err);
    }

    /**
     * La plataforma pide el catalogo completo otra vez («releer» en su respuesta): el plan ya no
     * recorta los productos, o el cliente lo ha pedido en su panel. Si ya hay un envio en marcha, se deja.
     */
    private static function atenderRelectura($idShop, $d)
    {
        if (!is_array($d) || empty($d['releer'])) {
            return false;
        }
        $s = self::estadoSync($idShop);
        if (!empty($s['activo'])) {
            return false;
        }
        self::empezar($idShop);
        self::$relectura[(int) $idShop] = true;
        EscLog::escribir('La plataforma pide volver a leer el catálogo: empieza un envío completo.');
        return true;
    }

    /**
     * La plataforma dice en cada respuesta que version del modulo se descarga ahora. Se guarda para
     * avisar en la configuracion del modulo cuando la instalada es anterior (1.1.2).
     */
    private static function anotarVersion($idShop, $d)
    {
        if (!is_array($d) || !isset($d['modulo_ultima']) || !preg_match('/^\d+(\.\d+){1,3}$/', (string) $d['modulo_ultima'])) {
            return;
        }
        // Solo se enlaza una descarga que cuelgue de la plataforma con la que esta conectada la tienda.
        $descarga = isset($d['modulo_descarga']) ? (string) $d['modulo_descarga'] : '';
        $base = rtrim((string) EscClient::cfg('ECOMSEOCONNECT_URL', $idShop, ''), '/') . '/';
        if ($base === '/' || strpos($descarga, $base) !== 0) {
            $descarga = '';
        }
        foreach (array('ECOMSEOCONNECT_ULTIMA_VERSION' => (string) $d['modulo_ultima'], 'ECOMSEOCONNECT_DESCARGA' => $descarga) as $k => $v) {
            if ((string) Configuration::getGlobalValue($k) !== $v) {
                Configuration::updateGlobalValue($k, $v);
            }
        }
    }

    private static function estadoSync($idShop)
    {
        $s = json_decode((string) EscClient::cfg('ECOMSEOCONNECT_SYNC', $idShop, ''), true);
        return is_array($s) ? $s : array('activo' => 0);
    }

    private static function guardarSync($idShop, array $s)
    {
        Configuration::updateValue('ECOMSEOCONNECT_SYNC', json_encode($s), false, null, (int) $idShop);
    }

    public static function progreso($idShop)
    {
        return self::estadoSync($idShop);
    }

    /** Prepara un envio completo del catalogo (se hace por tandas en las siguientes pasadas). */
    public static function empezar($idShop)
    {
        $cat = new EscCatalog($idShop);
        $total = 0;
        foreach (EscCatalog::tipos() as $t) {
            $total += $cat->total($t);
        }
        self::guardarSync($idShop, array('activo' => 1, 'idx' => 0, 'cursor' => 0, 'inicio' => 1, 'total' => $total, 'leidos' => 0, 'empezado' => date('Y-m-d H:i:s'), 'error' => ''));
    }

    /** Envia tandas del catalogo durante como mucho $segundos. Devuelve true si ha terminado. */
    public static function enviarCatalogo($idShop, $segundos)
    {
        $s = self::estadoSync($idShop);
        if (empty($s['activo'])) {
            return true;
        }
        $fin = microtime(true) + $segundos;
        $cat = new EscCatalog($idShop);
        $tipos = EscCatalog::tipos();
        while (microtime(true) < $fin) {
            if ($s['idx'] >= count($tipos)) {
                list($ok, , $err) = EscClient::llamar($idShop, 'sync', array_merge(self::meta($idShop, $cat), array('fin' => 1, 'elementos' => array(), 'leidos' => 0)));
                if (!$ok) {
                    $s['error'] = $err;
                    break;
                }
                $s = array('activo' => 0, 'terminado' => date('Y-m-d H:i:s'), 'total' => $s['total'], 'leidos' => $s['leidos'], 'error' => '');
                Configuration::updateValue('ECOMSEOCONNECT_SEEDED', 1, false, null, (int) $idShop);
                Configuration::updateValue('ECOMSEOCONNECT_ULTIMA_COMPLETA', date('Y-m-d H:i:s'), false, null, (int) $idShop);
                break;
            }
            $tipo = $tipos[$s['idx']];
            $ids = $cat->ids($tipo, $s['cursor'], self::LOTE);
            if (!$ids) {
                $s['idx']++;
                $s['cursor'] = 0;
                continue;
            }
            $elementos = array();
            foreach ($ids as $id) {
                $e = $cat->elemento($tipo, $id);
                if ($e) {
                    $elementos[] = $e;
                }
            }
            $datos = array_merge(self::meta($idShop, $cat), array('elementos' => $elementos, 'leidos' => count($ids), 'total' => (int) $s['total']));
            if (!empty($s['inicio'])) {
                $datos['inicio'] = 1;
            }
            list($ok, , $err) = EscClient::llamar($idShop, 'sync', $datos, 60);
            if (!$ok) {
                // No se avanza el cursor: la tanda se repite en la siguiente pasada.
                $s['error'] = $err;
                break;
            }
            $s['inicio'] = 0;
            $s['error'] = '';
            // El cursor avanza por lo LEIDO (el ultimo id pedido), no por lo que se ha mandado.
            $s['cursor'] = end($ids);
            $s['leidos'] += count($ids);
        }
        self::guardarSync($idShop, $s);
        return empty($s['activo']);
    }

    /** Manda lo que hay en la cola (cambios hechos en el back-office) y avisa a IndexNow. */
    public static function enviarCola($idShop)
    {
        $filas = EscQueue::sacar($idShop, 60);
        if (!$filas) {
            return 0;
        }
        $cat = new EscCatalog($idShop);
        $elementos = array();
        $borrados = array();
        $cambiados = array();
        foreach ($filas as $f) {
            $e = $cat->elemento($f['tipo'], (int) $f['id_elemento']);
            if ($e) {
                $elementos[] = $e;
                $cambiados[] = array($f['tipo'], (int) $f['id_elemento'], $f['fecha']);
            } else {
                $borrados[] = array('tipo' => $f['tipo'], 'id' => (int) $f['id_elemento']);
            }
        }
        list($ok, , $err) = EscClient::llamar($idShop, 'sync', array_merge(self::meta($idShop, $cat), array('incremental' => 1, 'elementos' => $elementos, 'borrados' => $borrados)), 60);
        if (!$ok) {
            EscLog::escribir('Cola no enviada: ' . $err);
            return 0;
        }
        $ids = array();
        foreach ($filas as $f) {
            $ids[] = (int) $f['id_queue'];
        }
        EscQueue::quitar($ids);
        EscIndexNow::avisar($idShop, $cambiados, $cat);
        return count($filas);
    }

    /** Va a buscar los cambios aprobados, los aplica con SUS permisos e informa del resultado. */
    public static function tiron($idShop)
    {
        list($ok, $d, $err) = EscClient::llamar($idShop, 'cambios', self::meta($idShop), 30);
        if ($ok) {
            self::atenderRelectura($idShop, $d);
            self::anotarVersion($idShop, $d);
        }
        $resultados = array();
        if ($ok && !empty($d['cambios']) && is_array($d['cambios'])) {
            $resultados = EscApplier::aplicar($idShop, $d['cambios']);
        }
        $deshechos = EscHistory::pendientesDeInformar($idShop);
        foreach ($deshechos as $h) {
            $resultados[] = array('id' => (int) $h['id_propuesta'], 'estado' => 'deshecha', 'motivo' => 'deshecho_en_la_tienda');
        }
        if ($resultados) {
            list($ok2) = EscClient::llamar($idShop, 'resultado', array('resultados' => $resultados), 30);
            if ($ok2 && $deshechos) {
                $ids = array();
                foreach ($deshechos as $h) {
                    $ids[] = (int) $h['id_history'];
                }
                EscHistory::marcarInformados($ids);
            }
        }
        Configuration::updateValue('ECOMSEOCONNECT_ULTIMO_TIRON', date('Y-m-d H:i:s'), false, null, (int) $idShop);
        return $ok ? count($resultados) : -1;
    }

    /** Una pasada completa de trabajo para una tienda, con candado para no pisarse. */
    public static function trabajo($idShop, $segundos = 20, $conCatalogo = true)
    {
        $candado = 'ECOMSEOCONNECT_CANDADO';
        $ahora = time();
        if ((int) EscClient::cfg($candado, $idShop, 0) > $ahora - 90) {
            return 'ocupado';
        }
        Configuration::updateValue($candado, $ahora, false, null, (int) $idShop);
        try {
            $fin = microtime(true) + $segundos;
            if ($conCatalogo) {
                $ultima = strtotime((string) EscClient::cfg('ECOMSEOCONNECT_ULTIMA_COMPLETA', $idShop, ''));
                $s = self::estadoSync($idShop);
                if (empty($s['activo']) && (!$ultima || $ultima < $ahora - 7 * 86400)) {
                    // Primera vez o semanal: repaso completo (recoge lo que no pasa por hooks, como las leyendas en PS 8.1+).
                    self::empezar($idShop);
                }
                self::enviarCatalogo($idShop, max(3, $fin - microtime(true) - 5));
            }
            self::enviarCola($idShop);
            self::tiron($idShop);
            if (!empty(self::$relectura[(int) $idShop])) {
                // La primera tanda sale ya: lleva la marca de inicio y la plataforma da la peticion por atendida.
                self::$relectura[(int) $idShop] = false;
                self::enviarCatalogo($idShop, max(3, $fin - microtime(true) - 2));
            }
            EscLlms::semanal();
        } catch (Exception $e) {
            EscLog::error('Trabajo tienda ' . $idShop . ': ' . $e->getMessage());
        }
        Configuration::updateValue($candado, 0, false, null, (int) $idShop);
        return 'ok';
    }
}
