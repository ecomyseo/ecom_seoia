<?php
/**
 * SEO IA Connect - el contenido de la web, en el formato que espera la plataforma.
 *
 * Tipos: «cms» son las entradas y las páginas; con WooCommerce, «producto», «categoria» y «marca».
 * El formato de cada elemento (comun + idiomas) es el mismo que manda el módulo de PrestaShop.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_Catalog
{
    public static function hayTienda()
    {
        return class_exists('WooCommerce') && post_type_exists('product') && function_exists('wc_get_product');
    }

    /** Idioma de la web: un idioma por web en esta versión. */
    public static function iso()
    {
        $iso = strtolower(substr((string) get_locale(), 0, 2));
        return preg_match('/^[a-z]{2}$/', $iso) ? $iso : 'es';
    }

    public static function tiposDePost($tipo)
    {
        if ($tipo === 'cms') {
            return array('post', 'page');
        }
        return $tipo === 'producto' && self::hayTienda() ? array('product') : array();
    }

    public static function taxonomias($tipo)
    {
        $out = array();
        if ($tipo === 'categoria') {
            if (self::hayTienda() && taxonomy_exists('product_cat')) {
                $out[] = 'product_cat';
            }
            $out[] = 'category';
        } elseif ($tipo === 'marca' && self::hayTienda() && taxonomy_exists('product_brand')) {
            $out[] = 'product_brand';
        }
        return $out;
    }

    public static function tipos()
    {
        $t = array();
        foreach (array('categoria', 'marca') as $tipo) {
            if (self::taxonomias($tipo)) {
                $t[] = $tipo;
            }
        }
        if (self::hayTienda()) {
            $t[] = 'producto';
        }
        $t[] = 'cms';
        return $t;
    }

    public static function tipoDePost($postType)
    {
        if ($postType === 'post' || $postType === 'page') {
            return 'cms';
        }
        return $postType === 'product' && self::hayTienda() ? 'producto' : null;
    }

    public static function tipoDeTaxonomia($taxonomia)
    {
        foreach (array('categoria', 'marca') as $tipo) {
            if (in_array($taxonomia, self::taxonomias($tipo), true)) {
                return $tipo;
            }
        }
        return null;
    }

    private static function lista(array $valores)
    {
        return "'" . implode("','", array_map('esc_sql', $valores)) . "'";
    }

    private static function estados()
    {
        return array('publish', 'private', 'draft', 'pending', 'future');
    }

    public static function total($tipo)
    {
        global $wpdb;
        $tax = self::taxonomias($tipo);
        if ($tax) {
            return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->term_taxonomy} WHERE taxonomy IN (" . self::lista($tax) . ')');
        }
        $pt = self::tiposDePost($tipo);
        if (!$pt) {
            return 0;
        }
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type IN (" . self::lista($pt) . ') AND post_status IN (' . self::lista(self::estados()) . ')');
    }

    /** Siguientes ids de ese tipo por encima del cursor. */
    public static function ids($tipo, $cursor, $limite)
    {
        global $wpdb;
        $tax = self::taxonomias($tipo);
        if ($tax) {
            $ids = $wpdb->get_col($wpdb->prepare("SELECT term_id FROM {$wpdb->term_taxonomy} WHERE taxonomy IN (" . self::lista($tax) . ') AND term_id > %d ORDER BY term_id ASC LIMIT %d', (int) $cursor, (int) $limite));
        } else {
            $pt = self::tiposDePost($tipo);
            if (!$pt) {
                return array();
            }
            $ids = $wpdb->get_col($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_type IN (" . self::lista($pt) . ') AND post_status IN (' . self::lista(self::estados()) . ') AND ID > %d ORDER BY ID ASC LIMIT %d', (int) $cursor, (int) $limite));
        }
        return array_map('intval', is_array($ids) ? $ids : array());
    }

    /** Un elemento listo para enviar, o null si ya no existe (entonces la plataforma lo borra). */
    public static function elemento($tipo, $id)
    {
        if ($tipo === 'categoria' || $tipo === 'marca') {
            return self::termino($tipo, (int) $id);
        }
        if ($tipo === 'producto') {
            return self::producto((int) $id);
        }
        return $tipo === 'cms' ? self::entrada((int) $id) : null;
    }

    private static function noIndexar($id)
    {
        if (get_post_meta($id, '_yoast_wpseo_meta-robots-noindex', true) === '1') {
            return true;
        }
        $rm = get_post_meta($id, 'rank_math_robots', true);
        return is_array($rm) && in_array('noindex', $rm, true);
    }

    private static function entrada($id)
    {
        $p = get_post($id);
        if (!$p || !in_array($p->post_type, self::tiposDePost('cms'), true) || !in_array($p->post_status, self::estados(), true)) {
            return null;
        }
        $categoria = '';
        if ($p->post_type === 'post') {
            $cats = get_the_category($id);
            $categoria = is_array($cats) && $cats ? (string) $cats[0]->name : '';
        }
        $comun = array(
            'indexar' => self::noIndexar($id) ? 0 : 1,
            'subtipo' => $p->post_type === 'post' ? 'entrada' : 'pagina',
            'categoria' => $categoria,
            'imagenes' => has_post_thumbnail($id) ? 1 : 0,
            'constructor' => Ecsc_Fields::constructor($id) ? 1 : 0,
        );
        $l = array(
            'name' => (string) $p->post_title,
            'meta_title' => (string) Ecsc_Fields::leer('cms', 'meta_title', $id),
            'meta_description' => (string) Ecsc_Fields::leer('cms', 'meta_description', $id),
            'content' => (string) $p->post_content,
            'link_rewrite' => (string) $p->post_name,
            'url' => (string) get_permalink($id),
        );
        return array('tipo' => 'cms', 'id' => $id, 'activo' => $p->post_status === 'publish' ? 1 : 0, 'comun' => $comun, 'idiomas' => array(self::iso() => $l));
    }

    private static function producto($id)
    {
        if (!self::hayTienda()) {
            return null;
        }
        $post = get_post($id);
        $p = $post && $post->post_type === 'product' && in_array($post->post_status, self::estados(), true) ? wc_get_product($id) : null;
        if (!$p) {
            return null;
        }
        $cats = wp_get_object_terms($id, 'product_cat', array('fields' => 'all', 'orderby' => 'term_id'));
        $cat = is_array($cats) && $cats ? $cats[0] : null;
        $marca = '';
        if (taxonomy_exists('product_brand')) {
            $marcas = wp_get_object_terms($id, 'product_brand', array('fields' => 'names'));
            $marca = is_array($marcas) && $marcas ? (string) $marcas[0] : '';
        }
        $caract = array();
        foreach ($p->get_attributes() as $atributo) {
            if (!is_object($atributo) || !method_exists($atributo, 'get_name')) {
                continue;
            }
            $nombre = wc_attribute_label($atributo->get_name());
            $valores = $atributo->is_taxonomy() ? wc_get_product_terms($id, $atributo->get_name(), array('fields' => 'names')) : $atributo->get_options();
            $caract[] = $nombre . ': ' . implode(', ', is_array($valores) ? array_map('strval', $valores) : array());
            if (count($caract) >= 30) {
                break;
            }
        }
        $imagenes = Ecsc_Fields::imagenes($id);
        $visibilidad = array('visible' => 'both', 'catalog' => 'catalog', 'search' => 'search', 'hidden' => 'none');
        $v = (string) $p->get_catalog_visibility();
        $cantidad = $p->get_stock_quantity();
        $comun = array(
            'marca' => $marca,
            'categoria' => $cat ? (string) $cat->name : '',
            'referencia' => (string) $p->get_sku(),
            'ean13' => method_exists($p, 'get_global_unique_id') ? (string) $p->get_global_unique_id() : '',
            'upc' => '',
            'isbn' => '',
            'mpn' => '',
            'precio' => round((float) $p->get_price(), 2),
            'stock' => $cantidad === null ? ($p->is_in_stock() ? 1 : 0) : (int) $cantidad,
            'pedir_sin_stock' => (bool) $p->backorders_allowed(),
            'visibilidad' => isset($visibilidad[$v]) ? $visibilidad[$v] : 'both',
            'redirect_type' => '',
            'id_type_redirected' => 0,
            'id_categoria' => $cat ? (int) $cat->term_id : 0,
            'condicion' => 'new',
            'peso' => (float) $p->get_weight() > 0 ? (float) $p->get_weight() : '',
            'imagenes' => count($imagenes),
            'caracteristicas' => count($caract),
            'caracteristicas_texto' => implode('; ', $caract),
        );
        $leyendas = array();
        foreach ($imagenes as $idImagen) {
            $leyendas[(string) $idImagen] = (string) get_post_meta($idImagen, '_wp_attachment_image_alt', true);
        }
        $l = array(
            'name' => (string) $post->post_title,
            'meta_title' => (string) Ecsc_Fields::leer('producto', 'meta_title', $id),
            'meta_description' => (string) Ecsc_Fields::leer('producto', 'meta_description', $id),
            'description_short' => (string) $post->post_excerpt,
            'description' => (string) $post->post_content,
            'link_rewrite' => (string) $post->post_name,
            'tags' => Ecsc_Fields::etiquetas($id),
            'leyendas' => $leyendas,
            'url' => (string) get_permalink($id),
        );
        return array('tipo' => 'producto', 'id' => $id, 'activo' => $post->post_status === 'publish' ? 1 : 0, 'comun' => $comun, 'idiomas' => array(self::iso() => $l));
    }

    private static function termino($tipo, $id)
    {
        $t = get_term($id);
        if (!$t || is_wp_error($t) || !in_array($t->taxonomy, self::taxonomias($tipo), true)) {
            return null;
        }
        $ejemplos = array();
        if ($tipo === 'categoria') {
            $posts = get_posts(array('post_type' => $t->taxonomy === 'product_cat' ? 'product' : 'post', 'post_status' => 'publish', 'numberposts' => 10, 'fields' => 'ids',
                'tax_query' => array(array('taxonomy' => $t->taxonomy, 'terms' => array((int) $t->term_id))), 'suppress_filters' => true));
            foreach (is_array($posts) ? $posts : array() as $idPost) {
                $ejemplos[] = (string) get_the_title($idPost);
            }
        }
        $enlace = get_term_link($t);
        $l = array(
            'name' => (string) $t->name,
            'meta_title' => (string) Ecsc_Fields::leer($tipo, 'meta_title', $id),
            'meta_description' => (string) Ecsc_Fields::leer($tipo, 'meta_description', $id),
            'description' => (string) $t->description,
            'link_rewrite' => (string) $t->slug,
            'productos_ejemplo' => $ejemplos,
            'url' => is_wp_error($enlace) ? '' : (string) $enlace,
        );
        return array('tipo' => $tipo, 'id' => (int) $t->term_id, 'activo' => 1, 'comun' => array('productos' => (int) $t->count, 'es_raiz' => 0, 'id_padre' => (int) $t->parent, 'taxonomia' => $t->taxonomy), 'idiomas' => array(self::iso() => $l));
    }

    /** Lo que la plataforma necesita saber de la web para sus reglas «de tienda». */
    public static function config()
    {
        $publica = (int) get_option('blog_public', 1) === 1;
        $mapas = function_exists('wp_sitemaps_get_server') && $publica && (bool) apply_filters('wp_sitemaps_enabled', true);
        return array(
            'friendly_url' => (string) get_option('permalink_structure', '') !== '',
            'ssl_everywhere' => strpos((string) home_url('/'), 'https://') === 0,
            'canonical_redirect' => 2,
            'shop_enabled' => true,
            'sitemap' => $mapas || defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION'),
            'robots' => true,
            'llms' => is_file(ABSPATH . 'llms.txt'),
            'smarty_cache' => true,
            'idioma_defecto' => self::iso(),
            'redirect_defecto' => '404',
            'url_producto_segura' => false,
            'url_categoria_segura' => false,
            'indexnow' => false,
            'nombre_tienda' => (string) get_bloginfo('name'),
            'hreflang_tema' => true,
            'xdefault' => true,
            'jsonld_tema' => self::hayTienda() ? array('Product') : array(),
            'jsonld_producto' => true,
            'robots_bloquea_todo' => !$publica,
            'robots_sitemap' => true,
            'gestor' => self::hayTienda() ? 'woocommerce' : 'wordpress',
            'version_woocommerce' => self::hayTienda() && defined('WC_VERSION') ? WC_VERSION : '',
            'seo' => Ecsc_Fields::seo(),
        );
    }
}
