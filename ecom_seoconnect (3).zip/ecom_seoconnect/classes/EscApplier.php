<?php
/**
 * Ecom SEO Connect - aplica los cambios aprobados que la tienda ha ido a buscar.
 * El orden de las comprobaciones es la seguridad del modulo:
 *   interruptor -> campo de la lista cerrada -> permiso del campo EN LA TIENDA -> URL segura
 *   -> tope diario -> valor actual (huella) -> validacion del nucleo -> escribir -> historial
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscApplier
{
    public static function modos()
    {
        return array('blocked', 'suggest', 'approve', 'auto');
    }

    /** Permisos por campo de UNA tienda. Por defecto «suggest»; link_rewrite, «blocked». */
    public static function permisos($idShop)
    {
        $p = json_decode((string) EscClient::cfg('ECOMSEOCONNECT_PERMS', $idShop, ''), true);
        $p = is_array($p) ? $p : array();
        $out = array();
        foreach (EscFields::mapa() as $tipo => $campos) {
            foreach (array_keys($campos) as $campo) {
                $k = $tipo . '.' . $campo;
                $defecto = $campo === 'link_rewrite' ? 'blocked' : 'suggest';
                $out[$k] = isset($p[$k]) && in_array($p[$k], self::modos(), true) ? $p[$k] : $defecto;
                if ($campo === 'link_rewrite' && !EscFields::urlSegura($tipo, $idShop)) {
                    $out[$k] = 'blocked';
                }
            }
        }
        return $out;
    }

    public static function aplicadosHoy($idShop)
    {
        return (int) Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'ecomseoconnect_history` WHERE `id_shop` = ' . (int) $idShop
            . ' AND `fecha` >= \'' . pSQL(date('Y-m-d 00:00:00')) . '\'');
    }

    /**
     * Aplica una lista de cambios. Devuelve los resultados para la plataforma.
     * Los que no caben en el tope diario NO devuelven resultado: la plataforma los reenviara.
     */
    public static function aplicar($idShop, array $cambios)
    {
        $res = array();
        $tocados = array();
        $kill = (int) EscClient::cfg('ECOMSEOCONNECT_KILL', $idShop, 0) === 1;
        $perm = self::permisos($idShop);
        $tope = max(0, (int) EscClient::cfg('ECOMSEOCONNECT_DAILY_CAP', $idShop, 50));
        $hoy = self::aplicadosHoy($idShop);
        foreach ($cambios as $c) {
            if (!is_array($c) || empty($c['id'])) {
                continue;
            }
            $id = (int) $c['id'];
            $tipo = isset($c['tipo']) ? (string) $c['tipo'] : '';
            $campo = isset($c['campo']) ? (string) $c['campo'] : '';
            if ($kill) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'parada_total_activa');
                continue;
            }
            if (!EscFields::existe($tipo, $campo)) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'campo_no_permitido');
                EscLog::error('Cambio #' . $id . ' con campo fuera de la lista: ' . $tipo . '.' . $campo);
                continue;
            }
            $modo = $perm[$tipo . '.' . $campo];
            if ($modo !== 'approve' && $modo !== 'auto') {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'permiso_' . $modo);
                continue;
            }
            if ($tope > 0 && $hoy >= $tope) {
                EscLog::escribir('Tope diario alcanzado (' . $tope . '): el resto espera a mañana');
                break;
            }
            $idLang = (int) Language::getIdByIso(isset($c['iso']) ? (string) $c['iso'] : '');
            $idEl = isset($c['id_elemento']) ? (int) $c['id_elemento'] : 0;
            $idSub = isset($c['id_sub']) && $c['id_sub'] !== null ? (int) $c['id_sub'] : null;
            $valor = isset($c['valor']) && is_string($c['valor']) ? $c['valor'] : null;
            if (!$idLang || !$idEl || $valor === null) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'datos_incompletos');
                continue;
            }
            $actual = EscFields::leer($tipo, $campo, $idEl, $idLang, $idShop, $idSub);
            if ($actual === null) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'no_existe');
                continue;
            }
            if ($actual === $valor) {
                $res[] = array('id' => $id, 'estado' => 'aplicada', 'motivo' => 'ya_estaba');
                continue;
            }
            if (!isset($c['hash_anterior']) || !hash_equals((string) $c['hash_anterior'], sha1($actual))) {
                // El texto ha cambiado desde que se genero la propuesta: no se pisa el trabajo del comerciante.
                $res[] = array('id' => $id, 'estado' => 'desfasada', 'motivo' => 'el_valor_ha_cambiado');
                continue;
            }
            $err = EscFields::validar($tipo, $campo, $valor);
            if ($err !== '') {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'validacion_' . $err);
                continue;
            }
            if (!EscFields::escribir($tipo, $campo, $idEl, $idLang, $idShop, $valor, $idSub)) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'error_al_guardar');
                continue;
            }
            Db::getInstance()->insert('ecomseoconnect_history', array(
                'id_shop' => (int) $idShop,
                'tipo' => pSQL($tipo),
                'id_elemento' => $idEl,
                'campo' => pSQL($campo),
                'id_sub' => $idSub === null ? 0 : $idSub,
                'id_lang' => $idLang,
                'valor_anterior' => pSQL($actual, true),
                'valor_nuevo' => pSQL($valor, true),
                'id_propuesta' => $id,
                'modo' => pSQL($modo),
                'fecha' => date('Y-m-d H:i:s'),
                'deshecho' => 0,
                'reportado' => 1,
            ));
            $hoy++;
            $tocados[$tipo . '|' . $idEl] = array($tipo, $idEl);
            $res[] = array('id' => $id, 'estado' => 'aplicada', 'motivo' => $modo === 'auto' ? 'automatico' : 'aprobada');
            EscLog::escribir('Aplicado #' . $id . ' ' . $tipo . ' ' . $idEl . ' ' . $campo . ' (' . $idLang . ')');
        }
        foreach ($tocados as $t) {
            EscFields::avisarNucleo($t[0], $t[1]);
        }
        if ($tocados) {
            Tools::clearSmartyCache();
        }
        return $res;
    }
}
