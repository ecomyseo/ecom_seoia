{**
 * Ecom SEO Connect - historial de cambios con deshacer.
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 *}
{if $esc_multitienda_sin_tienda}
    <div class="alert alert-warning">{l s='Each store connects separately: choose a store in the store selector at the top.' d='Modules.Ecomseoconnect.Admin'}</div>
{else}
<div class="panel">
    <h3><i class="icon-cloud"></i> {l s='Connection' d='Modules.Ecomseoconnect.Admin'}</h3>
    {if $esc_conectado}
        <p>{l s='Connected to' d='Modules.Ecomseoconnect.Admin'} <strong>{$esc_url|escape:'html':'UTF-8'}</strong>{if $esc_estado.plan|default:''} · {l s='plan' d='Modules.Ecomseoconnect.Admin'} {$esc_estado.plan|escape:'html':'UTF-8'}{/if}</p>
        <p>{l s='Applied today' d='Modules.Ecomseoconnect.Admin'}: <strong>{$esc_hoy|intval}</strong> / {if $esc_tope}{$esc_tope|intval}{else}∞{/if}
            · {l s='Changes waiting to be sent' d='Modules.Ecomseoconnect.Admin'}: {$esc_cola|intval}
            · {l s='Last fetch' d='Modules.Ecomseoconnect.Admin'}: {$esc_tiron|escape:'html':'UTF-8'}</p>
        <form method="post" action="{$esc_accion|escape:'html':'UTF-8'}" class="form-inline">
            <button type="submit" name="submitEscTrabajar" class="btn btn-primary"><i class="icon-refresh"></i> {l s='Sync now' d='Modules.Ecomseoconnect.Admin'}</button>
            <a class="btn btn-default" href="{$esc_config|escape:'html':'UTF-8'}"><i class="icon-cogs"></i> {l s='Configuration and permissions' d='Modules.Ecomseoconnect.Admin'}</a>
        </form>
        <p class="help-block">{l s='Sends pending changes and collects the improvements approved in the panel.' d='Modules.Ecomseoconnect.Admin'}</p>
    {else}
        <p>{l s='Not connected yet.' d='Modules.Ecomseoconnect.Admin'} <a href="{$esc_config|escape:'html':'UTF-8'}">{l s='Configure' d='Modules.Ecomseoconnect.Admin'}</a></p>
    {/if}
</div>

<div class="panel">
    <h3><i class="icon-time"></i> {l s='History of applied changes' d='Modules.Ecomseoconnect.Admin'} <span class="badge">{$esc_total|intval}</span></h3>
    <form method="post" action="{$esc_accion|escape:'html':'UTF-8'}" class="esc-confirmar-form">
        <button type="submit" name="submitEscDeshacerHoy" class="btn btn-default"><i class="icon-undo"></i> {l s='Undo everything applied today' d='Modules.Ecomseoconnect.Admin'}</button>
    </form>
    <div class="table-responsive">
    <table class="table">
        <thead><tr>
            <th>{l s='Date' d='Modules.Ecomseoconnect.Admin'}</th>
            <th>{l s='Element' d='Modules.Ecomseoconnect.Admin'}</th>
            <th>{l s='Field' d='Modules.Ecomseoconnect.Admin'}</th>
            <th>{l s='Before' d='Modules.Ecomseoconnect.Admin'}</th>
            <th>{l s='After' d='Modules.Ecomseoconnect.Admin'}</th>
            <th>{l s='Mode' d='Modules.Ecomseoconnect.Admin'}</th>
            <th></th>
        </tr></thead>
        <tbody>
        {foreach from=$esc_historial item=h}
            <tr{if $h.deshecho} class="esc-deshecho"{/if}>
                <td>{$h.fecha|escape:'html':'UTF-8'}</td>
                <td>{$h.tipo|escape:'html':'UTF-8'} #{$h.id_elemento|intval}</td>
                <td>{$h.campo|escape:'html':'UTF-8'}{if $h.id_sub} #{$h.id_sub|intval}{/if} ({$h.iso_code|escape:'html':'UTF-8'})</td>
                <td class="esc-texto">{$h.antes|escape:'html':'UTF-8'}</td>
                <td class="esc-texto">{$h.despues|escape:'html':'UTF-8'}</td>
                <td>{$h.modo|escape:'html':'UTF-8'}</td>
                <td class="text-right">
                    {if $h.deshecho}
                        <span class="label label-default">{l s='Undone' d='Modules.Ecomseoconnect.Admin'}</span>
                    {else}
                        <form method="post" action="{$esc_accion|escape:'html':'UTF-8'}" class="esc-confirmar-form">
                            <input type="hidden" name="id_history" value="{$h.id_history|intval}">
                            <button type="submit" name="submitEscDeshacer" class="btn btn-default btn-xs"><i class="icon-undo"></i> {l s='Undo' d='Modules.Ecomseoconnect.Admin'}</button>
                        </form>
                    {/if}
                </td>
            </tr>
        {foreachelse}
            <tr><td colspan="7">{l s='No change has been applied yet.' d='Modules.Ecomseoconnect.Admin'}</td></tr>
        {/foreach}
        </tbody>
    </table>
    </div>
    {if $esc_paginas > 1}
        <ul class="pagination">
            {for $i=1 to $esc_paginas}
                <li{if $i == $esc_pagina} class="active"{/if}><a href="{$esc_accion|escape:'html':'UTF-8'}&amp;p={$i|intval}">{$i|intval}</a></li>
            {/for}
        </ul>
    {/if}
</div>

<div class="panel esc-acordeon">
    <a href="#" class="esc-acordeon-titulo"><i class="icon-file-text"></i> {l s='Module log' d='Modules.Ecomseoconnect.Admin'}</a>
    <div class="esc-acordeon-cuerpo" style="display:none">
        <pre class="esc-log">{foreach from=$esc_log item=l}{$l|escape:'html':'UTF-8'}
{foreachelse}{l s='Empty. Turn on the debug log in Security to see more detail.' d='Modules.Ecomseoconnect.Admin'}{/foreach}</pre>
    </div>
</div>
{/if}
