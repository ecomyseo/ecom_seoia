<?php
/**
 * Ecom SEO Connect - conecta la tienda con el Sistema SEO IA.
 *
 * La tienda es la que pregunta: el modulo no abre ninguna puerta que reciba datos. Los cambios
 * aprobados solo se aplican si el campo lo permite AQUI, en la tienda.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/classes/EscLog.php';
require_once dirname(__FILE__) . '/classes/EscSigner.php';
require_once dirname(__FILE__) . '/classes/EscClient.php';
require_once dirname(__FILE__) . '/classes/EscFields.php';
require_once dirname(__FILE__) . '/classes/EscCatalog.php';
require_once dirname(__FILE__) . '/classes/EscQueue.php';
require_once dirname(__FILE__) . '/classes/EscApplier.php';
require_once dirname(__FILE__) . '/classes/EscHistory.php';
require_once dirname(__FILE__) . '/classes/EscIndexNow.php';
require_once dirname(__FILE__) . '/classes/EscSync.php';
require_once dirname(__FILE__) . '/classes/EscFront.php';
require_once dirname(__FILE__) . '/classes/EscLlms.php';

class Ecom_Seoconnect extends Module
{
    const VERSION = '1.1.4';
    const DOMINIO = 'Modules.Ecomseoconnect.Admin';

    private $escHooks = array(
        'actionProductAdd', 'actionProductUpdate', 'actionProductDelete',
        'actionCategoryAdd', 'actionCategoryUpdate', 'actionCategoryDelete',
        'actionObjectManufacturerAddAfter', 'actionObjectManufacturerUpdateAfter', 'actionObjectManufacturerDeleteAfter',
        'actionObjectCMSAddAfter', 'actionObjectCMSUpdateAfter', 'actionObjectCMSDeleteAfter',
        'actionObjectImageAddAfter', 'actionObjectImageUpdateAfter', 'actionObjectImageDeleteAfter',
        'actionAdminControllerSetMedia', 'displayHeader',
    );

    public function __construct()
    {
        $this->name = 'ecom_seoconnect';
        $this->tab = 'seo';
        $this->version = self::VERSION;
        $this->author = 'Ecom Experts';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = array('min' => '1.7.8', 'max' => _PS_VERSION_);
        parent::__construct();
        $this->displayName = $this->trans('SEO IA Connect', array(), 'Modules.Ecomseoconnect.Admin');
        $this->description = $this->trans('Connects your store with the SEO IA system: SEO diagnosis of the whole catalog and AI improvements applied only where you allow it.', array(), 'Modules.Ecomseoconnect.Admin');
        $this->confirmUninstall = $this->trans('The applied changes stay as they are. Do you want to uninstall?', array(), 'Modules.Ecomseoconnect.Admin');
    }

    public function isUsingNewTranslationSystem()
    {
        return true;
    }

    /** Module::trans() es protected: se abre para las clases y el controlador del modulo. */
    public function trans($id, array $parameters = array(), $domain = null, $locale = null)
    {
        return parent::trans($id, $parameters, $domain, $locale);
    }

    /* ======================= Instalacion ======================= */

    public function install()
    {
        if (!parent::install()) {
            return false;
        }
        $this->addnewfeatures();
        Configuration::updateValue('GMARTOS_LAST_PING_' . $this->name, 0);
        $this->checkGmartosUpdate();
        return true;
    }

    public function uninstall()
    {
        EscIndexNow::borrarFicheros();
        EscLlms::borrar();
        foreach (array('queue', 'history', 'nonce', 'indexnow') as $t) {
            Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ecomseoconnect_' . $t . '`');
        }
        $claves = Db::getInstance()->executeS('SELECT DISTINCT `name` FROM `' . _DB_PREFIX_ . 'configuration` WHERE `name` LIKE \'ECOMSEOCONNECT\\_%\'');
        foreach (is_array($claves) ? $claves : array() as $c) {
            Configuration::deleteByName($c['name']);
        }
        Configuration::deleteByName('GMARTOS_LAST_PING_' . $this->name);
        Configuration::deleteByName('GMARTOS_UPDATE_AVAILABLE_' . $this->name);
        Configuration::deleteByName('GMARTOS_LATEST_VERSION_' . $this->name);
        $idTab = (int) Db::getInstance()->getValue('SELECT `id_tab` FROM `' . _DB_PREFIX_ . 'tab` WHERE `class_name` = \'AdminEcomSeoconnect\'');
        if ($idTab) {
            $tab = new Tab($idTab);
            $tab->delete();
        }
        return parent::uninstall();
    }

    /** Migraciones y reparaciones: tablas, hooks, pestaña y valores por defecto. Idempotente. */
    public function addnewfeatures()
    {
        try {
            $db = Db::getInstance();
            $motor = defined('_MYSQL_ENGINE_') ? _MYSQL_ENGINE_ : 'InnoDB';
            $db->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ecomseoconnect_queue` (
                `id_queue` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_shop` INT UNSIGNED NOT NULL,
                `tipo` VARCHAR(20) NOT NULL,
                `id_elemento` INT UNSIGNED NOT NULL,
                `fecha` DATETIME NOT NULL,
                PRIMARY KEY (`id_queue`),
                UNIQUE KEY `elemento` (`id_shop`, `tipo`, `id_elemento`)
            ) ENGINE=' . $motor . ' DEFAULT CHARSET=utf8mb4');
            $db->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ecomseoconnect_history` (
                `id_history` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_shop` INT UNSIGNED NOT NULL,
                `tipo` VARCHAR(20) NOT NULL,
                `id_elemento` INT UNSIGNED NOT NULL,
                `campo` VARCHAR(40) NOT NULL,
                `id_sub` INT UNSIGNED NOT NULL DEFAULT 0,
                `id_lang` INT UNSIGNED NOT NULL,
                `valor_anterior` MEDIUMTEXT NULL,
                `valor_nuevo` MEDIUMTEXT NULL,
                `id_propuesta` INT UNSIGNED NOT NULL DEFAULT 0,
                `modo` VARCHAR(10) NOT NULL DEFAULT \'\',
                `fecha` DATETIME NOT NULL,
                `deshecho` TINYINT(1) NOT NULL DEFAULT 0,
                `reportado` TINYINT(1) NOT NULL DEFAULT 1,
                PRIMARY KEY (`id_history`),
                KEY `tienda_fecha` (`id_shop`, `fecha`)
            ) ENGINE=' . $motor . ' DEFAULT CHARSET=utf8mb4');
            $db->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ecomseoconnect_nonce` (
                `nonce` VARCHAR(64) NOT NULL,
                `fecha` DATETIME NOT NULL,
                PRIMARY KEY (`nonce`),
                KEY `fecha` (`fecha`)
            ) ENGINE=' . $motor . ' DEFAULT CHARSET=utf8mb4');
            $db->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ecomseoconnect_indexnow` (
                `id_shop` INT UNSIGNED NOT NULL,
                `url_hash` CHAR(40) NOT NULL,
                `fecha` DATETIME NOT NULL,
                PRIMARY KEY (`id_shop`, `url_hash`)
            ) ENGINE=' . $motor . ' DEFAULT CHARSET=utf8mb4');
            foreach ($this->escHooks as $h) {
                if (!$this->isRegisteredInHook($h)) {
                    $this->registerHook($h);
                }
            }
            $this->instalarPestana();
            if (!Configuration::getGlobalValue('ECOMSEOCONNECT_CRON_TOKEN')) {
                Configuration::updateGlobalValue('ECOMSEOCONNECT_CRON_TOKEN', bin2hex(random_bytes(16)));
            }
            $db->execute('DELETE FROM `' . _DB_PREFIX_ . 'ecomseoconnect_nonce` WHERE `fecha` < \'' . pSQL(date('Y-m-d H:i:s', time() - 900)) . '\'');
        } catch (Exception $e) {
            EscLog::error('addnewfeatures: ' . $e->getMessage());
        }
    }

    private function instalarPestana()
    {
        $db = Db::getInstance();
        // Sin Tab::getIdFromClassName: en PS 9 lanza NonUniqueResult si hay pestañas duplicadas.
        $ids = $db->executeS('SELECT `id_tab` FROM `' . _DB_PREFIX_ . 'tab` WHERE `class_name` = \'AdminEcomSeoconnect\' ORDER BY `id_tab`');
        $ids = is_array($ids) ? $ids : array();
        if (count($ids) > 1) {
            foreach (array_slice($ids, 1) as $f) {
                $t = new Tab((int) $f['id_tab']);
                $t->delete();
            }
        }
        if ($ids) {
            return;
        }
        $padre = (int) $db->getValue('SELECT `id_tab` FROM `' . _DB_PREFIX_ . 'tab` WHERE `class_name` = \'AdminCatalog\' ORDER BY `id_tab`');
        $tab = new Tab();
        $tab->class_name = 'AdminEcomSeoconnect';
        $tab->module = $this->name;
        $tab->id_parent = $padre;
        $tab->active = 1;
        foreach (Language::getLanguages(false) as $l) {
            $tab->name[(int) $l['id_lang']] = 'SEO IA';
        }
        $tab->add();
    }

    /* ======================= Hooks: SOLO encolan ======================= */

    public function hookActionProductAdd(array $params)
    {
        EscQueue::poner('producto', isset($params['id_product']) ? $params['id_product'] : 0);
    }

    public function hookActionProductUpdate(array $params)
    {
        EscQueue::poner('producto', isset($params['id_product']) ? $params['id_product'] : 0);
    }

    public function hookActionProductDelete(array $params)
    {
        EscQueue::poner('producto', isset($params['id_product']) ? $params['id_product'] : 0);
    }

    private function idDeObjeto(array $params, $clave)
    {
        if (isset($params[$clave]) && is_object($params[$clave]) && isset($params[$clave]->id)) {
            return (int) $params[$clave]->id;
        }
        return 0;
    }

    public function hookActionCategoryAdd(array $params)
    {
        EscQueue::poner('categoria', $this->idDeObjeto($params, 'category'));
    }

    public function hookActionCategoryUpdate(array $params)
    {
        EscQueue::poner('categoria', $this->idDeObjeto($params, 'category'));
    }

    public function hookActionCategoryDelete(array $params)
    {
        EscQueue::poner('categoria', $this->idDeObjeto($params, 'category'));
    }

    public function hookActionObjectManufacturerAddAfter(array $params)
    {
        EscQueue::poner('marca', $this->idDeObjeto($params, 'object'));
    }

    public function hookActionObjectManufacturerUpdateAfter(array $params)
    {
        EscQueue::poner('marca', $this->idDeObjeto($params, 'object'));
    }

    public function hookActionObjectManufacturerDeleteAfter(array $params)
    {
        EscQueue::poner('marca', $this->idDeObjeto($params, 'object'));
    }

    public function hookActionObjectCMSAddAfter(array $params)
    {
        EscQueue::poner('cms', $this->idDeObjeto($params, 'object'));
    }

    public function hookActionObjectCMSUpdateAfter(array $params)
    {
        EscQueue::poner('cms', $this->idDeObjeto($params, 'object'));
    }

    public function hookActionObjectCMSDeleteAfter(array $params)
    {
        EscQueue::poner('cms', $this->idDeObjeto($params, 'object'));
    }

    private function imagenAProducto(array $params)
    {
        if (isset($params['object']) && is_object($params['object']) && isset($params['object']->id_product)) {
            EscQueue::poner('producto', (int) $params['object']->id_product);
        }
    }

    public function hookActionObjectImageAddAfter(array $params)
    {
        $this->imagenAProducto($params);
    }

    public function hookActionObjectImageUpdateAfter(array $params)
    {
        $this->imagenAProducto($params);
    }

    public function hookActionObjectImageDeleteAfter(array $params)
    {
        $this->imagenAProducto($params);
    }

    /**
     * CSS/JS de las pantallas del modulo y, como ultimo recurso sin cron, una pasada corta
     * (cola + cambios aprobados) como mucho cada 5 minutos por tienda.
     */
    public function hookActionAdminControllerSetMedia(array $params)
    {
        $c = $this->context->controller;
        $clase = is_object($c) ? get_class($c) : '';
        if ($clase === 'AdminEcomSeoconnectController' || ($clase === 'AdminModulesController' && Tools::getValue('configure') === $this->name)) {
            $c->addCSS($this->_path . 'views/css/admin.css');
            $c->addJS($this->_path . 'views/js/admin.js');
            Media::addJsDef(array('escTextos' => array(
                'confirmar' => $this->trans('Are you sure?', array(), 'Modules.Ecomseoconnect.Admin'),
            )));
        }
        if (Tools::getValue('ajax') || Tools::isSubmit('submitEscGuardar')) {
            return;
        }
        foreach (EscQueue::tiendasConectadas() as $idShop) {
            $ult = (int) EscClient::cfg('ECOMSEOCONNECT_ULTIMA_PASADA', $idShop, 0);
            if ($ult < time() - 300) {
                Configuration::updateValue('ECOMSEOCONNECT_ULTIMA_PASADA', time(), false, null, (int) $idShop);
                EscSync::trabajo($idShop, 4, false);
            }
        }
    }

    /**
     * Front: hreflang x-default y datos estructurados que el tema no trae (especificaciones 007 y 008).
     * Todo apagado por defecto: si no se enciende nada, no se pinta nada.
     */
    public function hookDisplayHeader(array $params)
    {
        return EscFront::cabecera($this->context);
    }

    /* ======================= Configuracion ======================= */

    private function idShopActual()
    {
        return (int) $this->context->shop->id;
    }

    private function campos()
    {
        $etq = array(
            'meta_title' => $this->trans('SEO title', array(), 'Modules.Ecomseoconnect.Admin'),
            'meta_description' => $this->trans('Meta description', array(), 'Modules.Ecomseoconnect.Admin'),
            'name' => $this->trans('Product name', array(), 'Modules.Ecomseoconnect.Admin'),
            'description_short' => $this->trans('Short description', array(), 'Modules.Ecomseoconnect.Admin'),
            'description' => $this->trans('Description', array(), 'Modules.Ecomseoconnect.Admin'),
            'link_rewrite' => $this->trans('Friendly URL', array(), 'Modules.Ecomseoconnect.Admin'),
            'legend' => $this->trans('Image alt text', array(), 'Modules.Ecomseoconnect.Admin'),
            'tags' => $this->trans('Tags', array(), 'Modules.Ecomseoconnect.Admin'),
            'short_description' => $this->trans('Short description', array(), 'Modules.Ecomseoconnect.Admin'),
            'content' => $this->trans('Page content', array(), 'Modules.Ecomseoconnect.Admin'),
            'redirect' => $this->trans('Redirect of a disabled product (301)', array(), 'Modules.Ecomseoconnect.Admin'),
        );
        $tipos = array(
            'producto' => $this->trans('Products', array(), 'Modules.Ecomseoconnect.Admin'),
            'categoria' => $this->trans('Categories', array(), 'Modules.Ecomseoconnect.Admin'),
            'marca' => $this->trans('Brands', array(), 'Modules.Ecomseoconnect.Admin'),
            'cms' => $this->trans('CMS pages', array(), 'Modules.Ecomseoconnect.Admin'),
        );
        return array($etq, $tipos);
    }

    public function getContent()
    {
        $this->addnewfeatures();
        $salida = '';
        if ($this->checkGmartosUpdate()) {
            $this->context->smarty->assign(array('gmartos_latest_version' => Configuration::get('GMARTOS_LATEST_VERSION_' . $this->name)));
            $salida .= $this->display(__FILE__, 'views/templates/admin/gmartos_update.tpl');
        }
        // La plataforma dice que version se descarga ahora: si la instalada es anterior, se avisa aqui.
        $ultima = (string) Configuration::getGlobalValue('ECOMSEOCONNECT_ULTIMA_VERSION');
        if ($ultima !== '' && version_compare($ultima, self::VERSION, '>')) {
            $this->context->smarty->assign(array('esc_version_nueva' => $ultima, 'esc_version_actual' => self::VERSION,
                'esc_descarga' => (string) Configuration::getGlobalValue('ECOMSEOCONNECT_DESCARGA')));
            $salida .= $this->display(__FILE__, 'views/templates/admin/version_nueva.tpl');
        }
        if (Shop::isFeatureActive() && Shop::getContext() !== Shop::CONTEXT_SHOP) {
            return $salida . $this->displayWarning($this->trans('Each store connects separately: choose a store in the store selector at the top.', array(), 'Modules.Ecomseoconnect.Admin'));
        }
        $idShop = $this->idShopActual();
        $salida .= $this->procesar($idShop);
        $this->context->smarty->assign(array(
            'esc_conectado' => EscClient::conectado($idShop),
            'esc_estado' => json_decode((string) EscClient::cfg('ECOMSEOCONNECT_ESTADO', $idShop, ''), true) ?: array(),
            'esc_admin' => $this->context->link->getAdminLink('AdminEcomSeoconnect'),
            'esc_kill' => (int) EscClient::cfg('ECOMSEOCONNECT_KILL', $idShop, 0),
        ));
        $salida .= $this->display(__FILE__, 'views/templates/admin/cabecera.tpl');
        return $salida . $this->formulario($idShop) . $this->display(__FILE__, 'views/templates/admin/ayuda.tpl');
    }

    private function procesar($idShop)
    {
        $out = '';
        if (Tools::isSubmit('submitEscGuardar')) {
            $clave = trim((string) Tools::getValue('ECOMSEOCONNECT_CLAVE'));
            if ($clave !== '') {
                $datos = EscClient::leerClave($clave);
                if (!$datos) {
                    return $this->displayError($this->trans('The connection key is not valid. Copy it again from the panel (it starts with SEOIA1.).', array(), 'Modules.Ecomseoconnect.Admin'));
                }
                Configuration::updateValue('ECOMSEOCONNECT_URL', $datos[0], false, null, $idShop);
                Configuration::updateValue('ECOMSEOCONNECT_SITE_ID', $datos[1], false, null, $idShop);
                Configuration::updateValue('ECOMSEOCONNECT_SECRET', $datos[2], false, null, $idShop);
                EscQueue::olvidar();
            }
            $perm = array();
            foreach (EscFields::mapa() as $tipo => $cs) {
                foreach (array_keys($cs) as $campo) {
                    $v = (string) Tools::getValue('ESCPERM_' . $tipo . '_' . $campo, 'suggest');
                    $perm[$tipo . '.' . $campo] = in_array($v, EscApplier::modos(), true) ? $v : 'suggest';
                    if ($campo === 'link_rewrite' && !EscFields::urlSegura($tipo, $idShop)) {
                        $perm[$tipo . '.' . $campo] = 'blocked';
                    }
                }
            }
            Configuration::updateValue('ECOMSEOCONNECT_PERMS', json_encode($perm), false, null, $idShop);
            Configuration::updateValue('ECOMSEOCONNECT_KILL', (int) Tools::getValue('ECOMSEOCONNECT_KILL') === 1 ? 1 : 0, false, null, $idShop);
            Configuration::updateValue('ECOMSEOCONNECT_DAILY_CAP', max(0, min(100000, (int) Tools::getValue('ECOMSEOCONNECT_DAILY_CAP', 50))), false, null, $idShop);
            Configuration::updateGlobalValue('ECOMSEOCONNECT_DEBUG', (int) Tools::getValue('ECOMSEOCONNECT_DEBUG') === 1 ? 1 : 0);
            foreach (array('ECOMSEOCONNECT_XDEFAULT', 'ECOMSEOCONNECT_JSONLD_ORG', 'ECOMSEOCONNECT_JSONLD_FAQ', 'ECOMSEOCONNECT_JSONLD_PRODUCTO') as $k) {
                // Interruptor (switch): siempre viaja con 0 o 1.
                Configuration::updateValue($k, (int) Tools::getValue($k) === 1 ? 1 : 0, false, null, $idShop);
            }
            if ((int) Tools::getValue('ECOMSEOCONNECT_LLMS') === 1) {
                Configuration::updateGlobalValue('ECOMSEOCONNECT_LLMS', 1);
                $err = EscLlms::generar();
                if ($err === 'ajeno') {
                    $out .= $this->displayWarning($this->trans('There is already an llms.txt that the module did not write: it has not been touched.', array(), 'Modules.Ecomseoconnect.Admin'));
                } elseif ($err !== '') {
                    $out .= $this->displayWarning($this->trans('llms.txt could not be written: the store root folder is not writable.', array(), 'Modules.Ecomseoconnect.Admin'));
                }
            } else {
                Configuration::updateGlobalValue('ECOMSEOCONNECT_LLMS', 0);
                EscLlms::borrar();
            }
            if ((int) Tools::getValue('ECOMSEOCONNECT_INDEXNOW') === 1) {
                $err = EscIndexNow::encender($idShop);
                if ($err !== '') {
                    $out .= $this->displayWarning($this->trans('IndexNow could not be enabled: the store root folder is not writable.', array(), 'Modules.Ecomseoconnect.Admin'));
                }
            } else {
                EscIndexNow::apagar($idShop);
            }
            $out .= $this->displayConfirmation($this->trans('Settings saved.', array(), 'Modules.Ecomseoconnect.Admin'));
            if (EscClient::conectado($idShop)) {
                // La plataforma ve al momento los permisos nuevos.
                list($ok, , $err) = EscSync::probar($idShop);
                if ($clave !== '') {
                    $out .= $ok ? $this->displayConfirmation($this->trans('Connected to the SEO IA system.', array(), 'Modules.Ecomseoconnect.Admin'))
                        : $this->displayError($this->trans('Saved, but the connection failed: %s', array($err), 'Modules.Ecomseoconnect.Admin'));
                    if ($ok && !(int) EscClient::cfg('ECOMSEOCONNECT_SEEDED', $idShop, 0)) {
                        EscSync::empezar($idShop);
                        EscSync::enviarCatalogo($idShop, 15);
                        $out .= $this->displayConfirmation($this->trans('Sending the catalog. It continues on its own in the background.', array(), 'Modules.Ecomseoconnect.Admin'));
                    }
                }
            }
        } elseif (Tools::isSubmit('submitEscProbar')) {
            list($ok, $d, $err) = EscSync::probar($idShop);
            $out .= $ok
                ? $this->displayConfirmation($this->trans('Connected: %1$s · plan %2$s (%3$s).', array(isset($d['nombre']) ? $d['nombre'] : '', isset($d['plan']) ? $d['plan'] : '-', isset($d['nivel']) ? $d['nivel'] : ''), 'Modules.Ecomseoconnect.Admin'))
                : $this->displayError($this->trans('No connection: %s', array($err), 'Modules.Ecomseoconnect.Admin'));
        } elseif (Tools::isSubmit('submitEscCatalogo')) {
            if (!EscClient::conectado($idShop)) {
                return $this->displayError($this->trans('Connect the store first.', array(), 'Modules.Ecomseoconnect.Admin'));
            }
            $p = EscSync::progreso($idShop);
            if (empty($p['activo'])) {
                EscSync::empezar($idShop);
            }
            $fin = EscSync::enviarCatalogo($idShop, 20);
            $p = EscSync::progreso($idShop);
            if (!empty($p['error'])) {
                $out .= $this->displayError($this->trans('Error sending the catalog: %s', array($p['error']), 'Modules.Ecomseoconnect.Admin'));
            } else {
                $out .= $this->displayConfirmation($fin ? $this->trans('Catalog sent completely.', array(), 'Modules.Ecomseoconnect.Admin')
                    : $this->trans('Sent %1$d of %2$d. It continues in the background (or press again).', array((int) $p['leidos'], (int) $p['total']), 'Modules.Ecomseoconnect.Admin'));
            }
        } elseif (Tools::isSubmit('submitEscDesconectar')) {
            foreach (array('ECOMSEOCONNECT_URL', 'ECOMSEOCONNECT_SITE_ID', 'ECOMSEOCONNECT_SECRET', 'ECOMSEOCONNECT_ESTADO', 'ECOMSEOCONNECT_SYNC', 'ECOMSEOCONNECT_SEEDED') as $k) {
                Configuration::updateValue($k, '', false, null, $idShop);
            }
            EscQueue::olvidar();
            $out .= $this->displayConfirmation($this->trans('Store disconnected.', array(), 'Modules.Ecomseoconnect.Admin'));
        }
        return $out;
    }

    private function formulario($idShop)
    {
        list($etq, $tipos) = $this->campos();
        $modos = array(
            array('id' => 'blocked', 'name' => $this->trans('Blocked', array(), 'Modules.Ecomseoconnect.Admin')),
            array('id' => 'suggest', 'name' => $this->trans('Suggest only', array(), 'Modules.Ecomseoconnect.Admin')),
            array('id' => 'approve', 'name' => $this->trans('Apply with approval', array(), 'Modules.Ecomseoconnect.Admin')),
            array('id' => 'auto', 'name' => $this->trans('Automatic', array(), 'Modules.Ecomseoconnect.Admin')),
        );
        $conectado = EscClient::conectado($idShop);
        $inputs = array();
        $inputs[] = array(
            'type' => 'text', 'tab' => 'escconexion', 'name' => 'ECOMSEOCONNECT_CLAVE',
            'label' => $this->trans('Connection key', array(), 'Modules.Ecomseoconnect.Admin'),
            'desc' => $conectado
                ? $this->trans('Connected (site %d). Paste a new key only if you regenerated it in the panel.', array((int) EscClient::cfg('ECOMSEOCONNECT_SITE_ID', $idShop)), 'Modules.Ecomseoconnect.Admin')
                : $this->trans('Paste the key shown in the panel when you added the store (starts with SEOIA1.).', array(), 'Modules.Ecomseoconnect.Admin'),
        );
        $inputs[] = array('type' => 'html', 'tab' => 'escconexion', 'name' => 'esc_html_con', 'html_content' => $this->htmlConexion($idShop));
        $vals = array('ECOMSEOCONNECT_CLAVE' => '', 'esc_html_con' => '', 'esc_html_sync' => '', 'esc_html_perm' => '');
        $inputs[] = array('type' => 'html', 'tab' => 'escpermisos', 'name' => 'esc_html_perm', 'html_content' => '<p class="help-block">'
            . Tools::safeOutput($this->trans('Nothing is written in your store without passing these permissions, whatever the platform says. By default everything is «Suggest only».', array(), 'Modules.Ecomseoconnect.Admin')) . '</p>');
        $perm = EscApplier::permisos($idShop);
        foreach (EscFields::mapa() as $tipo => $cs) {
            foreach (array_keys($cs) as $campo) {
                $nombre = 'ESCPERM_' . $tipo . '_' . $campo;
                $in = array('type' => 'select', 'tab' => 'escpermisos', 'name' => $nombre, 'label' => $tipos[$tipo] . ' · ' . $etq[$campo], 'options' => array('query' => $modos, 'id' => 'id', 'name' => 'name'));
                if ($campo === 'link_rewrite' && !EscFields::urlSegura($tipo, $idShop)) {
                    $in['options']['query'] = array($modos[0]);
                    $in['desc'] = $this->trans('Blocked: your store does not redirect old URLs on its own (route without {id} or canonical redirect other than 301).', array(), 'Modules.Ecomseoconnect.Admin');
                } elseif ($campo === 'link_rewrite') {
                    $in['desc'] = $this->trans('Your store redirects the old URL to the new one (301), so it can be changed safely.', array(), 'Modules.Ecomseoconnect.Admin');
                }
                $inputs[] = $in;
                $vals[$nombre] = $perm[$tipo . '.' . $campo];
            }
        }
        $switch = function ($name, $label, $desc) {
            return array('type' => 'switch', 'tab' => 'escseguridad', 'name' => $name, 'label' => $label, 'desc' => $desc, 'is_bool' => true,
                'values' => array(array('id' => $name . '_on', 'value' => 1, 'label' => $this->trans('Yes', array(), 'Modules.Ecomseoconnect.Admin')), array('id' => $name . '_off', 'value' => 0, 'label' => $this->trans('No', array(), 'Modules.Ecomseoconnect.Admin'))));
        };
        $inputs[] = $switch('ECOMSEOCONNECT_KILL', $this->trans('Total stop switch', array(), 'Modules.Ecomseoconnect.Admin'), $this->trans('While it is on, no change is applied in the store.', array(), 'Modules.Ecomseoconnect.Admin'));
        $inputs[] = array('type' => 'text', 'tab' => 'escseguridad', 'name' => 'ECOMSEOCONNECT_DAILY_CAP', 'class' => 'fixed-width-sm',
            'label' => $this->trans('Daily limit of changes', array(), 'Modules.Ecomseoconnect.Admin'), 'desc' => $this->trans('Maximum changes applied per day (0 = no limit).', array(), 'Modules.Ecomseoconnect.Admin'));
        $inputs[] = $switch('ECOMSEOCONNECT_INDEXNOW', 'IndexNow', $this->trans('Notifies Bing, Yandex, Seznam and Naver of the pages that change from now on. Never the old catalog.', array(), 'Modules.Ecomseoconnect.Admin')
            . (EscIndexNow::activo($idShop) ? ' ' . $this->trans('Key file: %s', array(Tools::getShopDomainSsl(true) . __PS_BASE_URI__ . EscIndexNow::clave($idShop) . '.txt'), 'Modules.Ecomseoconnect.Admin') : ''));
        $inputs[] = $switch('ECOMSEOCONNECT_DEBUG', $this->trans('Debug log', array(), 'Modules.Ecomseoconnect.Admin'), $this->trans('Writes a detailed log in the module logs/ folder.', array(), 'Modules.Ecomseoconnect.Admin'));
        $inputs[] = array('type' => 'html', 'tab' => 'escdatos', 'name' => 'esc_html_datos', 'html_content' => $this->htmlDatos($idShop));
        $datos = function ($name, $label, $desc) use ($switch) {
            $s = $switch($name, $label, $desc);
            $s['tab'] = 'escdatos';
            return $s;
        };
        $inputs[] = $datos('ECOMSEOCONNECT_XDEFAULT', $this->trans('hreflang x-default', array(), 'Modules.Ecomseoconnect.Admin'), $this->trans('Tells Google which version to show to visitors who speak none of your languages (the default language). Only with more than one language.', array(), 'Modules.Ecomseoconnect.Admin'));
        $inputs[] = $datos('ECOMSEOCONNECT_JSONLD_ORG', $this->trans('Organization and search box', array(), 'Modules.Ecomseoconnect.Admin'), $this->trans('On the home page: the store data and its search engine. Only what the theme does not already publish.', array(), 'Modules.Ecomseoconnect.Admin'));
        $inputs[] = $datos('ECOMSEOCONNECT_JSONLD_FAQ', $this->trans('Frequently asked questions', array(), 'Modules.Ecomseoconnect.Admin'), $this->trans('On product pages whose description has questions (a heading ending in «?» followed by its answer).', array(), 'Modules.Ecomseoconnect.Admin'));
        $inputs[] = $datos('ECOMSEOCONNECT_JSONLD_PRODUCTO', $this->trans('Product (only if the theme lacks it)', array(), 'Modules.Ecomseoconnect.Admin'), $this->trans('Price, availability, brand and EAN on the product page. It is not published if the theme already does.', array(), 'Modules.Ecomseoconnect.Admin'));
        $inputs[] = $datos('ECOMSEOCONNECT_LLMS', 'llms.txt', $this->trans('Writes llms.txt in the store root with the main categories, products and pages, and rebuilds it every week. For the whole installation. It never overwrites one written by hand.', array(), 'Modules.Ecomseoconnect.Admin'));
        $inputs[] = array('type' => 'html', 'tab' => 'escsync', 'name' => 'esc_html_sync', 'html_content' => $this->htmlSync($idShop));
        $vals['ECOMSEOCONNECT_KILL'] = (int) EscClient::cfg('ECOMSEOCONNECT_KILL', $idShop, 0);
        $vals['ECOMSEOCONNECT_DAILY_CAP'] = (int) EscClient::cfg('ECOMSEOCONNECT_DAILY_CAP', $idShop, 50);
        $vals['ECOMSEOCONNECT_INDEXNOW'] = (int) EscClient::cfg('ECOMSEOCONNECT_INDEXNOW', $idShop, 0);
        $vals['ECOMSEOCONNECT_DEBUG'] = (int) Configuration::getGlobalValue('ECOMSEOCONNECT_DEBUG');
        foreach (array('ECOMSEOCONNECT_XDEFAULT', 'ECOMSEOCONNECT_JSONLD_ORG', 'ECOMSEOCONNECT_JSONLD_FAQ', 'ECOMSEOCONNECT_JSONLD_PRODUCTO') as $k) {
            $vals[$k] = (int) EscClient::cfg($k, $idShop, 0);
        }
        $vals['ECOMSEOCONNECT_LLMS'] = EscLlms::activo() ? 1 : 0;
        $vals['esc_html_datos'] = '';

        $form = array('form' => array(
            'legend' => array('title' => $this->displayName, 'icon' => 'icon-cogs'),
            'tabs' => array(
                'escconexion' => $this->trans('Connection', array(), 'Modules.Ecomseoconnect.Admin'),
                'escpermisos' => $this->trans('Permissions', array(), 'Modules.Ecomseoconnect.Admin'),
                'escseguridad' => $this->trans('Security', array(), 'Modules.Ecomseoconnect.Admin'),
                'escdatos' => $this->trans('Structured data', array(), 'Modules.Ecomseoconnect.Admin'),
                'escsync' => $this->trans('Synchronization', array(), 'Modules.Ecomseoconnect.Admin'),
            ),
            'input' => $inputs,
            'submit' => array('title' => $this->trans('Save', array(), 'Modules.Ecomseoconnect.Admin'), 'name' => 'submitEscGuardar'),
            'buttons' => array(
                array('title' => $this->trans('Test connection', array(), 'Modules.Ecomseoconnect.Admin'), 'name' => 'submitEscProbar', 'type' => 'submit', 'class' => 'btn btn-default pull-right', 'icon' => 'process-icon-refresh'),
                array('title' => $this->trans('Send the catalog now', array(), 'Modules.Ecomseoconnect.Admin'), 'name' => 'submitEscCatalogo', 'type' => 'submit', 'class' => 'btn btn-default pull-right', 'icon' => 'process-icon-upload'),
            ),
        ));
        if ($conectado) {
            $form['form']['buttons'][] = array('title' => $this->trans('Disconnect', array(), 'Modules.Ecomseoconnect.Admin'), 'name' => 'submitEscDesconectar', 'type' => 'submit', 'class' => 'btn btn-default esc-confirmar', 'icon' => 'process-icon-cancel');
        }
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->allow_employee_form_lang = (int) Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG');
        $helper->show_toolbar = false;
        $helper->submit_action = 'submitEscGuardar';
        $helper->fields_value = $vals;
        return $helper->generateForm(array($form));
    }

    private function htmlConexion($idShop)
    {
        $e = json_decode((string) EscClient::cfg('ECOMSEOCONNECT_ESTADO', $idShop, ''), true);
        if (!EscClient::conectado($idShop)) {
            return '<div class="alert alert-info">' . Tools::safeOutput($this->trans('Not connected yet.', array(), 'Modules.Ecomseoconnect.Admin')) . '</div>';
        }
        $h = '<div class="alert alert-success">' . Tools::safeOutput($this->trans('Platform: %s', array(EscClient::cfg('ECOMSEOCONNECT_URL', $idShop)), 'Modules.Ecomseoconnect.Admin'));
        if (is_array($e) && !empty($e['fecha'])) {
            $h .= '<br>' . Tools::safeOutput($this->trans('Last check: %1$s · plan %2$s (%3$s)', array($e['fecha'], $e['plan'], $e['nivel']), 'Modules.Ecomseoconnect.Admin'));
            if (!empty($e['panel']) && preg_match('#^https?://#', $e['panel'])) {
                $h .= '<br><a href="' . Tools::safeOutput($e['panel']) . '" target="_blank" rel="noopener noreferrer">' . Tools::safeOutput($this->trans('Open the diagnosis in the panel', array(), 'Modules.Ecomseoconnect.Admin')) . '</a>';
            }
        }
        return $h . '</div>';
    }

    /** Lo que ya trae el tema y el estado del llms.txt, para no duplicar nada. */
    private function htmlDatos($idShop)
    {
        $tema = EscFront::tema($idShop);
        $si = $this->trans('yes', array(), 'Modules.Ecomseoconnect.Admin');
        $no = $this->trans('no', array(), 'Modules.Ecomseoconnect.Admin');
        $tipos = $tema['tipos'] ? implode(', ', $tema['tipos']) : $this->trans('none', array(), 'Modules.Ecomseoconnect.Admin');
        $estados = array(
            'nuestro' => $this->trans('written by this module', array(), 'Modules.Ecomseoconnect.Admin'),
            'ajeno' => $this->trans('exists and was not written by this module (it is not touched)', array(), 'Modules.Ecomseoconnect.Admin'),
            'ninguno' => $this->trans('does not exist', array(), 'Modules.Ecomseoconnect.Admin'),
        );
        return '<div class="alert alert-info">'
            . Tools::safeOutput($this->trans('Theme %s already publishes: %s · hreflang: %s · x-default: %s', array($tema['nombre'], $tipos, $tema['hreflang'] ? $si : $no, $tema['xdefault'] ? $si : $no), 'Modules.Ecomseoconnect.Admin')) . '<br>'
            . Tools::safeOutput($this->trans('llms.txt: %s', array($estados[EscLlms::estado()]), 'Modules.Ecomseoconnect.Admin')) . '<br>'
            . Tools::safeOutput($this->trans('Other modules may also publish structured data: check a product with Google\'s Rich Results Test before turning anything on.', array(), 'Modules.Ecomseoconnect.Admin'))
            . '</div>';
    }

    private function htmlSync($idShop)
    {
        $p = EscSync::progreso($idShop);
        $h = '<div class="form-group"><div class="col-lg-9 col-lg-offset-3">';
        if (!empty($p['activo'])) {
            $h .= '<p>' . Tools::safeOutput($this->trans('Sending the catalog: %1$d of %2$d.', array((int) $p['leidos'], (int) $p['total']), 'Modules.Ecomseoconnect.Admin')) . '</p>';
            if (!empty($p['error'])) {
                $h .= '<p class="text-danger">' . Tools::safeOutput($p['error']) . '</p>';
            }
        } elseif (!empty($p['terminado'])) {
            $h .= '<p>' . Tools::safeOutput($this->trans('Last full send: %1$s (%2$d elements).', array($p['terminado'], (int) $p['leidos']), 'Modules.Ecomseoconnect.Admin')) . '</p>';
        }
        $h .= '<p>' . Tools::safeOutput($this->trans('Changes waiting to be sent: %d', array(EscQueue::pendientes($idShop)), 'Modules.Ecomseoconnect.Admin')) . '</p>';
        $h .= '<p>' . Tools::safeOutput($this->trans('Last time approved changes were fetched: %s', array(EscClient::cfg('ECOMSEOCONNECT_ULTIMO_TIRON', $idShop, '-')), 'Modules.Ecomseoconnect.Admin')) . '</p>';
        $h .= '<label>' . Tools::safeOutput($this->trans('Cron URL (every 5-10 minutes)', array(), 'Modules.Ecomseoconnect.Admin')) . '</label>';
        $h .= '<input type="text" readonly class="form-control esc-seleccionar" value="' . Tools::safeOutput(EscSync::urlCron($idShop)) . '">';
        return $h . '</div></div>';
    }

    /* ======================= Registro en modules.gmartos.es ======================= */

    /**
     * Registra la instalacion y mira si hay version nueva. Maximo una vez por semana, 3 segundos
     * de tiempo maximo y silencio total si falla. Con cURL: el modulo no usa dependencias.
     */
    private function checkGmartosUpdate()
    {
        $ultimo = (int) Configuration::get('GMARTOS_LAST_PING_' . $this->name);
        if ((time() - $ultimo) < 604800) {
            return (bool) Configuration::get('GMARTOS_UPDATE_AVAILABLE_' . $this->name);
        }
        if (!function_exists('curl_init')) {
            return false;
        }
        $datos = json_encode(array(
            'action' => 'register',
            'module_name' => $this->name,
            'version' => $this->version,
            'url' => Tools::getShopDomainSsl(true),
            'email' => Configuration::get('PS_SHOP_EMAIL'),
        ));
        $ch = curl_init('https://modules.gmartos.es/api.php');
        curl_setopt_array($ch, array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => $datos, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 3,
            CURLOPT_CONNECTTIMEOUT => 2, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_HTTPHEADER => array('Content-Type: application/json')));
        $resp = curl_exec($ch);
        $codigo = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (PHP_VERSION_ID < 80000) {
            curl_close($ch);
        }
        if ($resp === false || $codigo !== 200) {
            return false;
        }
        $j = json_decode((string) $resp, true);
        if (!is_array($j) || empty($j['success'])) {
            return false;
        }
        Configuration::updateValue('GMARTOS_LAST_PING_' . $this->name, time());
        $hay = !empty($j['update_available']);
        Configuration::updateValue('GMARTOS_UPDATE_AVAILABLE_' . $this->name, $hay ? 1 : 0);
        if ($hay && isset($j['latest_version'])) {
            Configuration::updateValue('GMARTOS_LATEST_VERSION_' . $this->name, (string) $j['latest_version']);
        }
        return $hay;
    }
}
