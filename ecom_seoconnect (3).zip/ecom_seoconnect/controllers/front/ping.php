<?php
/**
 * Ecom SEO Connect - «toque» de la plataforma. NO recibe datos: solo comprueba la firma y adelanta
 * la pasada que la tienda haria de todas formas (seguir con el catalogo que este a medias, enviar la
 * cola y recoger los cambios aprobados). Desde la 1.1.3 el envio del catalogo ya no depende de que la
 * tienda tenga programada la tarea del modulo: la plataforma lo va pidiendo hasta que termina.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class Ecom_SeoconnectPingModuleFrontController extends ModuleFrontController
{
    public $ssl = false;
    public $display_header = false;
    public $display_footer = false;

    /** El toque tiene que llegar aunque la tienda este en mantenimiento o el pais restringido. */
    protected function displayMaintenancePage()
    {
    }

    protected function displayRestrictedCountryPage()
    {
    }

    private function salir($codigo, $texto)
    {
        http_response_code($codigo);
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo $texto;
        exit;
    }

    public function postProcess()
    {
        $idShop = (int) $this->context->shop->id;
        if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST' || !EscClient::conectado($idShop)) {
            $this->salir(404, '');
        }
        $ruta = (string) parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH);
        $h = function ($k) {
            $k = 'HTTP_' . strtoupper(str_replace('-', '_', $k));
            return isset($_SERVER[$k]) ? (string) $_SERVER[$k] : '';
        };
        $ok = EscSigner::valida((string) EscClient::cfg('ECOMSEOCONNECT_SECRET', $idShop), (int) EscClient::cfg('ECOMSEOCONNECT_SITE_ID', $idShop),
            $ruta, '', $h('X-Seo-Site'), $h('X-Seo-Ts'), $h('X-Seo-Nonce'), $h('X-Seo-Sign'));
        if (!$ok) {
            EscLog::error('Toque con firma no válida desde ' . Tools::getRemoteAddr());
            $this->salir(401, 'no');
        }
        // Anti-repeticion: cada nonce vale una sola vez.
        $nonce = $h('X-Seo-Nonce');
        if (!Db::getInstance()->execute('INSERT IGNORE INTO `' . _DB_PREFIX_ . 'ecomseoconnect_nonce` (`nonce`, `fecha`) VALUES (\'' . pSQL($nonce) . '\', \'' . pSQL(date('Y-m-d H:i:s')) . '\')')
            || !Db::getInstance()->Affected_Rows()) {
            $this->salir(409, 'repetida');
        }
        $ult = (int) EscClient::cfg('ECOMSEOCONNECT_ULTIMO_PING', $idShop, 0);
        if ($ult > time() - 30) {
            $this->salir(429, 'espera');
        }
        Configuration::updateValue('ECOMSEOCONNECT_ULTIMO_PING', time(), false, null, $idShop);
        ignore_user_abort(true);
        // Con el catalogo: si hay un envio a medias, este toque lo continua (antes solo avanzaba con el cron de la tienda).
        EscSync::trabajo($idShop, 20, true);
        $this->salir(200, 'ok');
    }
}
