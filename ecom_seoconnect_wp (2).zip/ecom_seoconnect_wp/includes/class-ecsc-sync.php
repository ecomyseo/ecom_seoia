<?php
/**
 * SEO IA Connect - sincronización con la plataforma.
 *
 * Envío completo por tandas y por tiempo, cola con lo que cambia en la web, recogida de las
 * mejoras aprobadas («tirón») y el «toque» firmado con el que la plataforma adelanta una pasada.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_Sync
{
    const LOTE = 25;

    /** La plataforma acaba de pedir, en esta misma pasada, el contenido completo. */
    private static $relectura = false;

    public static function enganchar()
    {
        add_action('save_post', array(__CLASS__, 'alGuardarEntrada'), 20, 2);
        add_action('trashed_post', array(__CLASS__, 'alBorrarEntrada'));
        add_action('deleted_post', array(__CLASS__, 'alBorrarEntrada'));
        add_action('created_term', array(__CLASS__, 'alGuardarTermino'), 20, 3);
        add_action('edited_term', array(__CLASS__, 'alGuardarTermino'), 20, 3);
        add_action('delete_term', array(__CLASS__, 'alGuardarTermino'), 20, 3);
        add_action('rest_api_init', array(__CLASS__, 'rutas'));
    }

    // ------------------------------------------------------------------ cola de cambios

    public static function poner($tipo, $id)
    {
        global $wpdb;
        if (!$tipo || (int) $id <= 0 || !Ecsc_Client::conectado()) {
            return;
        }
        $wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->prefix}ecsc_queue (tipo, id_elemento, fecha) VALUES (%s, %d, %s) ON DUPLICATE KEY UPDATE fecha = VALUES(fecha)",
            (string) $tipo, (int) $id, current_time('mysql')));
    }

    public static function pendientes()
    {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ecsc_queue");
    }

    public static function alGuardarEntrada($idPost, $post = null)
    {
        if (wp_is_post_revision($idPost) || wp_is_post_autosave($idPost) || !is_object($post)) {
            return;
        }
        self::poner(Ecsc_Catalog::tipoDePost($post->post_type), (int) $idPost);
    }

    public static function alBorrarEntrada($idPost)
    {
        self::poner(Ecsc_Catalog::tipoDePost((string) get_post_type($idPost)), (int) $idPost);
    }

    public static function alGuardarTermino($idTermino, $ttId = 0, $taxonomia = '')
    {
        self::poner(Ecsc_Catalog::tipoDeTaxonomia((string) $taxonomia), (int) $idTermino);
    }

    // ------------------------------------------------------------------ lo que se cuenta de la web

    public static function urlToque()
    {
        return rest_url('ecsc/v1/toque');
    }

    /** Lo que la plataforma recibe en cada llamada para saber cómo es la web. */
    public static function meta()
    {
        return array(
            'plataforma' => Ecsc_Catalog::hayTienda() ? 'woocommerce' : 'wordpress',
            'version_ps' => (string) get_bloginfo('version'),
            'version_modulo' => ECSC_VERSION,
            'id_tienda' => (int) get_current_blog_id(),
            'idiomas' => array(Ecsc_Catalog::iso()),
            'config' => Ecsc_Catalog::config(),
            'permisos' => Ecsc_Applier::permisos(),
            'url_ping' => self::urlToque(),
        );
    }

    public static function probar()
    {
        list($ok, $d, $err) = Ecsc_Client::llamar('estado', self::meta(), 20);
        if ($ok) {
            update_option('ecsc_estado', wp_json_encode(array('fecha' => current_time('mysql'), 'nombre' => isset($d['nombre']) ? $d['nombre'] : '',
                'nivel' => isset($d['nivel']) ? $d['nivel'] : '', 'plan' => isset($d['plan']) ? $d['plan'] : '', 'panel' => isset($d['panel']) ? $d['panel'] : '')), false);
            self::atenderRelectura($d);
            self::anotarVersion($d);
        }
        return array($ok, $d, $err);
    }

    /** La plataforma pide el contenido completo otra vez. Si ya hay un envío en marcha, se deja. */
    private static function atenderRelectura($d)
    {
        if (!is_array($d) || empty($d['releer'])) {
            return false;
        }
        $s = self::progreso();
        if (!empty($s['activo'])) {
            return false;
        }
        self::empezar();
        self::$relectura = true;
        Ecsc_Log::escribir('La plataforma pide volver a leer el contenido: empieza un envío completo.');
        return true;
    }

    /** La plataforma dice qué versión del plugin se descarga ahora: se guarda para avisar en el escritorio. */
    private static function anotarVersion($d)
    {
        if (!is_array($d) || !isset($d['modulo_ultima']) || !preg_match('/^\d+(\.\d+){1,3}$/', (string) $d['modulo_ultima'])) {
            return;
        }
        $descarga = isset($d['modulo_descarga']) ? (string) $d['modulo_descarga'] : '';
        $base = rtrim((string) get_option('ecsc_url', ''), '/') . '/';
        if ($base === '/' || strpos($descarga, $base) !== 0) {
            $descarga = '';   // solo se enlaza una descarga que cuelgue de la plataforma conectada
        }
        if ((string) get_option('ecsc_ultima_version', '') !== (string) $d['modulo_ultima']) {
            update_option('ecsc_ultima_version', (string) $d['modulo_ultima'], false);
        }
        if ((string) get_option('ecsc_descarga', '') !== $descarga) {
            update_option('ecsc_descarga', $descarga, false);
        }
    }

    // ------------------------------------------------------------------ envío completo

    public static function progreso()
    {
        $s = json_decode((string) get_option('ecsc_sync', ''), true);
        return is_array($s) ? $s : array('activo' => 0);
    }

    private static function guardar(array $s)
    {
        update_option('ecsc_sync', wp_json_encode($s), false);
    }

    /** Prepara un envío completo (se hace por tandas en las siguientes pasadas). */
    public static function empezar()
    {
        $total = 0;
        foreach (Ecsc_Catalog::tipos() as $t) {
            $total += Ecsc_Catalog::total($t);
        }
        self::guardar(array('activo' => 1, 'idx' => 0, 'cursor' => 0, 'inicio' => 1, 'total' => $total, 'leidos' => 0, 'empezado' => current_time('mysql'), 'error' => ''));
    }

    /** Envía tandas durante como mucho $segundos. Devuelve true si ha terminado. */
    public static function enviarCatalogo($segundos)
    {
        $s = self::progreso();
        if (empty($s['activo'])) {
            return true;
        }
        $fin = microtime(true) + $segundos;
        $tipos = Ecsc_Catalog::tipos();
        while (microtime(true) < $fin) {
            if ($s['idx'] >= count($tipos)) {
                list($ok, , $err) = Ecsc_Client::llamar('sync', array_merge(self::meta(), array('fin' => 1, 'elementos' => array(), 'leidos' => 0)), 60);
                if (!$ok) {
                    $s['error'] = $err;
                    break;
                }
                $s = array('activo' => 0, 'terminado' => current_time('mysql'), 'total' => $s['total'], 'leidos' => $s['leidos'], 'error' => '');
                update_option('ecsc_seeded', 1, false);
                update_option('ecsc_ultima_completa', time(), false);
                break;
            }
            $tipo = $tipos[$s['idx']];
            $ids = Ecsc_Catalog::ids($tipo, $s['cursor'], self::LOTE);
            if (!$ids) {
                $s['idx']++;
                $s['cursor'] = 0;
                continue;
            }
            $elementos = array();
            foreach ($ids as $id) {
                $e = Ecsc_Catalog::elemento($tipo, $id);
                if ($e) {
                    $elementos[] = $e;
                }
            }
            $datos = array_merge(self::meta(), array('elementos' => $elementos, 'leidos' => count($ids), 'total' => (int) $s['total']));
            if (!empty($s['inicio'])) {
                $datos['inicio'] = 1;
            }
            list($ok, , $err) = Ecsc_Client::llamar('sync', $datos, 60);
            if (!$ok) {
                // No se avanza el cursor: la tanda se repite en la siguiente pasada.
                $s['error'] = $err;
                break;
            }
            $s['inicio'] = 0;
            $s['error'] = '';
            // El cursor avanza por lo LEÍDO (el último id pedido), no por lo que se ha mandado.
            $s['cursor'] = end($ids);
            $s['leidos'] += count($ids);
        }
        self::guardar($s);
        return empty($s['activo']);
    }

    /** Manda lo que hay en la cola (cambios hechos en la web). */
    public static function enviarCola()
    {
        global $wpdb;
        $filas = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ecsc_queue ORDER BY id ASC LIMIT 60", ARRAY_A);
        $filas = is_array($filas) ? $filas : array();
        if (!$filas) {
            return 0;
        }
        $elementos = array();
        $borrados = array();
        foreach ($filas as $f) {
            $e = Ecsc_Catalog::elemento($f['tipo'], (int) $f['id_elemento']);
            if ($e) {
                $elementos[] = $e;
            } else {
                $borrados[] = array('tipo' => $f['tipo'], 'id' => (int) $f['id_elemento']);
            }
        }
        list($ok, , $err) = Ecsc_Client::llamar('sync', array_merge(self::meta(), array('incremental' => 1, 'elementos' => $elementos, 'borrados' => $borrados)), 60);
        if (!$ok) {
            Ecsc_Log::escribir('Cola no enviada: ' . $err);
            return 0;
        }
        $ids = array();
        foreach ($filas as $f) {
            $ids[] = (int) $f['id'];
        }
        $wpdb->query("DELETE FROM {$wpdb->prefix}ecsc_queue WHERE id IN (" . implode(',', $ids) . ')');
        return count($filas);
    }

    /** Va a buscar las mejoras aprobadas, las aplica con SUS permisos e informa del resultado. */
    public static function tiron()
    {
        list($ok, $d, ) = Ecsc_Client::llamar('cambios', self::meta(), 30);
        if ($ok) {
            self::atenderRelectura($d);
            self::anotarVersion($d);
        }
        $resultados = array();
        if ($ok && !empty($d['cambios']) && is_array($d['cambios'])) {
            $resultados = Ecsc_Applier::aplicar($d['cambios']);
        }
        $deshechos = Ecsc_History::pendientesDeInformar();
        foreach ($deshechos as $h) {
            $resultados[] = array('id' => (int) $h['id_propuesta'], 'estado' => 'deshecha', 'motivo' => 'deshecho_en_la_web');
        }
        if ($resultados) {
            list($ok2) = Ecsc_Client::llamar('resultado', array('resultados' => $resultados), 30);
            if ($ok2 && $deshechos) {
                $ids = array();
                foreach ($deshechos as $h) {
                    $ids[] = (int) $h['id'];
                }
                Ecsc_History::marcarInformados($ids);
            }
        }
        update_option('ecsc_ultimo_tiron', current_time('mysql'), false);
        return $ok ? count($resultados) : -1;
    }

    /** Una pasada completa de trabajo, con candado para no pisarse. */
    public static function trabajo($segundos = 20, $conCatalogo = true)
    {
        $ahora = time();
        if ((int) get_option('ecsc_candado', 0) > $ahora - 90) {
            return 'ocupado';
        }
        update_option('ecsc_candado', $ahora, false);
        try {
            $fin = microtime(true) + $segundos;
            if ($conCatalogo) {
                $ultima = (int) get_option('ecsc_ultima_completa', 0);
                $s = self::progreso();
                if (empty($s['activo']) && (!$ultima || $ultima < $ahora - 7 * 86400)) {
                    // Primera vez o semanal: repaso completo.
                    self::empezar();
                }
                self::enviarCatalogo(max(3, $fin - microtime(true) - 5));
            }
            self::enviarCola();
            self::tiron();
            if (self::$relectura) {
                // La primera tanda sale ya: lleva la marca de inicio y la plataforma da la petición por atendida.
                self::$relectura = false;
                self::enviarCatalogo(max(3, $fin - microtime(true) - 2));
            }
        } catch (Exception $e) {
            Ecsc_Log::error('Trabajo: ' . $e->getMessage());
        }
        update_option('ecsc_candado', 0, false);
        return 'ok';
    }

    // ------------------------------------------------------------------ toque de la plataforma

    public static function rutas()
    {
        register_rest_route('ecsc/v1', '/toque', array(
            'methods' => 'POST',
            'callback' => array(__CLASS__, 'toque'),
            // La autorización es la firma HMAC de la petición, que se comprueba dentro.
            'permission_callback' => '__return_true',
        ));
    }

    private static function respuesta($codigo, $texto)
    {
        $r = new WP_REST_Response($texto, $codigo);
        $r->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $r->header('Pragma', 'no-cache');
        $r->header('Expires', '0');
        return $r;
    }

    /** Petición firmada y SIN datos: la web adelanta su propia pasada. No acepta nada por esta vía. */
    public static function toque($peticion)
    {
        global $wpdb;
        if (!Ecsc_Client::conectado()) {
            return self::respuesta(404, '');
        }
        $ruta = (string) wp_parse_url(self::urlToque(), PHP_URL_PATH);
        $ok = Ecsc_Signer::valida((string) get_option('ecsc_secret', ''), (int) get_option('ecsc_site_id', 0), $ruta, '',
            (string) $peticion->get_header('x_seo_site'), (string) $peticion->get_header('x_seo_ts'),
            (string) $peticion->get_header('x_seo_nonce'), (string) $peticion->get_header('x_seo_sign'));
        if (!$ok) {
            Ecsc_Log::error('Toque con firma no válida');
            return self::respuesta(401, 'no');
        }
        // Anti-repetición: cada nonce vale una sola vez.
        $nuevo = $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->prefix}ecsc_nonce (nonce, fecha) VALUES (%s, %s)", (string) $peticion->get_header('x_seo_nonce'), current_time('mysql')));
        if ((int) $nuevo !== 1) {
            return self::respuesta(409, 'repetida');
        }
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}ecsc_nonce WHERE fecha < %s", gmdate('Y-m-d H:i:s', time() - 2 * 86400)));
        if ((int) get_option('ecsc_ultimo_toque', 0) > time() - 30) {
            return self::respuesta(429, 'espera');
        }
        update_option('ecsc_ultimo_toque', time(), false);
        ignore_user_abort(true);
        self::trabajo(20, true);
        return self::respuesta(200, 'ok');
    }
}
