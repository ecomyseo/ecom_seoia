<?php
/**
 * Ecom SEO Connect - IndexNow (Bing, Yandex, Seznam, Naver).
 *
 * REGLA DE SEGURIDAD (avisos a terceros):
 *  - apagado por defecto;
 *  - solo avisa de elementos que entran en la cola DESPUES de encenderlo (ECOMSEOCONNECT_INDEXNOW_DESDE);
 *  - ventana maxima de 24 horas;
 *  - una URL, como mucho una vez al dia;
 *  - jamas recorre el catalogo antiguo.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscIndexNow
{
    /** Interruptor de codigo: si algun dia hubiera que cortar IndexNow en todas las tiendas a la vez. */
    const KILL_SWITCH = false;

    public static function raiz()
    {
        return rtrim(defined('_PS_ROOT_DIR_') ? _PS_ROOT_DIR_ : dirname(_PS_MODULE_DIR_), '/\\');
    }

    public static function activo($idShop)
    {
        return !self::KILL_SWITCH && (int) EscClient::cfg('ECOMSEOCONNECT_INDEXNOW', $idShop, 0) === 1 && self::clave($idShop) !== '' && is_file(self::fichero($idShop));
    }

    public static function clave($idShop)
    {
        $k = (string) EscClient::cfg('ECOMSEOCONNECT_INDEXNOW_KEY', $idShop, '');
        return preg_match('/^[a-f0-9]{32}$/', $k) ? $k : '';
    }

    public static function fichero($idShop)
    {
        return self::raiz() . '/' . self::clave($idShop) . '.txt';
    }

    /**
     * Enciende IndexNow: crea la clave y el fichero en la raiz, y fija el «desde» (semilla):
     * nada anterior a este momento se avisara nunca. Devuelve '' o el motivo del fallo.
     */
    public static function encender($idShop)
    {
        $k = self::clave($idShop);
        if ($k === '') {
            $k = bin2hex(random_bytes(16));
            Configuration::updateValue('ECOMSEOCONNECT_INDEXNOW_KEY', $k, false, null, (int) $idShop);
        }
        $f = self::raiz() . '/' . $k . '.txt';
        if (!is_file($f) && @file_put_contents($f, $k) === false) {
            Configuration::updateValue('ECOMSEOCONNECT_INDEXNOW', 0, false, null, (int) $idShop);
            return 'no_se_puede_escribir_en_la_raiz';
        }
        if (!(int) EscClient::cfg('ECOMSEOCONNECT_INDEXNOW', $idShop, 0)) {
            Configuration::updateValue('ECOMSEOCONNECT_INDEXNOW_DESDE', date('Y-m-d H:i:s'), false, null, (int) $idShop);
        }
        Configuration::updateValue('ECOMSEOCONNECT_INDEXNOW', 1, false, null, (int) $idShop);
        return '';
    }

    public static function apagar($idShop)
    {
        Configuration::updateValue('ECOMSEOCONNECT_INDEXNOW', 0, false, null, (int) $idShop);
    }

    /** Borra los ficheros de clave de todas las tiendas (al desinstalar). */
    public static function borrarFicheros()
    {
        foreach (Shop::getShops(false, null, true) as $idShop) {
            $k = self::clave($idShop);
            if ($k !== '' && is_file(self::raiz() . '/' . $k . '.txt')) {
                @unlink(self::raiz() . '/' . $k . '.txt');
            }
        }
    }

    /**
     * Avisa de las URLs de elementos cambiados. $cambiados = [[tipo, id, fecha_en_cola], ...]
     */
    public static function avisar($idShop, array $cambiados, EscCatalog $cat)
    {
        if (!self::activo($idShop) || !$cambiados) {
            return 0;
        }
        $desde = strtotime((string) EscClient::cfg('ECOMSEOCONNECT_INDEXNOW_DESDE', $idShop, '2999-01-01'));
        $limite = max($desde, time() - 86400);
        $urls = array();
        foreach ($cambiados as $c) {
            if (strtotime($c[2]) < $limite) {
                continue;
            }
            $e = $cat->elemento($c[0], $c[1]);
            if (!$e || empty($e['activo'])) {
                continue;
            }
            foreach ($e['idiomas'] as $l) {
                if (!empty($l['url'])) {
                    $urls[] = $l['url'];
                }
            }
        }
        $urls = array_values(array_unique($urls));
        $db = Db::getInstance();
        $enviar = array();
        foreach ($urls as $u) {
            $h = sha1($u);
            $ya = $db->getValue('SELECT 1 FROM `' . _DB_PREFIX_ . 'ecomseoconnect_indexnow` WHERE `id_shop` = ' . (int) $idShop . ' AND `url_hash` = \'' . pSQL($h) . '\' AND `fecha` > \'' . pSQL(date('Y-m-d H:i:s', time() - 86400)) . '\'');
            if (!$ya) {
                $enviar[$h] = $u;
            }
        }
        if (!$enviar) {
            return 0;
        }
        $host = (string) parse_url(reset($enviar), PHP_URL_HOST);
        $base = (string) parse_url(reset($enviar), PHP_URL_SCHEME) . '://' . $host;
        $cuerpo = json_encode(array('host' => $host, 'key' => self::clave($idShop), 'keyLocation' => $base . '/' . self::clave($idShop) . '.txt', 'urlList' => array_slice(array_values($enviar), 0, 1000)), JSON_UNESCAPED_SLASHES);
        $ch = curl_init('https://api.indexnow.org/indexnow');
        curl_setopt_array($ch, array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => $cuerpo, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
            CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_HTTPHEADER => array('Content-Type: application/json; charset=utf-8')));
        curl_exec($ch);
        $codigo = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (PHP_VERSION_ID < 80000) {
            curl_close($ch);
        }
        EscLog::escribir('IndexNow: ' . count($enviar) . ' URL -> HTTP ' . $codigo);
        if ($codigo === 200 || $codigo === 202) {
            foreach (array_keys($enviar) as $h) {
                $db->execute('REPLACE INTO `' . _DB_PREFIX_ . 'ecomseoconnect_indexnow` (`id_shop`, `url_hash`, `fecha`) VALUES (' . (int) $idShop . ', \'' . pSQL($h) . '\', \'' . pSQL(date('Y-m-d H:i:s')) . '\')');
            }
            return count($enviar);
        }
        return 0;
    }
}
