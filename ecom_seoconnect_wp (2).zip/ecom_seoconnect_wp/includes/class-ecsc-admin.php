<?php
/**
 * SEO IA Connect - Ajustes > SEO IA Connect: conexión, permisos, sincronización e historial.
 * Una sola pantalla con pestañas. Todo formulario lleva nonce y exige «manage_options».
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_Admin
{
    const PAGINA = 'ecsc';

    public static function enganchar()
    {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_post_ecsc_accion', array(__CLASS__, 'accion'));
        add_action('admin_notices', array(__CLASS__, 'avisoVersion'));
        add_filter('plugin_action_links_' . plugin_basename(ECSC_FILE), array(__CLASS__, 'enlaces'));
    }

    public static function menu()
    {
        add_options_page('SEO IA Connect', 'SEO IA Connect', 'manage_options', self::PAGINA, array(__CLASS__, 'pantalla'));
    }

    public static function enlaces($enlaces)
    {
        $lista = is_array($enlaces) ? $enlaces : array();
        array_unshift($lista, '<a href="' . esc_url(self::url()) . '">' . esc_html__('Settings', 'ecom_seoconnect_wp') . '</a>');
        return $lista;
    }

    private static function url($pestana = 'conexion')
    {
        return admin_url('options-general.php?page=' . self::PAGINA . '&tab=' . $pestana);
    }

    /** ¿Hay una versión del plugin más nueva que la instalada, según la plataforma? */
    public static function versionNueva()
    {
        $ultima = (string) get_option('ecsc_ultima_version', '');
        return $ultima !== '' && version_compare($ultima, ECSC_VERSION, '>') ? $ultima : '';
    }

    /** Aviso en todo el escritorio, para quien administra la web. */
    public static function avisoVersion()
    {
        $ultima = self::versionNueva();
        if ($ultima === '' || !current_user_can('manage_options')) {
            return;
        }
        $descarga = (string) get_option('ecsc_descarga', '');
        echo '<div class="notice notice-warning"><p><strong>' . esc_html(sprintf(
            /* translators: 1: new version, 2: installed version */
            __('SEO IA Connect: version %1$s is available (you have %2$s). Update it.', 'ecom_seoconnect_wp'), $ultima, ECSC_VERSION)) . '</strong>';
        if ($descarga !== '') {
            echo ' <a class="button button-primary" href="' . esc_url($descarga) . '">' . esc_html__('Download the plugin', 'ecom_seoconnect_wp') . '</a>';
        }
        echo '</p></div>';
    }

    private static function avisar($texto, $tipo = 'success')
    {
        set_transient('ecsc_aviso_' . get_current_user_id(), array($tipo, $texto), 60);
    }

    /** Todas las acciones de la pantalla pasan por aquí. */
    public static function accion()
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to do this.', 'ecom_seoconnect_wp'));
        }
        check_admin_referer('ecsc_accion');
        $que = isset($_POST['ecsc_que']) ? sanitize_key(wp_unslash($_POST['ecsc_que'])) : '';
        $pestana = 'conexion';
        if ($que === 'conectar') {
            $clave = isset($_POST['ecsc_clave']) ? trim(sanitize_text_field(wp_unslash($_POST['ecsc_clave']))) : '';
            if (!Ecsc_Client::conectar($clave)) {
                self::avisar(__('That connection key is not valid. Copy it again from your SEO IA panel.', 'ecom_seoconnect_wp'), 'error');
            } else {
                list($ok, , $err) = Ecsc_Sync::probar();
                if ($ok) {
                    if (!(int) get_option('ecsc_seeded', 0)) {
                        Ecsc_Sync::empezar();
                        Ecsc_Sync::enviarCatalogo(15);
                    }
                    self::avisar(__('Connected. The content is being sent and continues on its own in the background.', 'ecom_seoconnect_wp'));
                } else {
                    /* translators: %s: error returned by the platform */
                    self::avisar(sprintf(__('Saved, but the connection failed: %s', 'ecom_seoconnect_wp'), $err), 'error');
                }
            }
        } elseif ($que === 'probar') {
            list($ok, $d, $err) = Ecsc_Sync::probar();
            /* translators: 1: site name in the panel, 2: plan name. In the second string, %s: error */
            self::avisar($ok ? sprintf(__('Connected: %1$s · plan %2$s.', 'ecom_seoconnect_wp'), isset($d['nombre']) ? $d['nombre'] : '', isset($d['plan']) ? $d['plan'] : '-')
                : sprintf(__('No connection: %s', 'ecom_seoconnect_wp'), $err), $ok ? 'success' : 'error');
        } elseif ($que === 'desconectar') {
            Ecsc_Client::desconectar();
            self::avisar(__('Site disconnected.', 'ecom_seoconnect_wp'));
        } elseif ($que === 'enviar') {
            $pestana = 'sincronizacion';
            if (!Ecsc_Client::conectado()) {
                self::avisar(__('Connect the site first.', 'ecom_seoconnect_wp'), 'error');
            } else {
                $p = Ecsc_Sync::progreso();
                if (empty($p['activo'])) {
                    Ecsc_Sync::empezar();
                }
                $fin = Ecsc_Sync::enviarCatalogo(20);
                $p = Ecsc_Sync::progreso();
                if (!empty($p['error'])) {
                    /* translators: %s: error */
                    self::avisar(sprintf(__('Error sending the content: %s', 'ecom_seoconnect_wp'), $p['error']), 'error');
                } else {
                    /* translators: 1: sent, 2: total */
                    self::avisar($fin ? __('Content sent completely.', 'ecom_seoconnect_wp')
                        : sprintf(__('Sent %1$d of %2$d. It continues in the background (or press again).', 'ecom_seoconnect_wp'), (int) $p['leidos'], (int) $p['total']));
                }
            }
        } elseif ($que === 'permisos') {
            $pestana = 'permisos';
            $perm = array();
            foreach (Ecsc_Fields::mapa() as $tipo => $campos) {
                foreach ($campos as $campo) {
                    $k = 'ecsc_p_' . $tipo . '_' . $campo;
                    $v = isset($_POST[$k]) ? sanitize_key(wp_unslash($_POST[$k])) : '';
                    if (in_array($v, Ecsc_Applier::modos(), true)) {
                        $perm[$tipo . '.' . $campo] = $v;
                    }
                }
            }
            update_option('ecsc_perms', wp_json_encode($perm), false);
            update_option('ecsc_kill', isset($_POST['ecsc_kill']) ? 1 : 0, false);
            update_option('ecsc_debug', isset($_POST['ecsc_debug']) ? 1 : 0, false);
            update_option('ecsc_daily_cap', isset($_POST['ecsc_daily_cap']) ? max(0, min(5000, absint(wp_unslash($_POST['ecsc_daily_cap'])))) : 50, false);
            if (Ecsc_Client::conectado()) {
                Ecsc_Sync::probar();   // la plataforma ve al momento los permisos nuevos
            }
            self::avisar(__('Settings saved.', 'ecom_seoconnect_wp'));
        } elseif ($que === 'deshacer') {
            $pestana = 'historial';
            $motivo = Ecsc_History::deshacer(isset($_POST['ecsc_id']) ? absint(wp_unslash($_POST['ecsc_id'])) : 0, !empty($_POST['ecsc_forzar']));
            if ($motivo === '') {
                self::avisar(__('Change undone. The panel will be told on the next run.', 'ecom_seoconnect_wp'));
            } elseif ($motivo === 'cambiado_despues') {
                self::avisar(__('The text has changed since then, so it has not been touched. Tick "even if it has changed" to force it.', 'ecom_seoconnect_wp'), 'error');
            } else {
                /* translators: %s: reason */
                self::avisar(sprintf(__('It could not be undone: %s', 'ecom_seoconnect_wp'), $motivo), 'error');
            }
        }
        wp_safe_redirect(self::url($pestana));
        exit;
    }

    private static function abrirFormulario($que)
    {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('ecsc_accion');
        echo '<input type="hidden" name="action" value="ecsc_accion"><input type="hidden" name="ecsc_que" value="' . esc_attr($que) . '">';
    }

    private static function etiquetas()
    {
        return array(
            'tipos' => array('cms' => __('Posts and pages', 'ecom_seoconnect_wp'), 'producto' => __('Products', 'ecom_seoconnect_wp'),
                'categoria' => __('Categories', 'ecom_seoconnect_wp'), 'marca' => __('Brands', 'ecom_seoconnect_wp')),
            'campos' => array('meta_title' => __('SEO title', 'ecom_seoconnect_wp'), 'meta_description' => __('Meta description', 'ecom_seoconnect_wp'),
                'name' => __('Name', 'ecom_seoconnect_wp'), 'description_short' => __('Short description', 'ecom_seoconnect_wp'),
                'description' => __('Description', 'ecom_seoconnect_wp'), 'content' => __('Content', 'ecom_seoconnect_wp'),
                'legend' => __('Image alternative text', 'ecom_seoconnect_wp'), 'tags' => __('Tags', 'ecom_seoconnect_wp'), 'link_rewrite' => __('URL slug', 'ecom_seoconnect_wp')),
            'modos' => array('blocked' => __('Blocked', 'ecom_seoconnect_wp'), 'suggest' => __('Suggest only', 'ecom_seoconnect_wp'),
                'approve' => __('Apply with approval', 'ecom_seoconnect_wp'), 'auto' => __('Automatic', 'ecom_seoconnect_wp')),
        );
    }

    public static function pantalla()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $pestanas = array('conexion' => __('Connection', 'ecom_seoconnect_wp'), 'permisos' => __('Permissions', 'ecom_seoconnect_wp'),
            'sincronizacion' => __('Synchronisation', 'ecom_seoconnect_wp'), 'historial' => __('History', 'ecom_seoconnect_wp'));
        $actual = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'conexion';
        $actual = isset($pestanas[$actual]) ? $actual : 'conexion';
        echo '<div class="wrap"><h1>SEO IA Connect</h1>';
        $aviso = get_transient('ecsc_aviso_' . get_current_user_id());
        if (is_array($aviso)) {
            delete_transient('ecsc_aviso_' . get_current_user_id());
            echo '<div class="notice notice-' . esc_attr($aviso[0] === 'error' ? 'error' : 'success') . '"><p>' . esc_html($aviso[1]) . '</p></div>';
        }
        echo '<h2 class="nav-tab-wrapper">';
        foreach ($pestanas as $k => $nombre) {
            echo '<a class="nav-tab' . ($k === $actual ? ' nav-tab-active' : '') . '" href="' . esc_url(self::url($k)) . '">' . esc_html($nombre) . '</a>';
        }
        echo '</h2>';
        if ($actual === 'permisos') {
            self::pestanaPermisos();
        } elseif ($actual === 'sincronizacion') {
            self::pestanaSincronizacion();
        } elseif ($actual === 'historial') {
            self::pestanaHistorial();
        } else {
            self::pestanaConexion();
        }
        echo '</div>';
    }

    private static function pestanaConexion()
    {
        $conectado = Ecsc_Client::conectado();
        $e = json_decode((string) get_option('ecsc_estado', ''), true);
        $e = is_array($e) ? $e : array();
        if ($conectado) {
            echo '<p><strong>' . esc_html__('This site is connected.', 'ecom_seoconnect_wp') . '</strong> ';
            if (!empty($e['nombre'])) {
                /* translators: 1: site name in the panel, 2: plan, 3: date of the last check */
                echo esc_html(sprintf(__('Panel: %1$s · plan %2$s · checked on %3$s.', 'ecom_seoconnect_wp'), $e['nombre'], isset($e['plan']) && $e['plan'] !== '' ? $e['plan'] : '-', isset($e['fecha']) ? $e['fecha'] : '-'));
            }
            echo '</p>';
            if (!empty($e['panel'])) {
                echo '<p><a class="button" href="' . esc_url($e['panel']) . '" target="_blank" rel="noopener">' . esc_html__('Open the panel', 'ecom_seoconnect_wp') . '</a></p>';
            }
        } else {
            echo '<p>' . esc_html__('Paste the connection key that your SEO IA panel shows when you add this site.', 'ecom_seoconnect_wp') . '</p>';
        }
        self::abrirFormulario('conectar');
        echo '<table class="form-table" role="presentation"><tr><th scope="row"><label for="ecsc_clave">' . esc_html__('Connection key', 'ecom_seoconnect_wp') . '</label></th>';
        echo '<td><input type="password" class="regular-text" id="ecsc_clave" name="ecsc_clave" autocomplete="off" placeholder="SEOIA1.…" required>';
        echo '<p class="description">' . esc_html__('It is not shown again once saved. To change it, paste the new one.', 'ecom_seoconnect_wp') . '</p></td></tr></table>';
        submit_button($conectado ? __('Save and connect again', 'ecom_seoconnect_wp') : __('Save and connect', 'ecom_seoconnect_wp'));
        echo '</form>';
        if ($conectado) {
            echo '<p>';
            self::abrirFormulario('probar');
            submit_button(__('Test connection', 'ecom_seoconnect_wp'), 'secondary', 'submit', false);
            echo '</form> ';
            self::abrirFormulario('desconectar');
            submit_button(__('Disconnect', 'ecom_seoconnect_wp'), 'delete', 'submit', false);
            echo '</form></p>';
        }
        /* translators: %s: name of the SEO plugin or "this plugin" */
        echo '<p class="description">' . esc_html(sprintf(__('SEO titles and descriptions are stored by: %s.', 'ecom_seoconnect_wp'),
            Ecsc_Fields::seo() === 'yoast' ? 'Yoast SEO' : (Ecsc_Fields::seo() === 'rankmath' ? 'Rank Math' : __('this plugin', 'ecom_seoconnect_wp')))) . '</p>';
    }

    private static function pestanaPermisos()
    {
        $et = self::etiquetas();
        $perm = Ecsc_Applier::permisos();
        echo '<p>' . esc_html__('Decide what the panel may change in this site, field by field. Only this screen can change it.', 'ecom_seoconnect_wp') . '</p>';
        self::abrirFormulario('permisos');
        echo '<table class="widefat striped" style="max-width:760px"><thead><tr><th>' . esc_html__('Content', 'ecom_seoconnect_wp') . '</th><th>' . esc_html__('Field', 'ecom_seoconnect_wp') . '</th><th>' . esc_html__('Permission', 'ecom_seoconnect_wp') . '</th></tr></thead><tbody>';
        foreach (Ecsc_Fields::mapa() as $tipo => $campos) {
            foreach ($campos as $campo) {
                echo '<tr><td>' . esc_html(isset($et['tipos'][$tipo]) ? $et['tipos'][$tipo] : $tipo) . '</td><td>' . esc_html(isset($et['campos'][$campo]) ? $et['campos'][$campo] : $campo) . '</td><td>';
                echo '<select name="' . esc_attr('ecsc_p_' . $tipo . '_' . $campo) . '">';
                foreach ($et['modos'] as $modo => $nombre) {
                    echo '<option value="' . esc_attr($modo) . '"' . selected($perm[$tipo . '.' . $campo], $modo, false) . '>' . esc_html($nombre) . '</option>';
                }
                echo '</select></td></tr>';
            }
        }
        echo '</tbody></table>';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="ecsc_daily_cap">' . esc_html__('Changes per day, at most', 'ecom_seoconnect_wp') . '</label></th><td><input type="number" min="0" max="5000" class="small-text" id="ecsc_daily_cap" name="ecsc_daily_cap" value="' . esc_attr((int) get_option('ecsc_daily_cap', 50)) . '"> <span class="description">' . esc_html__('0 = no limit.', 'ecom_seoconnect_wp') . '</span></td></tr>';
        echo '<tr><th scope="row">' . esc_html__('Emergency stop', 'ecom_seoconnect_wp') . '</th><td><label><input type="checkbox" name="ecsc_kill" value="1"' . checked((int) get_option('ecsc_kill', 0), 1, false) . '> ' . esc_html__('Do not apply anything, whatever the permissions say.', 'ecom_seoconnect_wp') . '</label></td></tr>';
        echo '<tr><th scope="row">' . esc_html__('Debug log', 'ecom_seoconnect_wp') . '</th><td><label><input type="checkbox" name="ecsc_debug" value="1"' . checked((int) get_option('ecsc_debug', 0), 1, false) . '> ' . esc_html__('Write every step to the log (errors are always written).', 'ecom_seoconnect_wp') . '</label></td></tr>';
        echo '</table>';
        submit_button(__('Save', 'ecom_seoconnect_wp'));
        echo '</form>';
    }

    private static function pestanaSincronizacion()
    {
        $p = Ecsc_Sync::progreso();
        echo '<table class="form-table" role="presentation">';
        if (!empty($p['activo'])) {
            /* translators: 1: sent, 2: total */
            echo '<tr><th scope="row">' . esc_html__('Full send', 'ecom_seoconnect_wp') . '</th><td>' . esc_html(sprintf(__('In progress: %1$d of %2$d.', 'ecom_seoconnect_wp'), (int) $p['leidos'], (int) $p['total']));
            if (!empty($p['error'])) {
                echo ' <span style="color:#b32d2e">' . esc_html($p['error']) . '</span>';
            }
            echo '</td></tr>';
        } elseif (!empty($p['terminado'])) {
            /* translators: 1: date, 2: number of items */
            echo '<tr><th scope="row">' . esc_html__('Full send', 'ecom_seoconnect_wp') . '</th><td>' . esc_html(sprintf(__('Last one: %1$s (%2$d items).', 'ecom_seoconnect_wp'), $p['terminado'], (int) $p['leidos'])) . '</td></tr>';
        }
        echo '<tr><th scope="row">' . esc_html__('Changes waiting to be sent', 'ecom_seoconnect_wp') . '</th><td>' . esc_html((string) Ecsc_Sync::pendientes()) . '</td></tr>';
        echo '<tr><th scope="row">' . esc_html__('Last time approved improvements were fetched', 'ecom_seoconnect_wp') . '</th><td>' . esc_html((string) get_option('ecsc_ultimo_tiron', '-')) . '</td></tr>';
        $siguiente = wp_next_scheduled('ecsc_trabajo');
        echo '<tr><th scope="row">' . esc_html__('Next automatic run', 'ecom_seoconnect_wp') . '</th><td>' . esc_html($siguiente ? wp_date('Y-m-d H:i:s', $siguiente) : '-') . '</td></tr>';
        echo '</table>';
        echo '<p class="description">' . esc_html__('The plugin works on its own every 5 minutes with the WordPress scheduler, which only runs when the site has visits. On a site with little traffic, call wp-cron.php from a real cron.', 'ecom_seoconnect_wp') . '</p>';
        self::abrirFormulario('enviar');
        submit_button(__('Send the content now', 'ecom_seoconnect_wp'), 'secondary');
        echo '</form>';
        $lineas = Ecsc_Log::ultimas(25);
        if ($lineas) {
            echo '<h2>' . esc_html__('Log', 'ecom_seoconnect_wp') . '</h2><pre style="max-height:260px;overflow:auto;background:#fff;border:1px solid #c3c4c7;padding:8px">' . esc_html(implode("\n", $lineas)) . '</pre>';
        }
    }

    private static function pestanaHistorial()
    {
        $et = self::etiquetas();
        $filas = Ecsc_History::lista(50);
        if (!$filas) {
            echo '<p>' . esc_html__('Nothing has been applied yet.', 'ecom_seoconnect_wp') . '</p>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Date', 'ecom_seoconnect_wp') . '</th><th>' . esc_html__('Content', 'ecom_seoconnect_wp') . '</th><th>' . esc_html__('Field', 'ecom_seoconnect_wp') . '</th><th>' . esc_html__('Before', 'ecom_seoconnect_wp') . '</th><th>' . esc_html__('After', 'ecom_seoconnect_wp') . '</th><th></th></tr></thead><tbody>';
        foreach ($filas as $h) {
            $titulo = in_array($h['tipo'], array('categoria', 'marca'), true) ? get_term_field('name', (int) $h['id_elemento']) : get_the_title((int) $h['id_elemento']);
            echo '<tr><td>' . esc_html($h['fecha']) . '</td><td>' . esc_html((isset($et['tipos'][$h['tipo']]) ? $et['tipos'][$h['tipo']] : $h['tipo']) . ' · ' . (is_string($titulo) && $titulo !== '' ? $titulo : '#' . (int) $h['id_elemento'])) . '</td>';
            echo '<td>' . esc_html(isset($et['campos'][$h['campo']]) ? $et['campos'][$h['campo']] : $h['campo']) . '</td>';
            echo '<td>' . esc_html(wp_html_excerpt(wp_strip_all_tags((string) $h['valor_anterior']), 140, '…')) . '</td><td>' . esc_html(wp_html_excerpt(wp_strip_all_tags((string) $h['valor_nuevo']), 140, '…')) . '</td><td>';
            if ((int) $h['deshecho']) {
                echo esc_html__('Undone', 'ecom_seoconnect_wp');
            } else {
                self::abrirFormulario('deshacer');
                echo '<input type="hidden" name="ecsc_id" value="' . esc_attr((int) $h['id']) . '">';
                submit_button(__('Undo', 'ecom_seoconnect_wp'), 'small', 'submit', false);
                echo ' <label><input type="checkbox" name="ecsc_forzar" value="1"> ' . esc_html__('even if it has changed', 'ecom_seoconnect_wp') . '</label></form>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
    }
}
