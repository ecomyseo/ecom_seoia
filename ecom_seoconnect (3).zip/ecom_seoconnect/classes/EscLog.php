<?php
/**
 * Ecom SEO Connect - registro en logs/ (errores siempre; el resto solo con la depuracion activada).
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscLog
{
    public static function escribir($msg, $siempre = false)
    {
        if (!$siempre && !(int) Configuration::getGlobalValue('ECOMSEOCONNECT_DEBUG')) {
            return;
        }
        $dir = _PS_MODULE_DIR_ . 'ecom_seoconnect/logs';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        @file_put_contents($dir . '/esc-' . date('Y-m') . '.log', '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
    }

    public static function error($msg)
    {
        self::escribir('ERROR ' . $msg, true);
    }

    /** Ultimas lineas del registro, para la pantalla del modulo. */
    public static function ultimas($n = 60)
    {
        $f = _PS_MODULE_DIR_ . 'ecom_seoconnect/logs/esc-' . date('Y-m') . '.log';
        if (!is_file($f)) {
            return array();
        }
        $lineas = @file($f, FILE_IGNORE_NEW_LINES);
        return is_array($lineas) ? array_reverse(array_slice($lineas, -$n)) : array();
    }
}
