<?php
/**
 * Ecom SEO Connect - cola local de elementos cambiados. Los hooks SOLO encolan (una consulta):
 * guardar un producto nunca espera a la plataforma.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscQueue
{
    /** @var array|null tiendas conectadas (cache por peticion) */
    private static $tiendas = null;

    public static function tiendasConectadas()
    {
        if (self::$tiendas === null) {
            self::$tiendas = array();
            foreach (Shop::getShops(false, null, true) as $idShop) {
                if (EscClient::conectado((int) $idShop)) {
                    self::$tiendas[] = (int) $idShop;
                }
            }
        }
        return self::$tiendas;
    }

    public static function olvidar()
    {
        self::$tiendas = null;
    }

    public static function poner($tipo, $id)
    {
        if (!in_array($tipo, array('producto', 'categoria', 'marca', 'cms'), true) || (int) $id <= 0) {
            return;
        }
        foreach (self::tiendasConectadas() as $idShop) {
            Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . 'ecomseoconnect_queue` (`id_shop`, `tipo`, `id_elemento`, `fecha`)
                VALUES (' . (int) $idShop . ', \'' . pSQL($tipo) . '\', ' . (int) $id . ', \'' . pSQL(date('Y-m-d H:i:s')) . '\')
                ON DUPLICATE KEY UPDATE `fecha` = VALUES(`fecha`)');
        }
    }

    public static function sacar($idShop, $limite = 100)
    {
        $f = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'ecomseoconnect_queue` WHERE `id_shop` = ' . (int) $idShop . ' ORDER BY `id_queue` ASC LIMIT ' . (int) $limite);
        return is_array($f) ? $f : array();
    }

    public static function quitar(array $ids)
    {
        $ids = array_map('intval', $ids);
        if ($ids) {
            Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . 'ecomseoconnect_queue` WHERE `id_queue` IN (' . implode(',', $ids) . ')');
        }
    }

    public static function pendientes($idShop)
    {
        return (int) Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'ecomseoconnect_queue` WHERE `id_shop` = ' . (int) $idShop);
    }
}
