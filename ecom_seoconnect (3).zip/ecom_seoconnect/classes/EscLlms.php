<?php
/**
 * Ecom SEO Connect - llms.txt (especificacion 009): resumen de la tienda para los buscadores con IA.
 *
 *  - apagado por defecto; una sola opcion global (el fichero esta en la raiz y es uno para toda la instalacion);
 *  - el contenido sale de la tienda por defecto;
 *  - NUNCA pisa un llms.txt que no haya escrito el modulo (se compara su huella);
 *  - se rehace una vez por semana y se borra al apagarlo o al desinstalar, solo si es suyo.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscLlms
{
    public static function fichero()
    {
        return rtrim(defined('_PS_ROOT_DIR_') ? _PS_ROOT_DIR_ : dirname(_PS_MODULE_DIR_), '/\\') . '/llms.txt';
    }

    public static function activo()
    {
        return (int) Configuration::getGlobalValue('ECOMSEOCONNECT_LLMS') === 1;
    }

    /** ¿El llms.txt que hay es el que escribio el modulo? */
    public static function esNuestro()
    {
        $f = self::fichero();
        $h = (string) Configuration::getGlobalValue('ECOMSEOCONNECT_LLMS_HASH');
        return is_file($f) && $h !== '' && sha1((string) @file_get_contents($f)) === $h;
    }

    /** Estado para la pantalla: 'nuestro', 'ajeno' o 'ninguno'. */
    public static function estado()
    {
        if (!is_file(self::fichero())) {
            return 'ninguno';
        }
        return self::esNuestro() ? 'nuestro' : 'ajeno';
    }

    /** Escribe el fichero. Devuelve '' si ha ido bien, 'ajeno' o 'no_escribible'. */
    public static function generar()
    {
        $f = self::fichero();
        if (is_file($f) && !self::esNuestro()) {
            return 'ajeno';
        }
        $txt = self::contenido();
        if (@file_put_contents($f, $txt) === false) {
            return 'no_escribible';
        }
        Configuration::updateGlobalValue('ECOMSEOCONNECT_LLMS_HASH', sha1($txt));
        Configuration::updateGlobalValue('ECOMSEOCONNECT_LLMS_FECHA', time());
        return '';
    }

    public static function borrar()
    {
        if (self::esNuestro()) {
            @unlink(self::fichero());
        }
        Configuration::updateGlobalValue('ECOMSEOCONNECT_LLMS_HASH', '');
    }

    /** Lo llama la pasada del modulo: rehace el fichero si toca (una vez por semana). */
    public static function semanal()
    {
        if (self::activo() && (int) Configuration::getGlobalValue('ECOMSEOCONNECT_LLMS_FECHA') < time() - 7 * 86400) {
            self::generar();
        }
    }

    private static function limpio($s, $max = 0)
    {
        $s = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string) $s), ENT_QUOTES, 'UTF-8')));
        $s = str_replace(array('[', ']'), array('(', ')'), $s);
        return $max > 0 && mb_strlen($s) > $max ? rtrim(mb_substr($s, 0, $max - 1)) . '…' : $s;
    }

    /** Encabezados en el idioma de la tienda (el fichero es para leerlo, no se traduce con el back-office). */
    private static function titulos($iso)
    {
        $t = array(
            'es' => array('Categorías', 'Productos', 'Información'),
            'ca' => array('Categories', 'Productes', 'Informació'),
            'gl' => array('Categorías', 'Produtos', 'Información'),
            'fr' => array('Catégories', 'Produits', 'Informations'),
            'it' => array('Categorie', 'Prodotti', 'Informazioni'),
            'pt' => array('Categorias', 'Produtos', 'Informação'),
            'de' => array('Kategorien', 'Produkte', 'Informationen'),
            'nl' => array('Categorieën', 'Producten', 'Informatie'),
        );
        $iso = strtolower(substr($iso, 0, 2));
        return isset($t[$iso]) ? $t[$iso] : array('Categories', 'Products', 'Information');
    }

    public static function contenido()
    {
        $db = Db::getInstance();
        $idShop = (int) Configuration::get('PS_SHOP_DEFAULT');
        $idLang = (int) Configuration::get('PS_LANG_DEFAULT', null, null, $idShop);
        $link = new Link();
        $nombre = self::limpio(Configuration::get('PS_SHOP_NAME', null, null, $idShop));
        $meta = Meta::getMetaByPage('index', $idLang);
        $resumen = is_array($meta) && !empty($meta['description']) ? self::limpio($meta['description'], 300) : $nombre;
        $l = array('# ' . $nombre, '', '> ' . $resumen, '');
        $titulos = self::titulos((string) Language::getIsoById($idLang));

        $raiz = (int) Configuration::get('PS_HOME_CATEGORY', null, null, $idShop);
        $cats = $db->executeS('SELECT c.`id_category`, cl.`name`, cl.`meta_description` FROM `' . _DB_PREFIX_ . 'category` c
            INNER JOIN `' . _DB_PREFIX_ . 'category_shop` cs ON cs.`id_category` = c.`id_category` AND cs.`id_shop` = ' . $idShop . '
            INNER JOIN `' . _DB_PREFIX_ . 'category_lang` cl ON cl.`id_category` = c.`id_category` AND cl.`id_lang` = ' . $idLang . ' AND cl.`id_shop` = ' . $idShop . '
            WHERE c.`active` = 1 AND c.`id_parent` = ' . $raiz . ' ORDER BY cs.`position` ASC LIMIT 30');
        $cats = is_array($cats) ? $cats : array();
        if ($cats) {
            $l[] = '## ' . $titulos[0];
            $l[] = '';
            foreach ($cats as $c) {
                $l[] = '- [' . self::limpio($c['name']) . '](' . $link->getCategoryLink((int) $c['id_category'], null, $idLang, null, $idShop) . ')'
                    . (self::limpio($c['meta_description']) !== '' ? ': ' . self::limpio($c['meta_description'], 160) : '');
            }
            $l[] = '';
        }

        $prods = $db->executeS('SELECT p.`id_product`, pl.`name`, pl.`description_short` FROM `' . _DB_PREFIX_ . 'product` p
            INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON ps.`id_product` = p.`id_product` AND ps.`id_shop` = ' . $idShop . '
            INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON pl.`id_product` = p.`id_product` AND pl.`id_lang` = ' . $idLang . ' AND pl.`id_shop` = ' . $idShop . '
            WHERE ps.`active` = 1 AND ps.`visibility` IN (\'both\', \'catalog\') ORDER BY ps.`date_add` DESC LIMIT 50');
        $prods = is_array($prods) ? $prods : array();
        if ($prods) {
            $l[] = '## ' . $titulos[1];
            $l[] = '';
            foreach ($prods as $p) {
                $corta = self::limpio($p['description_short'], 160);
                $l[] = '- [' . self::limpio($p['name']) . '](' . $link->getProductLink((int) $p['id_product'], null, null, null, $idLang, $idShop) . ')' . ($corta !== '' ? ': ' . $corta : '');
            }
            $l[] = '';
        }

        $cms = $db->executeS('SELECT c.`id_cms`, cl.`meta_title` FROM `' . _DB_PREFIX_ . 'cms` c
            INNER JOIN `' . _DB_PREFIX_ . 'cms_shop` cs ON cs.`id_cms` = c.`id_cms` AND cs.`id_shop` = ' . $idShop . '
            INNER JOIN `' . _DB_PREFIX_ . 'cms_lang` cl ON cl.`id_cms` = c.`id_cms` AND cl.`id_lang` = ' . $idLang . ' AND cl.`id_shop` = ' . $idShop . '
            WHERE c.`active` = 1 AND c.`indexation` = 1 ORDER BY c.`position` ASC LIMIT 20');
        $cms = is_array($cms) ? $cms : array();
        if ($cms) {
            $l[] = '## ' . $titulos[2];
            $l[] = '';
            foreach ($cms as $c) {
                $l[] = '- [' . self::limpio($c['meta_title']) . '](' . $link->getCMSLink((int) $c['id_cms'], null, null, $idLang, $idShop) . ')';
            }
            $l[] = '';
        }
        return implode("\n", $l);
    }
}
