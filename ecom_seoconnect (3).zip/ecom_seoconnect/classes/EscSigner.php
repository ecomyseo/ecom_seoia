<?php
/**
 * Ecom SEO Connect - firma HMAC de las peticiones. Gemelo de SeoSigner (plataforma).
 * firma = HMAC-SHA256(secreto, METODO \n RUTA \n MARCA_TIEMPO \n NONCE \n sha256(cuerpo)) en hex
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscSigner
{
    const DESFASE = 300;

    public static function firmar($secreto, $metodo, $ruta, $ts, $nonce, $cuerpo)
    {
        $base = strtoupper((string) $metodo) . "\n" . $ruta . "\n" . $ts . "\n" . $nonce . "\n" . hash('sha256', (string) $cuerpo);
        return hash_hmac('sha256', $base, $secreto);
    }

    public static function cabeceras($idSitio, $secreto, $ruta, $cuerpo)
    {
        $ts = (string) time();
        $nonce = bin2hex(random_bytes(16));
        return array(
            'X-Seo-Site: ' . (int) $idSitio,
            'X-Seo-Ts: ' . $ts,
            'X-Seo-Nonce: ' . $nonce,
            'X-Seo-Sign: ' . self::firmar($secreto, 'POST', $ruta, $ts, $nonce, $cuerpo),
        );
    }

    /** Comprueba cabeceras firmadas (de una respuesta o de un «toque»). */
    public static function valida($secreto, $idSitioEsperado, $ruta, $cuerpo, $idSitio, $ts, $nonce, $firma)
    {
        if ($secreto === '' || !ctype_digit((string) $ts) || abs(time() - (int) $ts) > self::DESFASE) {
            return false;
        }
        if (!preg_match('/^[a-f0-9]{16,64}$/', (string) $nonce) || !preg_match('/^[a-f0-9]{64}$/', (string) $firma)) {
            return false;
        }
        if ((int) $idSitio !== (int) $idSitioEsperado || (int) $idSitioEsperado <= 0) {
            return false;
        }
        return hash_equals(self::firmar($secreto, 'POST', $ruta, $ts, $nonce, $cuerpo), (string) $firma);
    }
}
