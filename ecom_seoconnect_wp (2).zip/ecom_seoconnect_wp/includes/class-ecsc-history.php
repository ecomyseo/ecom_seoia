<?php
/**
 * SEO IA Connect - historial de lo que el plugin ha cambiado en la web, y deshacer.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_History
{
    private static function tabla()
    {
        global $wpdb;
        return $wpdb->prefix . 'ecsc_history';
    }

    public static function anotar($tipo, $idElemento, $campo, $idSub, $anterior, $nuevo, $idPropuesta, $modo)
    {
        global $wpdb;
        return (bool) $wpdb->insert(self::tabla(), array(
            'tipo' => (string) $tipo,
            'id_elemento' => (int) $idElemento,
            'campo' => (string) $campo,
            'id_sub' => $idSub === null ? 0 : (int) $idSub,
            'valor_anterior' => (string) $anterior,
            'valor_nuevo' => (string) $nuevo,
            'id_propuesta' => (int) $idPropuesta,
            'modo' => (string) $modo,
            'fecha' => current_time('mysql'),
            'deshecho' => 0,
            'reportado' => 1,
        ));
    }

    public static function lista($limite = 50, $offset = 0)
    {
        global $wpdb;
        $f = $wpdb->get_results($wpdb->prepare('SELECT * FROM ' . self::tabla() . ' ORDER BY id DESC LIMIT %d, %d', (int) $offset, (int) $limite), ARRAY_A);
        return is_array($f) ? $f : array();
    }

    public static function total()
    {
        global $wpdb;
        return (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . self::tabla());
    }

    public static function aplicadosHoy()
    {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . self::tabla() . ' WHERE fecha >= %s', current_time('Y-m-d') . ' 00:00:00'));
    }

    /** Devuelve '' si se ha deshecho; si no, el motivo. */
    public static function deshacer($id, $forzar = false)
    {
        global $wpdb;
        $h = $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::tabla() . ' WHERE id = %d', (int) $id), ARRAY_A);
        if (!$h) {
            return 'no_existe';
        }
        if ((int) $h['deshecho']) {
            return 'ya_deshecho';
        }
        $idSub = (int) $h['id_sub'] ?: null;
        $actual = Ecsc_Fields::leer($h['tipo'], $h['campo'], (int) $h['id_elemento'], $idSub);
        if ($actual === null) {
            return 'el_elemento_ya_no_existe';
        }
        if (!$forzar && $actual !== (string) $h['valor_nuevo']) {
            return 'cambiado_despues';
        }
        if (!Ecsc_Fields::escribir($h['tipo'], $h['campo'], (int) $h['id_elemento'], (string) $h['valor_anterior'], $idSub)) {
            return 'error_al_guardar';
        }
        $wpdb->update(self::tabla(), array('deshecho' => 1, 'reportado' => 0), array('id' => (int) $id));
        Ecsc_Log::escribir('Deshecho #' . (int) $id . ' (propuesta ' . (int) $h['id_propuesta'] . ')');
        return '';
    }

    /** Deshechos en la web que la plataforma todavía no sabe. */
    public static function pendientesDeInformar()
    {
        global $wpdb;
        $f = $wpdb->get_results('SELECT * FROM ' . self::tabla() . ' WHERE deshecho = 1 AND reportado = 0 ORDER BY id ASC LIMIT 200', ARRAY_A);
        return is_array($f) ? $f : array();
    }

    public static function marcarInformados(array $ids)
    {
        global $wpdb;
        $ids = array_filter(array_map('intval', $ids));
        if ($ids) {
            $wpdb->query('UPDATE ' . self::tabla() . ' SET reportado = 1 WHERE id IN (' . implode(',', $ids) . ')');
        }
    }
}
