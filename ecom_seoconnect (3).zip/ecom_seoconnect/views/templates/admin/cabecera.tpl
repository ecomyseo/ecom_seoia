{**
 * Ecom SEO Connect - cabecera de la configuracion: solo lo importante.
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 *}
{if $esc_kill}
    <div class="alert alert-danger">{l s='The total stop switch is ON: no change will be applied.' d='Modules.Ecomseoconnect.Admin'}</div>
{/if}
{if !$esc_conectado}
    <div class="alert alert-info">{l s='Paste the connection key from the panel in the «Connection» tab and save.' d='Modules.Ecomseoconnect.Admin'}</div>
{elseif isset($esc_estado.nivel) && $esc_estado.nivel == 'lectura'}
    <div class="alert alert-warning">{l s='Your subscription is suspended: nothing is generated or applied until it is renewed.' d='Modules.Ecomseoconnect.Admin'}</div>
{elseif isset($esc_estado.nivel) && $esc_estado.nivel == 'ninguno'}
    <div class="alert alert-warning">{l s='Your account has no active plan.' d='Modules.Ecomseoconnect.Admin'}</div>
{/if}
<div class="panel esc-botonera">
    <a class="btn btn-default" href="{$esc_admin|escape:'html':'UTF-8'}"><i class="icon-list"></i> {l s='History and undo' d='Modules.Ecomseoconnect.Admin'}</a>
    {if isset($esc_estado.panel) && $esc_estado.panel}
        <a class="btn btn-default" href="{$esc_estado.panel|escape:'html':'UTF-8'}" target="_blank" rel="noopener noreferrer"><i class="icon-external-link"></i> {l s='Open the SEO panel' d='Modules.Ecomseoconnect.Admin'}</a>
    {/if}
    <p class="help-block">{l s='History: every change applied, with its undo button. Panel: diagnosis, AI improvements and approval.' d='Modules.Ecomseoconnect.Admin'}</p>
</div>
