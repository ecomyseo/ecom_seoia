<?php
/**
 * SEO IA Connect - conexión con la plataforma: clave de conexión y llamadas firmadas.
 * La web tira; la plataforma no empuja.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_Client
{
    public static function conectado()
    {
        return (string) get_option('ecsc_url', '') !== '' && (int) get_option('ecsc_site_id', 0) > 0 && (string) get_option('ecsc_secret', '') !== '';
    }

    /** Descifra la clave de conexión «SEOIA1.xxxx». Devuelve array(url, id_sitio, secreto) o null. */
    public static function leerClave($clave)
    {
        $clave = trim((string) $clave);
        if (strpos($clave, 'SEOIA1.') !== 0) {
            return null;
        }
        $b = strtr(substr($clave, 7), '-_', '+/');
        $j = json_decode((string) base64_decode($b . str_repeat('=', (4 - strlen($b) % 4) % 4), true), true);
        if (!is_array($j) || empty($j['u']) || empty($j['s']) || empty($j['k'])) {
            return null;
        }
        if (!preg_match('#^https?://[^\s]+$#i', (string) $j['u']) || !preg_match('/^[a-f0-9]{64}$/', (string) $j['k'])) {
            return null;
        }
        return array(rtrim((string) $j['u'], '/'), (int) $j['s'], (string) $j['k']);
    }

    public static function conectar($clave)
    {
        $c = self::leerClave($clave);
        if (!$c) {
            return false;
        }
        update_option('ecsc_url', $c[0], false);
        update_option('ecsc_site_id', $c[1], false);
        update_option('ecsc_secret', $c[2], false);
        return true;
    }

    public static function desconectar()
    {
        foreach (array('ecsc_url', 'ecsc_site_id', 'ecsc_secret', 'ecsc_estado', 'ecsc_sync', 'ecsc_seeded', 'ecsc_ultima_completa') as $k) {
            delete_option($k);
        }
    }

    /**
     * Llamada firmada a /api/v1/<accion>.
     * @return array [ok, datos, error, codigo]
     */
    public static function llamar($accion, array $datos, $timeout = 30)
    {
        if (!self::conectado()) {
            return array(false, array(), 'no_conectado', 0);
        }
        $ruta = '/api/v1/' . $accion;
        $idSitio = (int) get_option('ecsc_site_id', 0);
        $secreto = (string) get_option('ecsc_secret', '');
        $cuerpo = wp_json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
        $cab = array_merge(array('Content-Type' => 'application/json', 'Accept' => 'application/json'), Ecsc_Signer::cabeceras($idSitio, $secreto, $ruta, $cuerpo));
        $resp = wp_remote_post(rtrim((string) get_option('ecsc_url', ''), '/') . $ruta, array(
            'headers' => $cab,
            'body' => $cuerpo,
            'timeout' => (int) $timeout,
            'redirection' => 0,
            'user-agent' => 'EcomSeoConnectWP/' . ECSC_VERSION . ' WordPress/' . get_bloginfo('version'),
        ));
        if (is_wp_error($resp)) {
            Ecsc_Log::error('Plataforma ' . $accion . ': ' . $resp->get_error_message());
            return array(false, array(), 'red: ' . $resp->get_error_message(), 0);
        }
        $codigo = (int) wp_remote_retrieve_response_code($resp);
        $crudo = (string) wp_remote_retrieve_body($resp);
        $d = json_decode($crudo, true);
        $d = is_array($d) ? $d : array();
        if ($codigo === 401 || $codigo === 429) {
            $motivo = isset($d['motivo']) ? $d['motivo'] : (isset($d['error']) ? $d['error'] : 'http_' . $codigo);
            Ecsc_Log::error('Plataforma ' . $accion . ' rechazada: ' . $motivo);
            return array(false, $d, (string) $motivo, $codigo);
        }
        $firmada = Ecsc_Signer::valida($secreto, $idSitio, $ruta, $crudo,
            (string) wp_remote_retrieve_header($resp, 'x-seo-site'), (string) wp_remote_retrieve_header($resp, 'x-seo-ts'),
            (string) wp_remote_retrieve_header($resp, 'x-seo-nonce'), (string) wp_remote_retrieve_header($resp, 'x-seo-sign'));
        if (!$firmada) {
            Ecsc_Log::error('Respuesta de ' . $accion . ' SIN firma válida (HTTP ' . $codigo . '): se ignora');
            return array(false, array(), 'respuesta_sin_firma', $codigo);
        }
        Ecsc_Log::escribir('Plataforma ' . $accion . ' -> ' . $codigo);
        return array($codigo >= 200 && $codigo < 300 && !empty($d['ok']), $d, isset($d['error']) ? (string) $d['error'] : '', $codigo);
    }
}
