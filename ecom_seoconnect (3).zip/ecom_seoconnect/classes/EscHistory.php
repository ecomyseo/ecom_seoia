<?php
/**
 * Ecom SEO Connect - historial de cambios y DESHACER (el valor vuelve exactamente al anterior).
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscHistory
{
    public static function lista($idShop, $limite = 100, $offset = 0)
    {
        $filas = Db::getInstance()->executeS('SELECT h.*, l.`iso_code` FROM `' . _DB_PREFIX_ . 'ecomseoconnect_history` h
            LEFT JOIN `' . _DB_PREFIX_ . 'lang` l ON l.`id_lang` = h.`id_lang`
            WHERE h.`id_shop` = ' . (int) $idShop . ' ORDER BY h.`id_history` DESC LIMIT ' . (int) $offset . ', ' . (int) $limite);
        return is_array($filas) ? $filas : array();
    }

    public static function total($idShop)
    {
        return (int) Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'ecomseoconnect_history` WHERE `id_shop` = ' . (int) $idShop);
    }

    /**
     * Deshace un cambio. Si el campo ya no tiene el valor que puso el modulo (alguien lo cambio despues),
     * no lo pisa salvo que se fuerce.
     * @return string '' si ha ido bien, o el motivo
     */
    public static function deshacer($idShop, $idHistory, $forzar = false)
    {
        $db = Db::getInstance();
        $h = $db->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ecomseoconnect_history` WHERE `id_history` = ' . (int) $idHistory . ' AND `id_shop` = ' . (int) $idShop);
        if (!$h) {
            return 'no_existe';
        }
        if ((int) $h['deshecho']) {
            return 'ya_deshecho';
        }
        $idSub = (int) $h['id_sub'] ?: null;
        $actual = EscFields::leer($h['tipo'], $h['campo'], (int) $h['id_elemento'], (int) $h['id_lang'], (int) $idShop, $idSub);
        if ($actual === null) {
            return 'el_elemento_ya_no_existe';
        }
        if (!$forzar && $actual !== (string) $h['valor_nuevo']) {
            return 'cambiado_despues';
        }
        if (!EscFields::escribir($h['tipo'], $h['campo'], (int) $h['id_elemento'], (int) $h['id_lang'], (int) $idShop, (string) $h['valor_anterior'], $idSub)) {
            return 'error_al_guardar';
        }
        $db->update('ecomseoconnect_history', array('deshecho' => 1, 'reportado' => 0), '`id_history` = ' . (int) $idHistory);
        EscFields::avisarNucleo($h['tipo'], (int) $h['id_elemento']);
        EscLog::escribir('Deshecho #' . $idHistory . ' (propuesta ' . $h['id_propuesta'] . ')');
        return '';
    }

    /** Deshace todo lo aplicado hoy en esta tienda. Devuelve [hechos, saltados]. */
    public static function deshacerHoy($idShop)
    {
        $ids = Db::getInstance()->executeS('SELECT `id_history` FROM `' . _DB_PREFIX_ . 'ecomseoconnect_history` WHERE `id_shop` = ' . (int) $idShop
            . ' AND `deshecho` = 0 AND `fecha` >= \'' . pSQL(date('Y-m-d 00:00:00')) . '\' ORDER BY `id_history` DESC');
        $hechos = 0;
        $saltados = 0;
        foreach (is_array($ids) ? $ids : array() as $f) {
            if (self::deshacer($idShop, (int) $f['id_history']) === '') {
                $hechos++;
            } else {
                $saltados++;
            }
        }
        Tools::clearSmartyCache();
        return array($hechos, $saltados);
    }

    /** Deshechos todavia sin contar a la plataforma. */
    public static function pendientesDeInformar($idShop)
    {
        $filas = Db::getInstance()->executeS('SELECT `id_history`, `id_propuesta` FROM `' . _DB_PREFIX_ . 'ecomseoconnect_history` WHERE `id_shop` = ' . (int) $idShop
            . ' AND `deshecho` = 1 AND `reportado` = 0 LIMIT 200');
        return is_array($filas) ? $filas : array();
    }

    public static function marcarInformados(array $ids)
    {
        $ids = array_map('intval', $ids);
        if ($ids) {
            Db::getInstance()->update('ecomseoconnect_history', array('reportado' => 1), '`id_history` IN (' . implode(',', $ids) . ')');
        }
    }
}
