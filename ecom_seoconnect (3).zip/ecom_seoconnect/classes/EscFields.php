<?php
/**
 * Ecom SEO Connect - LISTA CERRADA de campos que el modulo sabe leer y escribir.
 * Tiene que coincidir con SeoCampos de la plataforma. Cualquier otro campo se rechaza.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscFields
{
    /**
     * tipo => campo => [tabla _lang, columna, clase ObjectModel, por tienda]
     */
    public static function mapa()
    {
        return array(
            'producto' => array(
                'meta_title' => array('product_lang', 'meta_title', 'Product', true),
                'meta_description' => array('product_lang', 'meta_description', 'Product', true),
                'name' => array('product_lang', 'name', 'Product', true),
                'description_short' => array('product_lang', 'description_short', 'Product', true),
                'description' => array('product_lang', 'description', 'Product', true),
                'link_rewrite' => array('product_lang', 'link_rewrite', 'Product', true),
                'legend' => array('image_lang', 'legend', 'Image', false),
                'tags' => array('product_tag', 'tags', 'Tag', false),
                // Especificacion 017: redireccion de un producto desactivado (campos del nucleo, sin tabla propia).
                'redirect' => array('product_shop', 'redirect_type', 'Product', true),
            ),
            'categoria' => array(
                'meta_title' => array('category_lang', 'meta_title', 'Category', true),
                'meta_description' => array('category_lang', 'meta_description', 'Category', true),
                'description' => array('category_lang', 'description', 'Category', true),
                'link_rewrite' => array('category_lang', 'link_rewrite', 'Category', true),
            ),
            'marca' => array(
                'meta_title' => array('manufacturer_lang', 'meta_title', 'Manufacturer', false),
                'meta_description' => array('manufacturer_lang', 'meta_description', 'Manufacturer', false),
                'short_description' => array('manufacturer_lang', 'short_description', 'Manufacturer', false),
                'description' => array('manufacturer_lang', 'description', 'Manufacturer', false),
            ),
            'cms' => array(
                'meta_title' => array('cms_lang', 'meta_title', 'CMS', true),
                'meta_description' => array('cms_lang', 'meta_description', 'CMS', true),
                'content' => array('cms_lang', 'content', 'CMS', true),
            ),
        );
    }

    public static function existe($tipo, $campo)
    {
        $m = self::mapa();
        return isset($m[$tipo][$campo]);
    }

    public static function idCampo($tipo)
    {
        $ids = array('producto' => 'id_product', 'categoria' => 'id_category', 'marca' => 'id_manufacturer', 'cms' => 'id_cms');
        return $ids[$tipo];
    }

    /** ¿Deja la tienda cambiar URLs sin romper enlaces? Ruta con {id} y redireccion canonica 301. */
    public static function urlSegura($tipo, $idShop)
    {
        if ((int) Configuration::get('PS_CANONICAL_REDIRECT', null, null, $idShop) !== 2) {
            return false;
        }
        $ruta = $tipo === 'categoria' ? 'category_rule' : 'product_rule';
        $propia = (string) Configuration::get('PS_ROUTE_' . $ruta, null, null, $idShop);
        return $propia === '' || strpos($propia, '{id}') !== false;
    }

    /** Etiquetas de un producto en un idioma, siempre en el mismo orden (la huella tiene que ser estable). */
    public static function etiquetas($idProduct, $idLang)
    {
        $filas = Db::getInstance()->executeS('SELECT t.`name` FROM `' . _DB_PREFIX_ . 'product_tag` pt
            INNER JOIN `' . _DB_PREFIX_ . 'tag` t ON t.`id_tag` = pt.`id_tag`
            WHERE pt.`id_product` = ' . (int) $idProduct . ' AND pt.`id_lang` = ' . (int) $idLang . ' ORDER BY t.`name` ASC');
        $n = array();
        foreach (is_array($filas) ? $filas : array() as $f) {
            $n[] = (string) $f['name'];
        }
        return implode(', ', $n);
    }

    /** Valor ACTUAL en la base de datos, crudo (el mismo que se manda en la sincronizacion). */
    public static function leer($tipo, $campo, $id, $idLang, $idShop, $idSub = null)
    {
        $m = self::mapa();
        if (!isset($m[$tipo][$campo])) {
            return null;
        }
        list($tabla, $col, , $porTienda) = $m[$tipo][$campo];
        if ($campo === 'tags') {
            return self::etiquetas($id, $idLang);
        }
        if ($campo === 'redirect') {
            $f = Db::getInstance()->getRow('SELECT `redirect_type`, `id_type_redirected` FROM `' . _DB_PREFIX_ . 'product_shop` WHERE `id_product` = ' . (int) $id . ' AND `id_shop` = ' . (int) $idShop);
            return $f ? self::redireccion($f['redirect_type'], $f['id_type_redirected']) : null;
        }
        if ($campo === 'legend') {
            $ok = Db::getInstance()->getValue('SELECT 1 FROM `' . _DB_PREFIX_ . 'image` WHERE `id_image` = ' . (int) $idSub . ' AND `id_product` = ' . (int) $id);
            if (!$ok) {
                return null;
            }
            $v = Db::getInstance()->getValue('SELECT `legend` FROM `' . _DB_PREFIX_ . 'image_lang` WHERE `id_image` = ' . (int) $idSub . ' AND `id_lang` = ' . (int) $idLang);
            return $v === false ? '' : (string) $v;
        }
        $sql = 'SELECT `' . bqSQL($col) . '` FROM `' . _DB_PREFIX_ . bqSQL($tabla) . '` WHERE `' . self::idCampo($tipo) . '` = ' . (int) $id . ' AND `id_lang` = ' . (int) $idLang
            . ($porTienda ? ' AND `id_shop` = ' . (int) $idShop : '');
        $v = Db::getInstance()->getValue($sql);
        return $v === false ? null : (string) $v;
    }

    /** Valor del campo «redirect»: tipo:id, igual en la tienda y en la plataforma (sirve para la huella). */
    public static function redireccion($tipo, $id)
    {
        return (string) $tipo . ':' . (int) $id;
    }

    /** array(tipo, id) de un valor «redirect», o null si no es valido. */
    public static function partirRedireccion($valor)
    {
        if (preg_match('/^(301|302)-(category|product):(\d+)$/', (string) $valor, $m)) {
            return array($m[1] . '-' . $m[2], (int) $m[3]);
        }
        if (preg_match('/^(404|410|default|):0$/', (string) $valor, $m)) {
            return array($m[1], 0);
        }
        return null;
    }

    /** Valida con la definicion del ObjectModel del nucleo. Devuelve '' si vale o el motivo. */
    public static function validar($tipo, $campo, $valor)
    {
        if ($campo === 'redirect') {
            $r = self::partirRedireccion($valor);
            if (!$r) {
                return 'redireccion_no_valida';
            }
            if (strpos($r[0], 'category') !== false && $r[1] > 0 && !Db::getInstance()->getValue('SELECT 1 FROM `' . _DB_PREFIX_ . 'category` WHERE `id_category` = ' . (int) $r[1] . ' AND `active` = 1')) {
                return 'destino_no_existe';
            }
            if (strpos($r[0], 'product') !== false && !Db::getInstance()->getValue('SELECT 1 FROM `' . _DB_PREFIX_ . 'product` WHERE `id_product` = ' . (int) $r[1])) {
                return 'destino_no_existe';
            }
            return '';
        }
        $m = self::mapa();
        $clase = $m[$tipo][$campo][2];
        if ($campo === 'tags') {
            foreach (array_filter(array_map('trim', explode(',', $valor))) as $t) {
                if (!Validate::isGenericName($t) || Tools::strlen($t) > 32) {
                    return 'tag_no_valida';
                }
            }
            return '';
        }
        $def = isset($clase::$definition['fields'][$campo]) ? $clase::$definition['fields'][$campo] : null;
        if (!$def) {
            return 'sin_definicion';
        }
        if (!empty($def['required']) && trim($valor) === '') {
            return 'obligatorio';
        }
        if (isset($def['size'])) {
            $max = is_array($def['size']) ? (isset($def['size']['max']) ? (int) $def['size']['max'] : 0) : (int) $def['size'];
            if ($max > 0 && Tools::strlen($valor) > $max) {
                return 'demasiado_largo';
            }
        }
        if (!empty($def['validate']) && method_exists('Validate', $def['validate'])) {
            $metodo = $def['validate'];
            if (!Validate::$metodo($valor)) {
                return 'no_valido';
            }
        }
        return '';
    }

    /** Escribe SOLO ese campo, en ese idioma (y tienda). Devuelve true si ha ido bien. */
    public static function escribir($tipo, $campo, $id, $idLang, $idShop, $valor, $idSub = null)
    {
        $db = Db::getInstance();
        $m = self::mapa();
        list($tabla, $col, , $porTienda) = $m[$tipo][$campo];
        if ($campo === 'tags') {
            $viejas = $db->executeS('SELECT `id_tag` FROM `' . _DB_PREFIX_ . 'product_tag` WHERE `id_product` = ' . (int) $id . ' AND `id_lang` = ' . (int) $idLang);
            $db->execute('DELETE FROM `' . _DB_PREFIX_ . 'product_tag` WHERE `id_product` = ' . (int) $id . ' AND `id_lang` = ' . (int) $idLang);
            if (trim($valor) !== '') {
                Tag::addTags((int) $idLang, (int) $id, $valor, ',');
            }
            $ids = array();
            foreach (is_array($viejas) ? $viejas : array() as $f) {
                $ids[] = (int) $f['id_tag'];
            }
            Tag::updateTagCount($ids ?: null);
            return true;
        }
        if ($campo === 'redirect') {
            $r = self::partirRedireccion($valor);
            if (!$r) {
                return false;
            }
            $datos = array('redirect_type' => pSQL($r[0]), 'id_type_redirected' => (int) $r[1]);
            // product_shop (lo que manda en cada tienda) y product (la copia que el nucleo mantiene igual).
            $ok = $db->update('product_shop', $datos, '`id_product` = ' . (int) $id . ' AND `id_shop` = ' . (int) $idShop);
            return $ok && $db->update('product', $datos, '`id_product` = ' . (int) $id);
        }
        if ($campo === 'legend') {
            $existe = $db->getValue('SELECT 1 FROM `' . _DB_PREFIX_ . 'image_lang` WHERE `id_image` = ' . (int) $idSub . ' AND `id_lang` = ' . (int) $idLang);
            if ($existe) {
                return $db->update('image_lang', array('legend' => pSQL($valor)), '`id_image` = ' . (int) $idSub . ' AND `id_lang` = ' . (int) $idLang);
            }
            return $db->insert('image_lang', array('id_image' => (int) $idSub, 'id_lang' => (int) $idLang, 'legend' => pSQL($valor)));
        }
        $html = in_array($campo, array('description', 'description_short', 'short_description', 'content'), true);
        $where = '`' . self::idCampo($tipo) . '` = ' . (int) $id . ' AND `id_lang` = ' . (int) $idLang . ($porTienda ? ' AND `id_shop` = ' . (int) $idShop : '');
        return $db->update($tabla, array($col => pSQL($valor, $html)), $where);
    }

    /** Avisa al nucleo y a los demas modulos de que el elemento ha cambiado. */
    public static function avisarNucleo($tipo, $id)
    {
        try {
            if ($tipo === 'producto') {
                $p = new Product((int) $id);
                Hook::exec('actionProductUpdate', array('id_product' => (int) $id, 'product' => $p));
                if (class_exists('Search') && method_exists('Search', 'indexation')) {
                    Search::indexation(false, (int) $id);
                }
            } elseif ($tipo === 'categoria') {
                Hook::exec('actionCategoryUpdate', array('category' => new Category((int) $id)));
            } elseif ($tipo === 'marca') {
                Hook::exec('actionObjectManufacturerUpdateAfter', array('object' => new Manufacturer((int) $id)));
            } elseif ($tipo === 'cms') {
                Hook::exec('actionObjectCMSUpdateAfter', array('object' => new CMS((int) $id)));
            }
        } catch (Exception $e) {
            EscLog::escribir('avisarNucleo ' . $tipo . ' ' . $id . ': ' . $e->getMessage());
        }
    }
}
