<?php
/**
 * Ecom SEO Connect - pantalla «SEO IA»: estado, historial de cambios y deshacer.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminEcomSeoconnectController extends ModuleAdminController
{
    const POR_PAGINA = 50;

    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
        $this->meta_title = 'SEO IA';
    }

    public function postProcess()
    {
        if (Shop::isFeatureActive() && Shop::getContext() !== Shop::CONTEXT_SHOP) {
            return parent::postProcess();
        }
        $idShop = (int) $this->context->shop->id;
        if (Tools::isSubmit('submitEscDeshacer')) {
            $err = EscHistory::deshacer($idShop, (int) Tools::getValue('id_history'));
            Tools::clearSmartyCache();
            if ($err === '') {
                $this->confirmations[] = $this->trans('Change undone. The platform will be informed in the next sync.', array(), 'Modules.Ecomseoconnect.Admin');
            } elseif ($err === 'cambiado_despues') {
                $this->errors[] = $this->trans('Not undone: the field was changed again after this change.', array(), 'Modules.Ecomseoconnect.Admin');
            } else {
                $this->errors[] = $this->trans('Could not undo: %s', array($err), 'Modules.Ecomseoconnect.Admin');
            }
        } elseif (Tools::isSubmit('submitEscDeshacerHoy')) {
            list($hechos, $saltados) = EscHistory::deshacerHoy($idShop);
            $this->confirmations[] = $this->trans('Undone: %1$d. Skipped (changed afterwards): %2$d.', array($hechos, $saltados), 'Modules.Ecomseoconnect.Admin');
        } elseif (Tools::isSubmit('submitEscTrabajar')) {
            if (EscClient::conectado($idShop)) {
                $r = EscSync::trabajo($idShop, 25, true);
                if ($r === 'ocupado') {
                    $this->warnings[] = $this->trans('A sync is already running. Try again in a minute.', array(), 'Modules.Ecomseoconnect.Admin');
                } else {
                    $this->confirmations[] = $this->trans('Sync done.', array(), 'Modules.Ecomseoconnect.Admin');
                }
            }
        }
        return parent::postProcess();
    }

    public function initContent()
    {
        $sinTienda = Shop::isFeatureActive() && Shop::getContext() !== Shop::CONTEXT_SHOP;
        $idShop = (int) $this->context->shop->id;
        $pagina = max(1, (int) Tools::getValue('p', 1));
        $historial = array();
        foreach ($sinTienda ? array() : EscHistory::lista($idShop, self::POR_PAGINA, ($pagina - 1) * self::POR_PAGINA) as $h) {
            $h['antes'] = Tools::substr(strip_tags((string) $h['valor_anterior']), 0, 160);
            $h['despues'] = Tools::substr(strip_tags((string) $h['valor_nuevo']), 0, 160);
            $historial[] = $h;
        }
        $total = $sinTienda ? 0 : EscHistory::total($idShop);
        $this->context->smarty->assign(array(
            'esc_multitienda_sin_tienda' => $sinTienda,
            'esc_conectado' => !$sinTienda && EscClient::conectado($idShop),
            'esc_url' => EscClient::cfg('ECOMSEOCONNECT_URL', $idShop),
            'esc_estado' => json_decode((string) EscClient::cfg('ECOMSEOCONNECT_ESTADO', $idShop, ''), true) ?: array(),
            'esc_hoy' => $sinTienda ? 0 : EscApplier::aplicadosHoy($idShop),
            'esc_tope' => (int) EscClient::cfg('ECOMSEOCONNECT_DAILY_CAP', $idShop, 50),
            'esc_cola' => $sinTienda ? 0 : EscQueue::pendientes($idShop),
            'esc_tiron' => EscClient::cfg('ECOMSEOCONNECT_ULTIMO_TIRON', $idShop, '-'),
            'esc_historial' => $historial,
            'esc_total' => $total,
            'esc_pagina' => $pagina,
            'esc_paginas' => (int) ceil($total / self::POR_PAGINA),
            'esc_log' => EscLog::ultimas(80),
            'esc_accion' => $this->context->link->getAdminLink('AdminEcomSeoconnect'),
            'esc_config' => $this->context->link->getAdminLink('AdminModules', true, array(), array('configure' => 'ecom_seoconnect')),
        ));
        $this->content = $this->context->smarty->fetch(_PS_MODULE_DIR_ . 'ecom_seoconnect/views/templates/admin/panel.tpl');
        parent::initContent();
    }
}
