<?php
/**
 * SEO IA Connect - campos que el plugin sabe leer y escribir, y dónde vive cada uno.
 *
 * El título y la descripción SEO se guardan donde los lee el plugin SEO que esté activo
 * (Yoast SEO o Rank Math). Sin ninguno, en metadatos propios que publica Ecsc_Front.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_Fields
{
    /** tipo => lista de campos. Solo lo que existe en esta web. */
    public static function mapa()
    {
        $m = array('cms' => array('meta_title', 'meta_description', 'content'));
        if (Ecsc_Catalog::hayTienda()) {
            $m['producto'] = array('meta_title', 'meta_description', 'name', 'description_short', 'description', 'legend', 'tags', 'link_rewrite');
        }
        if (Ecsc_Catalog::taxonomias('categoria')) {
            $m['categoria'] = array('meta_title', 'meta_description', 'description', 'link_rewrite');
        }
        if (Ecsc_Catalog::taxonomias('marca')) {
            $m['marca'] = array('meta_title', 'meta_description', 'description');
        }
        return $m;
    }

    public static function existe($tipo, $campo)
    {
        $m = self::mapa();
        return isset($m[$tipo]) && in_array($campo, $m[$tipo], true);
    }

    /** Quién guarda el título y la descripción SEO en esta web. */
    public static function seo()
    {
        if (defined('WPSEO_VERSION')) {
            return 'yoast';
        }
        if (defined('RANK_MATH_VERSION')) {
            return 'rankmath';
        }
        return 'propio';
    }

    private static function clavesMeta()
    {
        $seo = self::seo();
        if ($seo === 'yoast') {
            return array('meta_title' => '_yoast_wpseo_title', 'meta_description' => '_yoast_wpseo_metadesc');
        }
        if ($seo === 'rankmath') {
            return array('meta_title' => 'rank_math_title', 'meta_description' => 'rank_math_description');
        }
        return array('meta_title' => '_ecsc_title', 'meta_description' => '_ecsc_description');
    }

    private static function esTermino($tipo)
    {
        return $tipo === 'categoria' || $tipo === 'marca';
    }

    /** El término, si es de una taxonomía de ese tipo; null si no. */
    private static function termino($tipo, $id)
    {
        $t = get_term((int) $id);
        if (!$t || is_wp_error($t) || !in_array($t->taxonomy, Ecsc_Catalog::taxonomias($tipo), true)) {
            return null;
        }
        return $t;
    }

    /** La entrada, página o producto, si es de ese tipo y no está en la papelera; null si no. */
    private static function entrada($tipo, $id)
    {
        $p = get_post((int) $id);
        if (!$p || !in_array($p->post_type, Ecsc_Catalog::tiposDePost($tipo), true) || in_array($p->post_status, array('trash', 'auto-draft', 'inherit'), true)) {
            return null;
        }
        return $p;
    }

    /** Imágenes de un producto: la destacada y la galería. */
    public static function imagenes($idProducto)
    {
        $ids = array();
        $destacada = (int) get_post_thumbnail_id((int) $idProducto);
        if ($destacada > 0) {
            $ids[] = $destacada;
        }
        $galeria = (string) get_post_meta((int) $idProducto, '_product_image_gallery', true);
        foreach (array_filter(array_map('intval', explode(',', $galeria))) as $id) {
            if (!in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }
        return $ids;
    }

    /** Etiquetas de un producto, en una línea y siempre en el mismo orden. */
    public static function etiquetas($idProducto)
    {
        $nombres = wp_get_object_terms((int) $idProducto, 'product_tag', array('fields' => 'names', 'orderby' => 'name', 'order' => 'ASC'));
        return is_array($nombres) ? implode(', ', $nombres) : '';
    }

    /** ¿El contenido lo lleva un constructor visual? Entonces no se reescribe. */
    public static function constructor($idPost)
    {
        $id = (int) $idPost;
        return get_post_meta($id, '_elementor_edit_mode', true) === 'builder' || get_post_meta($id, '_et_pb_use_builder', true) === 'on'
            || (bool) get_post_meta($id, '_fl_builder_enabled', true) || get_post_meta($id, '_wpb_vc_js_status', true) === 'true';
    }

    private static function leerMeta($tipo, $id, $campo, $taxonomia = '')
    {
        $claves = self::clavesMeta();
        if (!self::esTermino($tipo)) {
            return (string) get_post_meta((int) $id, $claves[$campo], true);
        }
        if (self::seo() === 'yoast') {
            $todo = get_option('wpseo_taxonomy_meta');
            $k = $campo === 'meta_title' ? 'wpseo_title' : 'wpseo_desc';
            return is_array($todo) && isset($todo[$taxonomia][(int) $id][$k]) ? (string) $todo[$taxonomia][(int) $id][$k] : '';
        }
        return (string) get_term_meta((int) $id, $claves[$campo], true);
    }

    private static function escribirMeta($tipo, $id, $campo, $valor, $taxonomia = '')
    {
        $claves = self::clavesMeta();
        if (!self::esTermino($tipo)) {
            update_post_meta((int) $id, $claves[$campo], wp_slash($valor));
            return self::leerMeta($tipo, $id, $campo) === $valor;
        }
        if (self::seo() === 'yoast') {
            $todo = get_option('wpseo_taxonomy_meta');
            $todo = is_array($todo) ? $todo : array();
            $todo[$taxonomia][(int) $id][$campo === 'meta_title' ? 'wpseo_title' : 'wpseo_desc'] = $valor;
            update_option('wpseo_taxonomy_meta', $todo);
        } else {
            update_term_meta((int) $id, $claves[$campo], wp_slash($valor));
        }
        return self::leerMeta($tipo, $id, $campo, $taxonomia) === $valor;
    }

    /** Valor actual de un campo. null si el elemento no existe (o no es de ese tipo). */
    public static function leer($tipo, $campo, $id, $idSub = null)
    {
        if (!self::existe($tipo, $campo)) {
            return null;
        }
        if (self::esTermino($tipo)) {
            $t = self::termino($tipo, $id);
            if (!$t) {
                return null;
            }
            if ($campo === 'description') {
                return (string) $t->description;
            }
            if ($campo === 'link_rewrite') {
                return (string) $t->slug;
            }
            return self::leerMeta($tipo, $id, $campo, $t->taxonomy);
        }
        $p = self::entrada($tipo, $id);
        if (!$p) {
            return null;
        }
        switch ($campo) {
            case 'name':
                return (string) $p->post_title;
            case 'content':
            case 'description':
                return (string) $p->post_content;
            case 'description_short':
                return (string) $p->post_excerpt;
            case 'link_rewrite':
                return (string) $p->post_name;
            case 'tags':
                return self::etiquetas($id);
            case 'legend':
                if (!in_array((int) $idSub, self::imagenes($id), true)) {
                    return null;
                }
                return (string) get_post_meta((int) $idSub, '_wp_attachment_image_alt', true);
        }
        return self::leerMeta($tipo, $id, $campo);
    }

    /** '' si el valor se puede guardar; si no, el motivo en una palabra. */
    public static function validar($tipo, $campo, $valor, $id = 0)
    {
        $valor = (string) $valor;
        $sinHtml = array('meta_title' => 255, 'meta_description' => 512, 'name' => 255, 'tags' => 250, 'legend' => 255, 'link_rewrite' => 200);
        if (isset($sinHtml[$campo])) {
            if ($valor !== wp_strip_all_tags($valor) || preg_match('/[<>]/', $valor)) {
                return 'html';
            }
            if (function_exists('mb_strlen') ? mb_strlen($valor) > $sinHtml[$campo] : strlen($valor) > $sinHtml[$campo]) {
                return 'largo';
            }
            if ($campo === 'name' && trim($valor) === '') {
                return 'vacio';
            }
            if ($campo === 'link_rewrite' && ($valor === '' || sanitize_title($valor) !== $valor)) {
                return 'url';
            }
            return '';
        }
        if (strlen($valor) > 200000) {
            return 'largo';
        }
        if (preg_match('#<\s*(script|iframe|object|embed|form|style|link|meta)\b#i', $valor) || preg_match('#\son[a-z]+\s*=#i', $valor) || preg_match('#javascript\s*:#i', $valor)) {
            return 'html_peligroso';
        }
        if (($campo === 'content' || $campo === 'description') && !self::esTermino($tipo) && (int) $id > 0 && self::constructor($id)) {
            return 'constructor_visual';
        }
        return '';
    }

    /** Guarda el valor. Devuelve true solo si al releerlo es lo que se ha pedido. */
    public static function escribir($tipo, $campo, $id, $valor, $idSub = null)
    {
        $valor = (string) $valor;
        if (!self::existe($tipo, $campo)) {
            return false;
        }
        if (self::esTermino($tipo)) {
            $t = self::termino($tipo, $id);
            if (!$t) {
                return false;
            }
            if ($campo === 'description' || $campo === 'link_rewrite') {
                $r = wp_update_term((int) $id, $t->taxonomy, array($campo === 'description' ? 'description' : 'slug' => wp_slash($valor)));
                return !is_wp_error($r);
            }
            return self::escribirMeta($tipo, $id, $campo, $valor, $t->taxonomy);
        }
        $p = self::entrada($tipo, $id);
        if (!$p) {
            return false;
        }
        $columnas = array('name' => 'post_title', 'content' => 'post_content', 'description' => 'post_content', 'description_short' => 'post_excerpt', 'link_rewrite' => 'post_name');
        if (isset($columnas[$campo])) {
            $r = wp_update_post(wp_slash(array('ID' => (int) $id, $columnas[$campo] => $valor)), true);
            $ok = !is_wp_error($r) && (int) $r > 0;
        } elseif ($campo === 'tags') {
            $nombres = array_values(array_filter(array_map('trim', explode(',', $valor)), 'strlen'));
            $ok = !is_wp_error(wp_set_object_terms((int) $id, $nombres, 'product_tag'));
        } elseif ($campo === 'legend') {
            if (!in_array((int) $idSub, self::imagenes($id), true)) {
                return false;
            }
            update_post_meta((int) $idSub, '_wp_attachment_image_alt', wp_slash($valor));
            $ok = (string) get_post_meta((int) $idSub, '_wp_attachment_image_alt', true) === $valor;
        } else {
            $ok = self::escribirMeta($tipo, $id, $campo, $valor);
        }
        if ($ok) {
            clean_post_cache((int) $id);
            if ($tipo === 'producto' && function_exists('wc_delete_product_transients')) {
                wc_delete_product_transients((int) $id);
            }
        }
        return $ok;
    }
}
