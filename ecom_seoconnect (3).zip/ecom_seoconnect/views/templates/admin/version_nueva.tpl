{**
 * SEO IA Connect - aviso de versión nueva del módulo (la versión la dice la plataforma en cada respuesta).
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 *}
<div class="alert alert-warning">
    <strong>{l s='New version available' d='Modules.Ecomseoconnect.Admin'} ({$esc_version_nueva|escape:'html':'UTF-8'})</strong>
    · {l s='This store has version %s. Download the new one and install it over this one (Modules > Upload a module).' d='Modules.Ecomseoconnect.Admin' sprintf=[$esc_version_actual]}
    {if $esc_descarga}<a class="btn btn-default" href="{$esc_descarga|escape:'html':'UTF-8'}">{l s='Download the module' d='Modules.Ecomseoconnect.Admin'}</a>{/if}
</div>
