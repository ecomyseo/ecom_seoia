/**
 * Ecom SEO Connect - JS de las pantallas del modulo (por delegacion sobre document).
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
(function () {
  'use strict';
  var texto = function () {
    return (window.escTextos && window.escTextos.confirmar) ? window.escTextos.confirmar : '?';
  };
  document.addEventListener('click', function (ev) {
    var a = ev.target.closest ? ev.target.closest('.esc-acordeon-titulo') : null;
    if (a) {
      ev.preventDefault();
      var c = a.parentNode.querySelector('.esc-acordeon-cuerpo');
      if (c) {
        c.style.display = c.style.display === 'none' ? 'block' : 'none';
      }
      return;
    }
    var b = ev.target.closest ? ev.target.closest('button.esc-confirmar') : null;
    if (b && !window.confirm(texto())) {
      ev.preventDefault();
    }
    var s = ev.target.closest ? ev.target.closest('.esc-seleccionar') : null;
    if (s && s.select) {
      s.select();
    }
  });
  document.addEventListener('submit', function (ev) {
    var f = ev.target;
    if (f && f.classList && f.classList.contains('esc-confirmar-form') && !window.confirm(texto())) {
      ev.preventDefault();
    }
  });
})();
