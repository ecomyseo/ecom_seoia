<?php
/**
 * Ecom SEO Connect - URL de cron (con token). Programar cada 5-10 minutos.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class Ecom_SeoconnectCronModuleFrontController extends ModuleFrontController
{
    public $ssl = false;
    public $display_header = false;
    public $display_footer = false;

    protected function displayMaintenancePage()
    {
    }

    protected function displayRestrictedCountryPage()
    {
    }

    public function postProcess()
    {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
        $esperado = (string) Configuration::getGlobalValue('ECOMSEOCONNECT_CRON_TOKEN');
        if ($esperado === '' || !hash_equals($esperado, (string) Tools::getValue('token'))) {
            http_response_code(403);
            exit;
        }
        $idShop = (int) $this->context->shop->id;
        if (!EscClient::conectado($idShop)) {
            echo 'no conectado';
            exit;
        }
        ignore_user_abort(true);
        @set_time_limit(60);
        echo 'tienda ' . $idShop . ': ' . EscSync::trabajo($idShop, 25, true);
        exit;
    }
}
