<?php
/**
 * SEO IA Connect - aplicar en la web las mejoras aprobadas, con los permisos de ESTA web.
 *
 * Los permisos por campo solo se cambian aquí, en WordPress: la plataforma los recibe de solo
 * lectura. Nada se escribe si el campo no está en «Aplicar con aprobación» o «Automático», ni
 * si el texto ha cambiado desde que se generó la mejora.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_Applier
{
    public static function modos()
    {
        return array('blocked', 'suggest', 'approve', 'auto');
    }

    /** Campos que la plataforma conoce y este plugin no escribe: se mandan bloqueados para que no los proponga. */
    private static function ajenos()
    {
        return array('marca.short_description');
    }

    /** Permisos por campo. Por defecto «suggest»; la URL, «blocked». */
    public static function permisos()
    {
        $p = json_decode((string) get_option('ecsc_perms', ''), true);
        $p = is_array($p) ? $p : array();
        $out = array();
        foreach (Ecsc_Fields::mapa() as $tipo => $campos) {
            foreach ($campos as $campo) {
                $k = $tipo . '.' . $campo;
                $defecto = $campo === 'link_rewrite' ? 'blocked' : 'suggest';
                $out[$k] = isset($p[$k]) && in_array($p[$k], self::modos(), true) ? $p[$k] : $defecto;
            }
        }
        foreach (self::ajenos() as $k) {
            $out[$k] = 'blocked';
        }
        return $out;
    }

    /**
     * Aplica una lista de cambios y devuelve los resultados para la plataforma.
     * Los que no caben en el tope diario NO devuelven resultado: la plataforma los reenviará.
     */
    public static function aplicar(array $cambios)
    {
        $res = array();
        $parada = (int) get_option('ecsc_kill', 0) === 1;
        $perm = self::permisos();
        $tope = max(0, (int) get_option('ecsc_daily_cap', 50));
        $hoy = Ecsc_History::aplicadosHoy();
        foreach ($cambios as $c) {
            if (!is_array($c) || empty($c['id'])) {
                continue;
            }
            $id = (int) $c['id'];
            $tipo = isset($c['tipo']) ? (string) $c['tipo'] : '';
            $campo = isset($c['campo']) ? (string) $c['campo'] : '';
            if ($parada) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'parada_total_activa');
                continue;
            }
            if (!Ecsc_Fields::existe($tipo, $campo)) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'campo_no_permitido');
                Ecsc_Log::error('Cambio #' . $id . ' con campo fuera de la lista: ' . $tipo . '.' . $campo);
                continue;
            }
            $modo = $perm[$tipo . '.' . $campo];
            if ($modo !== 'approve' && $modo !== 'auto') {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'permiso_' . $modo);
                continue;
            }
            if ($tope > 0 && $hoy >= $tope) {
                Ecsc_Log::escribir('Tope diario alcanzado (' . $tope . '): el resto espera a mañana');
                break;
            }
            $idEl = isset($c['id_elemento']) ? (int) $c['id_elemento'] : 0;
            $idSub = isset($c['id_sub']) && $c['id_sub'] !== null ? (int) $c['id_sub'] : null;
            $valor = isset($c['valor']) && is_string($c['valor']) ? $c['valor'] : null;
            if (!$idEl || $valor === null || (isset($c['iso']) && strtolower((string) $c['iso']) !== Ecsc_Catalog::iso())) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'datos_incompletos');
                continue;
            }
            $actual = Ecsc_Fields::leer($tipo, $campo, $idEl, $idSub);
            if ($actual === null) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'no_existe');
                continue;
            }
            if ($actual === $valor) {
                $res[] = array('id' => $id, 'estado' => 'aplicada', 'motivo' => 'ya_estaba');
                continue;
            }
            if (!isset($c['hash_anterior']) || !hash_equals((string) $c['hash_anterior'], sha1($actual))) {
                // El texto ha cambiado desde que se generó la mejora: no se pisa el trabajo de nadie.
                $res[] = array('id' => $id, 'estado' => 'desfasada', 'motivo' => 'el_valor_ha_cambiado');
                continue;
            }
            $err = Ecsc_Fields::validar($tipo, $campo, $valor, $idEl);
            if ($err !== '') {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'validacion_' . $err);
                continue;
            }
            if (!Ecsc_Fields::escribir($tipo, $campo, $idEl, $valor, $idSub)) {
                $res[] = array('id' => $id, 'estado' => 'rechazada', 'motivo' => 'error_al_guardar');
                continue;
            }
            Ecsc_History::anotar($tipo, $idEl, $campo, $idSub, $actual, $valor, $id, $modo);
            $hoy++;
            $res[] = array('id' => $id, 'estado' => 'aplicada', 'motivo' => $modo === 'auto' ? 'automatico' : 'aprobada');
            Ecsc_Log::escribir('Aplicado #' . $id . ' ' . $tipo . ' ' . $idEl . ' ' . $campo);
        }
        return $res;
    }
}
