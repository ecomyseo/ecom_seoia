<?php
/**
 * SEO IA Connect - registro del plugin en wp-content/uploads/ecsc-logs/ (protegido).
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('ABSPATH')) {
    exit;
}

class Ecsc_Log
{
    private static function carpeta()
    {
        $subidas = wp_upload_dir(null, false);
        $dir = trailingslashit($subidas['basedir']) . 'ecsc-logs';
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
            // Los registros no se sirven por web.
            @file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n");
            @file_put_contents($dir . '/index.php', "<?php\n// Silence is golden.\n");
        }
        return $dir;
    }

    public static function escribir($mensaje, $nivel = 'info')
    {
        if ($nivel !== 'error' && (int) get_option('ecsc_debug', 0) !== 1) {
            return;
        }
        $linea = '[' . gmdate('Y-m-d H:i:s') . '] ' . strtoupper($nivel) . ' ' . preg_replace('/[\r\n]+/', ' ', (string) $mensaje) . "\n";
        @file_put_contents(self::carpeta() . '/' . gmdate('Y-m') . '.log', $linea, FILE_APPEND | LOCK_EX);
    }

    public static function error($mensaje)
    {
        self::escribir($mensaje, 'error');
    }

    /** Últimas líneas del registro del mes, para enseñarlas en los ajustes. */
    public static function ultimas($n = 40)
    {
        $f = self::carpeta() . '/' . gmdate('Y-m') . '.log';
        if (!is_file($f)) {
            return array();
        }
        $lineas = file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return array_slice(is_array($lineas) ? $lineas : array(), -1 * (int) $n);
    }

    public static function borrarTodo()
    {
        $dir = self::carpeta();
        $ficheros = glob($dir . '/*');
        foreach (is_array($ficheros) ? $ficheros : array() as $f) {
            @unlink($f);
        }
        @unlink($dir . '/.htaccess');
        @rmdir($dir);
    }
}
