<?php
/**
 * Ecom SEO Connect - lo que el modulo puede publicar en la tienda (especificaciones 007, 008 y 012):
 * hreflang x-default y datos estructurados (organizacion, web con buscador, preguntas frecuentes y
 * producto), SOLO lo que el tema no trae ya, y siempre apagado por defecto.
 *
 * Tambien mira el tema y el robots.txt EN DISCO (sin descargar nada) para contarselo a la plataforma.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscFront
{
    const TIPOS = 'Organization|WebSite|Product|FAQPage|BreadcrumbList|Store|OnlineStore';

    /**
     * Lo que pinta el tema de la tienda: hreflang, x-default y tipos de datos estructurados.
     * Se guarda en configuracion y se repasa si cambia el tema o cada 24 horas.
     */
    public static function tema($idShop)
    {
        $idShop = (int) $idShop;
        $nombre = '';
        try {
            $shop = new Shop($idShop);
            $nombre = (string) $shop->theme_name;
        } catch (Exception $e) {
            $nombre = '';
        }
        $guardado = json_decode((string) EscClient::cfg('ECOMSEOCONNECT_TEMA', $idShop, ''), true);
        if (is_array($guardado) && isset($guardado['nombre'], $guardado['fecha']) && $guardado['nombre'] === $nombre && $guardado['fecha'] > time() - 86400) {
            return $guardado;
        }
        $r = array('nombre' => $nombre, 'hreflang' => false, 'xdefault' => false, 'tipos' => array(), 'fecha' => time());
        $dirs = array();
        if ($nombre !== '' && defined('_PS_ALL_THEMES_DIR_')) {
            $dirs[] = _PS_ALL_THEMES_DIR_ . $nombre;
            $yml = @file_get_contents(_PS_ALL_THEMES_DIR_ . $nombre . '/config/theme.yml');
            if (is_string($yml) && preg_match('/^parent:\s*([A-Za-z0-9_.-]+)/m', $yml, $m)) {
                $dirs[] = _PS_ALL_THEMES_DIR_ . $m[1];
            }
        }
        $tipos = array();
        $leidos = 0;
        foreach ($dirs as $dir) {
            if (!is_dir($dir . '/templates')) {
                continue;
            }
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir . '/templates', FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if ($leidos >= 3000) {
                    break 2;
                }
                if (!$f->isFile() || substr($f->getFilename(), -4) !== '.tpl') {
                    continue;
                }
                $leidos++;
                $t = (string) @file_get_contents($f->getPathname());
                if (stripos($t, 'hreflang') !== false) {
                    $r['hreflang'] = true;
                }
                if (stripos($t, 'x-default') !== false) {
                    $r['xdefault'] = true;
                }
                if (preg_match_all('/["\']@type["\']\s*:\s*["\'](' . self::TIPOS . ')["\']/', $t, $m)) {
                    foreach ($m[1] as $x) {
                        $tipos[$x] = true;
                    }
                }
                if (preg_match_all('#itemtype=["\']https?://schema\.org/(Product|Organization)["\']#i', $t, $m)) {
                    foreach ($m[1] as $x) {
                        $tipos[ucfirst(strtolower($x)) === 'Organization' ? 'Organization' : 'Product'] = true;
                    }
                }
            }
        }
        $r['tipos'] = array_keys($tipos);
        Configuration::updateValue('ECOMSEOCONNECT_TEMA', json_encode($r), false, null, $idShop);
        return $r;
    }

    /** robots.txt de la raiz: ¿bloquea toda la tienda para todos (o Google)? ¿declara el sitemap? */
    public static function robots()
    {
        $raiz = rtrim(defined('_PS_ROOT_DIR_') ? _PS_ROOT_DIR_ : dirname(_PS_MODULE_DIR_), '/\\');
        $t = @file_get_contents($raiz . '/robots.txt');
        if (!is_string($t)) {
            return array('bloquea' => false, 'sitemap' => false);
        }
        $bloquea = false;
        $sitemap = false;
        $agentes = array();
        $anteriorAgente = false;
        foreach (preg_split('/\r\n|\r|\n/', $t) as $linea) {
            $linea = trim(preg_replace('/#.*$/', '', $linea));
            if ($linea === '' || strpos($linea, ':') === false) {
                continue;
            }
            list($k, $v) = array_map('trim', explode(':', $linea, 2));
            $k = strtolower($k);
            if ($k === 'user-agent') {
                $agentes = $anteriorAgente ? array_merge($agentes, array(strtolower($v))) : array(strtolower($v));
                $anteriorAgente = true;
                continue;
            }
            $anteriorAgente = false;
            if ($k === 'sitemap' && $v !== '') {
                $sitemap = true;
            }
            if ($k === 'disallow' && $v === '/' && (in_array('*', $agentes, true) || in_array('googlebot', $agentes, true))) {
                $bloquea = true;
            }
        }
        return array('bloquea' => $bloquea, 'sitemap' => $sitemap);
    }

    /** Preguntas frecuentes de una descripcion: encabezado (o parrafo en negrita) que acaba en «?» y el texto que le sigue. */
    public static function preguntas($html)
    {
        $html = preg_replace('#<p[^>]*>\s*<(strong|b)>(.*?)</\1>\s*</p>#is', '<h3>$2</h3>', (string) $html);
        $partes = preg_split('#<h[2-4][^>]*>(.*?)</h[2-4]>#is', (string) $html, -1, PREG_SPLIT_DELIM_CAPTURE);
        $out = array();
        $limpia = function ($s) {
            return trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string) $s), ENT_QUOTES, 'UTF-8')));
        };
        $n = is_array($partes) ? count($partes) : 0;
        for ($i = 1; $i + 1 < $n && count($out) < 10; $i += 2) {
            $q = $limpia($partes[$i]);
            $a = $limpia($partes[$i + 1]);
            if ($q !== '' && $a !== '' && preg_match('/\?$/u', $q)) {
                $out[] = array($q, mb_substr($a, 0, 1000));
            }
        }
        return $out;
    }

    private static function script(array $datos)
    {
        return '<script type="application/ld+json">' . json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) . '</script>' . "\n";
    }

    /** Lo que se pinta en <head> (hook displayHeader). Devuelve '' si no hay nada encendido. */
    public static function cabecera(Context $ctx)
    {
        $idShop = (int) $ctx->shop->id;
        $xdef = (int) EscClient::cfg('ECOMSEOCONNECT_XDEFAULT', $idShop, 0) === 1;
        $org = (int) EscClient::cfg('ECOMSEOCONNECT_JSONLD_ORG', $idShop, 0) === 1;
        $faq = (int) EscClient::cfg('ECOMSEOCONNECT_JSONLD_FAQ', $idShop, 0) === 1;
        $prod = (int) EscClient::cfg('ECOMSEOCONNECT_JSONLD_PRODUCTO', $idShop, 0) === 1;
        if (!$xdef && !$org && !$faq && !$prod) {
            return '';
        }
        $c = $ctx->controller;
        $pagina = is_object($c) && isset($c->php_self) ? (string) $c->php_self : '';
        $tema = self::tema($idShop);
        $out = '';
        try {
            if ($xdef && !$tema['xdefault'] && count(Language::getLanguages(true, $idShop)) > 1) {
                $url = $ctx->link->getLanguageLink((int) Configuration::get('PS_LANG_DEFAULT', null, null, $idShop));
                $out .= '<link rel="alternate" href="' . htmlspecialchars((string) $url, ENT_QUOTES, 'UTF-8') . '" hreflang="x-default">' . "\n";
            }
            if ($org && $pagina === 'index') {
                $base = $ctx->link->getBaseLink($idShop, true);
                $nombre = (string) Configuration::get('PS_SHOP_NAME', null, null, $idShop);
                if (!in_array('Organization', $tema['tipos'], true)) {
                    $o = array('@context' => 'https://schema.org', '@type' => 'Organization', 'name' => $nombre, 'url' => $base);
                    $logo = (string) Configuration::get('PS_LOGO', null, null, $idShop);
                    if ($logo !== '') {
                        $o['logo'] = $ctx->link->getMediaLink(_PS_IMG_ . $logo);
                    }
                    $out .= self::script($o);
                }
                if (!in_array('WebSite', $tema['tipos'], true)) {
                    $buscar = $ctx->link->getPageLink('search', true, null, null, false, $idShop);
                    $out .= self::script(array('@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => $nombre, 'url' => $base,
                        'potentialAction' => array('@type' => 'SearchAction',
                            'target' => array('@type' => 'EntryPoint', 'urlTemplate' => $buscar . (strpos($buscar, '?') === false ? '?' : '&') . 'search_query={search_term_string}'),
                            'query-input' => 'required name=search_term_string')));
                }
            }
            if (($faq || $prod) && $pagina === 'product' && method_exists($c, 'getProduct')) {
                $p = $c->getProduct();
                if (Validate::isLoadedObject($p)) {
                    $idLang = (int) $ctx->language->id;
                    if ($faq) {
                        $qs = self::preguntas(is_array($p->description) ? (isset($p->description[$idLang]) ? $p->description[$idLang] : '') : $p->description);
                        if ($qs) {
                            $items = array();
                            foreach ($qs as $q) {
                                $items[] = array('@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => array('@type' => 'Answer', 'text' => $q[1]));
                            }
                            $out .= self::script(array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $items));
                        }
                    }
                    if ($prod && !in_array('Product', $tema['tipos'], true)) {
                        $out .= self::script(self::producto($p, $ctx, $idShop, $idLang));
                    }
                }
            }
        } catch (Exception $e) {
            EscLog::error('Cabecera: ' . $e->getMessage());
        }
        return $out;
    }

    private static function producto(Product $p, Context $ctx, $idShop, $idLang)
    {
        $txt = function ($v) use ($idLang) {
            $v = is_array($v) ? (isset($v[$idLang]) ? $v[$idLang] : '') : $v;
            return trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string) $v), ENT_QUOTES, 'UTF-8')));
        };
        $nombre = $txt($p->name);
        $d = array('@context' => 'https://schema.org', '@type' => 'Product', 'name' => $nombre, 'url' => $ctx->link->getProductLink($p));
        $desc = $txt($p->description_short) !== '' ? $txt($p->description_short) : $txt($p->description);
        if ($desc !== '') {
            $d['description'] = mb_substr($desc, 0, 5000);
        }
        $portada = Product::getCover((int) $p->id);
        if (is_array($portada) && !empty($portada['id_image'])) {
            $d['image'] = $ctx->link->getImageLink(is_array($p->link_rewrite) ? (string) reset($p->link_rewrite) : (string) $p->link_rewrite, (int) $portada['id_image'], ImageType::getFormattedName('large'));
        }
        if ((string) $p->reference !== '') {
            $d['sku'] = (string) $p->reference;
        }
        if (preg_match('/^\d{13}$/', (string) $p->ean13)) {
            $d['gtin13'] = (string) $p->ean13;
        }
        if (isset($p->mpn) && (string) $p->mpn !== '') {
            $d['mpn'] = (string) $p->mpn;
        }
        if ((int) $p->id_manufacturer > 0) {
            $marca = Manufacturer::getNameById((int) $p->id_manufacturer);
            if ($marca) {
                $d['brand'] = array('@type' => 'Brand', 'name' => (string) $marca);
            }
        }
        $cantidad = (int) StockAvailable::getQuantityAvailableByProduct((int) $p->id, 0, (int) $idShop);
        $disponible = $cantidad > 0 || Product::isAvailableWhenOutOfStock(StockAvailable::outOfStock((int) $p->id, (int) $idShop));
        $condiciones = array('new' => 'NewCondition', 'used' => 'UsedCondition', 'refurbished' => 'RefurbishedCondition');
        $d['offers'] = array(
            '@type' => 'Offer',
            'url' => $d['url'],
            'price' => number_format((float) Product::getPriceStatic((int) $p->id, true, null, 2), 2, '.', ''),
            'priceCurrency' => (string) $ctx->currency->iso_code,
            'availability' => 'https://schema.org/' . ($disponible ? 'InStock' : 'OutOfStock'),
            'itemCondition' => 'https://schema.org/' . (isset($condiciones[(string) $p->condition]) ? $condiciones[(string) $p->condition] : 'NewCondition'),
        );
        return $d;
    }
}
