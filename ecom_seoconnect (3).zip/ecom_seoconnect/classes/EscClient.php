<?php
/**
 * Ecom SEO Connect - llamadas firmadas a la plataforma. SIEMPRE las inicia la tienda.
 * Las respuestas tienen que venir firmadas; si no, no se cree nada de lo que traen.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscClient
{
    /** Valor de configuracion de UNA tienda concreta. */
    public static function cfg($clave, $idShop, $defecto = '')
    {
        $v = Configuration::get($clave, null, null, (int) $idShop);
        return $v === false || $v === null ? $defecto : $v;
    }

    public static function conectado($idShop)
    {
        return self::cfg('ECOMSEOCONNECT_URL', $idShop) !== '' && (int) self::cfg('ECOMSEOCONNECT_SITE_ID', $idShop) > 0 && self::cfg('ECOMSEOCONNECT_SECRET', $idShop) !== '';
    }

    /**
     * Descifra la clave de conexion «SEOIA1.xxxx». Devuelve array(url, id_sitio, secreto) o null.
     */
    public static function leerClave($clave)
    {
        $clave = trim((string) $clave);
        if (strpos($clave, 'SEOIA1.') !== 0) {
            return null;
        }
        $b = strtr(substr($clave, 7), '-_', '+/');
        $j = json_decode((string) base64_decode($b . str_repeat('=', (4 - strlen($b) % 4) % 4), true), true);
        if (!is_array($j) || empty($j['u']) || empty($j['s']) || empty($j['k'])) {
            return null;
        }
        if (!preg_match('#^https?://[^\s]+$#i', $j['u']) || !preg_match('/^[a-f0-9]{64}$/', $j['k'])) {
            return null;
        }
        return array(rtrim($j['u'], '/'), (int) $j['s'], $j['k']);
    }

    /**
     * @return array [ok, datos, error, codigo]
     */
    public static function llamar($idShop, $accion, array $datos, $timeout = 30)
    {
        if (!self::conectado($idShop)) {
            return array(false, array(), 'no_conectado', 0);
        }
        if (!function_exists('curl_init')) {
            return array(false, array(), 'sin_curl', 0);
        }
        $ruta = '/api/v1/' . $accion;
        $url = rtrim(self::cfg('ECOMSEOCONNECT_URL', $idShop), '/') . $ruta;
        $idSitio = (int) self::cfg('ECOMSEOCONNECT_SITE_ID', $idShop);
        $secreto = (string) self::cfg('ECOMSEOCONNECT_SECRET', $idShop);
        $cuerpo = json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
        $cabResp = array();
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $cuerpo,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => (int) $timeout,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'EcomSeoConnect/' . Ecom_Seoconnect::VERSION . ' PrestaShop/' . _PS_VERSION_,
            CURLOPT_HTTPHEADER => array_merge(array('Content-Type: application/json', 'Accept: application/json', 'Expect:'), EscSigner::cabeceras($idSitio, $secreto, $ruta, $cuerpo)),
            CURLOPT_HEADERFUNCTION => function ($c, $linea) use (&$cabResp) {
                $p = strpos($linea, ':');
                if ($p !== false) {
                    $cabResp[strtolower(trim(substr($linea, 0, $p)))] = trim(substr($linea, $p + 1));
                }
                return strlen($linea);
            },
        ));
        $resp = curl_exec($ch);
        $codigo = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = $resp === false ? curl_error($ch) : '';
        if (PHP_VERSION_ID < 80000) {
            curl_close($ch);
        }
        if ($resp === false) {
            EscLog::error('Plataforma ' . $accion . ': ' . $err);
            return array(false, array(), 'red: ' . $err, 0);
        }
        $d = json_decode((string) $resp, true);
        $d = is_array($d) ? $d : array();
        if ($codigo === 401 || $codigo === 429) {
            $motivo = isset($d['motivo']) ? $d['motivo'] : (isset($d['error']) ? $d['error'] : 'http_' . $codigo);
            EscLog::error('Plataforma ' . $accion . ' rechazada: ' . $motivo);
            return array(false, $d, (string) $motivo, $codigo);
        }
        $firmada = EscSigner::valida($secreto, $idSitio, $ruta, (string) $resp,
            isset($cabResp['x-seo-site']) ? $cabResp['x-seo-site'] : '',
            isset($cabResp['x-seo-ts']) ? $cabResp['x-seo-ts'] : '',
            isset($cabResp['x-seo-nonce']) ? $cabResp['x-seo-nonce'] : '',
            isset($cabResp['x-seo-sign']) ? $cabResp['x-seo-sign'] : '');
        if (!$firmada) {
            EscLog::error('Respuesta de ' . $accion . ' SIN firma válida (HTTP ' . $codigo . '): se ignora');
            return array(false, array(), 'respuesta_sin_firma', $codigo);
        }
        EscLog::escribir('Plataforma ' . $accion . ' -> ' . $codigo);
        return array($codigo >= 200 && $codigo < 300 && !empty($d['ok']), $d, isset($d['error']) ? (string) $d['error'] : '', $codigo);
    }
}
