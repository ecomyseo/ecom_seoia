<?php
/**
 * Ecom SEO Connect - lee el catalogo de UNA tienda con SQL directo (sin cargar ObjectModel por
 * producto) y lo prepara para la plataforma. Solo lectura.
 *
 * @author    Ecom Experts <ecomyseo@gmail.com>
 * @copyright 2026 Ecom Experts
 * @license   AFL-3.0
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class EscCatalog
{
    /** @var int */
    private $idShop;
    /** @var array id_lang => iso */
    private $idiomas;
    /** @var Link */
    private $link;
    /** @var int */
    private $idLangDef;

    public function __construct($idShop)
    {
        $this->idShop = (int) $idShop;
        $this->idiomas = array();
        foreach (Language::getLanguages(true, $this->idShop) as $l) {
            $this->idiomas[(int) $l['id_lang']] = Tools::strtolower($l['iso_code']);
        }
        $this->idLangDef = (int) Configuration::get('PS_LANG_DEFAULT', null, null, $this->idShop);
        $this->link = new Link();
    }

    public function idiomas()
    {
        return $this->idiomas;
    }

    public static function tipos()
    {
        return array('categoria', 'marca', 'cms', 'producto');
    }

    public function total($tipo)
    {
        $db = Db::getInstance();
        $s = (int) $this->idShop;
        switch ($tipo) {
            case 'producto':
                return (int) $db->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'product_shop` WHERE `id_shop` = ' . $s);
            case 'categoria':
                return (int) $db->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'category_shop` cs INNER JOIN `' . _DB_PREFIX_ . 'category` c ON c.`id_category` = cs.`id_category` WHERE cs.`id_shop` = ' . $s . ' AND c.`id_parent` > 0');
            case 'marca':
                return (int) $db->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'manufacturer_shop` WHERE `id_shop` = ' . $s);
            case 'cms':
                return (int) $db->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'cms_shop` WHERE `id_shop` = ' . $s);
        }
        return 0;
    }

    /** Ids a partir del cursor. El cursor avanza por lo LEIDO, no por lo que se manda. */
    public function ids($tipo, $cursor, $limite)
    {
        $s = (int) $this->idShop;
        $c = (int) $cursor;
        $l = (int) $limite;
        switch ($tipo) {
            case 'producto':
                $sql = 'SELECT `id_product` FROM `' . _DB_PREFIX_ . 'product_shop` WHERE `id_shop` = ' . $s . ' AND `id_product` > ' . $c . ' ORDER BY `id_product` ASC LIMIT ' . $l;
                break;
            case 'categoria':
                $sql = 'SELECT cs.`id_category` FROM `' . _DB_PREFIX_ . 'category_shop` cs INNER JOIN `' . _DB_PREFIX_ . 'category` c ON c.`id_category` = cs.`id_category`
                    WHERE cs.`id_shop` = ' . $s . ' AND c.`id_parent` > 0 AND cs.`id_category` > ' . $c . ' ORDER BY cs.`id_category` ASC LIMIT ' . $l;
                break;
            case 'marca':
                $sql = 'SELECT `id_manufacturer` FROM `' . _DB_PREFIX_ . 'manufacturer_shop` WHERE `id_shop` = ' . $s . ' AND `id_manufacturer` > ' . $c . ' ORDER BY `id_manufacturer` ASC LIMIT ' . $l;
                break;
            default:
                $sql = 'SELECT `id_cms` FROM `' . _DB_PREFIX_ . 'cms_shop` WHERE `id_shop` = ' . $s . ' AND `id_cms` > ' . $c . ' ORDER BY `id_cms` ASC LIMIT ' . $l;
        }
        $filas = Db::getInstance()->executeS($sql);
        $out = array();
        foreach (is_array($filas) ? $filas : array() as $f) {
            $out[] = (int) reset($f);
        }
        return $out;
    }

    /** Un elemento listo para la plataforma, o null si ya no existe en esta tienda. */
    public function elemento($tipo, $id)
    {
        switch ($tipo) {
            case 'producto':
                return $this->producto((int) $id);
            case 'categoria':
                return $this->categoria((int) $id);
            case 'marca':
                return $this->marca((int) $id);
            case 'cms':
                return $this->cms((int) $id);
        }
        return null;
    }

    private function lang($tabla, $col, $id, $cols, $porTienda = true)
    {
        $filas = Db::getInstance()->executeS('SELECT `id_lang`, ' . $cols . ' FROM `' . _DB_PREFIX_ . $tabla . '` WHERE `' . $col . '` = ' . (int) $id
            . ($porTienda ? ' AND `id_shop` = ' . (int) $this->idShop : ''));
        $out = array();
        foreach (is_array($filas) ? $filas : array() as $f) {
            if (isset($this->idiomas[(int) $f['id_lang']])) {
                $out[(int) $f['id_lang']] = $f;
            }
        }
        return $out;
    }

    private function url($callback)
    {
        try {
            return (string) call_user_func($callback);
        } catch (Exception $e) {
            return '';
        }
    }

    private function producto($id)
    {
        $db = Db::getInstance();
        $p = $db->getRow('SELECT p.`id_product`, p.`reference`, p.`ean13`, p.`upc`, p.`isbn`, p.`mpn`, p.`id_manufacturer`, ps.`active`, ps.`price`, ps.`visibility`,
            ps.`redirect_type`, ps.`id_type_redirected`, ps.`id_category_default`, ps.`condition`, p.`weight`
            FROM `' . _DB_PREFIX_ . 'product` p INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON ps.`id_product` = p.`id_product` AND ps.`id_shop` = ' . (int) $this->idShop . '
            WHERE p.`id_product` = ' . (int) $id);
        if (!$p) {
            return null;
        }
        $marca = $p['id_manufacturer'] ? (string) $db->getValue('SELECT `name` FROM `' . _DB_PREFIX_ . 'manufacturer` WHERE `id_manufacturer` = ' . (int) $p['id_manufacturer']) : '';
        $cat = (string) $db->getValue('SELECT `name` FROM `' . _DB_PREFIX_ . 'category_lang` WHERE `id_category` = ' . (int) $p['id_category_default'] . ' AND `id_lang` = ' . (int) $this->idLangDef . ' AND `id_shop` = ' . (int) $this->idShop);
        $imagenes = $db->executeS('SELECT i.`id_image` FROM `' . _DB_PREFIX_ . 'image` i INNER JOIN `' . _DB_PREFIX_ . 'image_shop` ims ON ims.`id_image` = i.`id_image` AND ims.`id_shop` = ' . (int) $this->idShop . '
            WHERE i.`id_product` = ' . (int) $id . ' ORDER BY i.`position` ASC');
        $imagenes = is_array($imagenes) ? $imagenes : array();
        $caract = $db->executeS('SELECT fl.`name`, fvl.`value` FROM `' . _DB_PREFIX_ . 'feature_product` fp
            INNER JOIN `' . _DB_PREFIX_ . 'feature_lang` fl ON fl.`id_feature` = fp.`id_feature` AND fl.`id_lang` = ' . (int) $this->idLangDef . '
            INNER JOIN `' . _DB_PREFIX_ . 'feature_value_lang` fvl ON fvl.`id_feature_value` = fp.`id_feature_value` AND fvl.`id_lang` = ' . (int) $this->idLangDef . '
            WHERE fp.`id_product` = ' . (int) $id . ' LIMIT 30');
        $caractTxt = array();
        foreach (is_array($caract) ? $caract : array() as $c) {
            $caractTxt[] = $c['name'] . ': ' . $c['value'];
        }
        $stock = (int) StockAvailable::getQuantityAvailableByProduct((int) $id, 0, (int) $this->idShop);
        $pedirSinStock = (bool) Product::isAvailableWhenOutOfStock(StockAvailable::outOfStock((int) $id, (int) $this->idShop));
        $comun = array(
            'marca' => $marca,
            'categoria' => $cat,
            'referencia' => (string) $p['reference'],
            'ean13' => (string) $p['ean13'],
            'upc' => (string) $p['upc'],
            'isbn' => isset($p['isbn']) ? (string) $p['isbn'] : '',
            'mpn' => isset($p['mpn']) ? (string) $p['mpn'] : '',
            'precio' => round((float) $p['price'], 2),
            'stock' => $stock,
            'pedir_sin_stock' => $pedirSinStock,
            'visibilidad' => (string) $p['visibility'],
            'redirect_type' => (string) $p['redirect_type'],
            'id_type_redirected' => (int) $p['id_type_redirected'],
            'id_categoria' => (int) $p['id_category_default'],
            'condicion' => (string) $p['condition'],
            'peso' => (float) $p['weight'] > 0 ? (float) $p['weight'] : '',
            'imagenes' => count($imagenes),
            'caracteristicas' => count($caractTxt),
            'caracteristicas_texto' => implode('; ', $caractTxt),
        );
        $idiomas = array();
        foreach ($this->lang('product_lang', 'id_product', $id, '`name`, `description`, `description_short`, `link_rewrite`, `meta_title`, `meta_description`') as $idLang => $f) {
            $iso = $this->idiomas[$idLang];
            $ley = array();
            foreach ($imagenes as $im) {
                $v = $db->getValue('SELECT `legend` FROM `' . _DB_PREFIX_ . 'image_lang` WHERE `id_image` = ' . (int) $im['id_image'] . ' AND `id_lang` = ' . (int) $idLang);
                $ley[(string) (int) $im['id_image']] = $v === false ? '' : (string) $v;
            }
            $idiomas[$iso] = array(
                'name' => (string) $f['name'],
                'meta_title' => (string) $f['meta_title'],
                'meta_description' => (string) $f['meta_description'],
                'description_short' => (string) $f['description_short'],
                'description' => (string) $f['description'],
                'link_rewrite' => (string) $f['link_rewrite'],
                'tags' => EscFields::etiquetas($id, $idLang),
                'leyendas' => $ley,
                'url' => $this->url(function () use ($id, $idLang) {
                    return $this->link->getProductLink((int) $id, null, null, null, (int) $idLang, (int) $this->idShop);
                }),
            );
        }
        return array('tipo' => 'producto', 'id' => (int) $id, 'activo' => (int) $p['active'], 'comun' => $comun, 'idiomas' => $idiomas);
    }

    private function categoria($id)
    {
        $db = Db::getInstance();
        $c = $db->getRow('SELECT c.`id_category`, c.`active`, c.`is_root_category`, c.`id_parent` FROM `' . _DB_PREFIX_ . 'category` c
            INNER JOIN `' . _DB_PREFIX_ . 'category_shop` cs ON cs.`id_category` = c.`id_category` AND cs.`id_shop` = ' . (int) $this->idShop . ' WHERE c.`id_category` = ' . (int) $id);
        if (!$c || (int) $c['id_parent'] === 0) {
            return null;
        }
        $productos = (int) $db->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'category_product` cp INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON ps.`id_product` = cp.`id_product`
            AND ps.`id_shop` = ' . (int) $this->idShop . ' AND ps.`active` = 1 WHERE cp.`id_category` = ' . (int) $id);
        $idiomas = array();
        $ejemplos = $db->executeS('SELECT pl.`id_lang`, pl.`name` FROM `' . _DB_PREFIX_ . 'category_product` cp INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl
            ON pl.`id_product` = cp.`id_product` AND pl.`id_shop` = ' . (int) $this->idShop . ' WHERE cp.`id_category` = ' . (int) $id . ' ORDER BY cp.`position` LIMIT 60');
        $porIdioma = array();
        foreach (is_array($ejemplos) ? $ejemplos : array() as $e) {
            if (!isset($porIdioma[(int) $e['id_lang']]) || count($porIdioma[(int) $e['id_lang']]) < 10) {
                $porIdioma[(int) $e['id_lang']][] = $e['name'];
            }
        }
        foreach ($this->lang('category_lang', 'id_category', $id, '`name`, `description`, `link_rewrite`, `meta_title`, `meta_description`') as $idLang => $f) {
            $idiomas[$this->idiomas[$idLang]] = array(
                'name' => (string) $f['name'],
                'meta_title' => (string) $f['meta_title'],
                'meta_description' => (string) $f['meta_description'],
                'description' => (string) $f['description'],
                'link_rewrite' => (string) $f['link_rewrite'],
                'productos_ejemplo' => isset($porIdioma[$idLang]) ? $porIdioma[$idLang] : array(),
                'url' => $this->url(function () use ($id, $idLang) {
                    return $this->link->getCategoryLink((int) $id, null, (int) $idLang, null, (int) $this->idShop);
                }),
            );
        }
        return array('tipo' => 'categoria', 'id' => (int) $id, 'activo' => (int) $c['active'], 'comun' => array('productos' => $productos, 'es_raiz' => (int) $c['is_root_category'], 'id_padre' => (int) $c['id_parent']), 'idiomas' => $idiomas);
    }

    private function marca($id)
    {
        $db = Db::getInstance();
        $m = $db->getRow('SELECT m.`id_manufacturer`, m.`name`, m.`active` FROM `' . _DB_PREFIX_ . 'manufacturer` m INNER JOIN `' . _DB_PREFIX_ . 'manufacturer_shop` ms
            ON ms.`id_manufacturer` = m.`id_manufacturer` AND ms.`id_shop` = ' . (int) $this->idShop . ' WHERE m.`id_manufacturer` = ' . (int) $id);
        if (!$m) {
            return null;
        }
        $productos = (int) $db->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'product` p INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON ps.`id_product` = p.`id_product`
            AND ps.`id_shop` = ' . (int) $this->idShop . ' AND ps.`active` = 1 WHERE p.`id_manufacturer` = ' . (int) $id);
        $idiomas = array();
        foreach ($this->lang('manufacturer_lang', 'id_manufacturer', $id, '`description`, `short_description`, `meta_title`, `meta_description`', false) as $idLang => $f) {
            $idiomas[$this->idiomas[$idLang]] = array(
                'name' => (string) $m['name'],
                'meta_title' => (string) $f['meta_title'],
                'meta_description' => (string) $f['meta_description'],
                'short_description' => (string) $f['short_description'],
                'description' => (string) $f['description'],
                'url' => $this->url(function () use ($id, $idLang) {
                    return $this->link->getManufacturerLink((int) $id, null, (int) $idLang, (int) $this->idShop);
                }),
            );
        }
        return array('tipo' => 'marca', 'id' => (int) $id, 'activo' => (int) $m['active'], 'comun' => array('productos' => $productos), 'idiomas' => $idiomas);
    }

    private function cms($id)
    {
        $db = Db::getInstance();
        $c = $db->getRow('SELECT c.`id_cms`, c.`active`, c.`indexation` FROM `' . _DB_PREFIX_ . 'cms` c INNER JOIN `' . _DB_PREFIX_ . 'cms_shop` cs
            ON cs.`id_cms` = c.`id_cms` AND cs.`id_shop` = ' . (int) $this->idShop . ' WHERE c.`id_cms` = ' . (int) $id);
        if (!$c) {
            return null;
        }
        $idiomas = array();
        foreach ($this->lang('cms_lang', 'id_cms', $id, '`meta_title`, `meta_description`, `content`, `link_rewrite`') as $idLang => $f) {
            $idiomas[$this->idiomas[$idLang]] = array(
                'name' => (string) $f['meta_title'],
                'meta_title' => (string) $f['meta_title'],
                'meta_description' => (string) $f['meta_description'],
                'content' => (string) $f['content'],
                'link_rewrite' => (string) $f['link_rewrite'],
                'url' => $this->url(function () use ($id, $idLang) {
                    return $this->link->getCMSLink((int) $id, null, null, (int) $idLang, (int) $this->idShop);
                }),
            );
        }
        return array('tipo' => 'cms', 'id' => (int) $id, 'activo' => (int) $c['active'], 'comun' => array('indexar' => (int) $c['indexation']), 'idiomas' => $idiomas);
    }

    /** Lo que la plataforma necesita saber de la tienda para las reglas «de tienda». */
    public function configTienda()
    {
        $s = $this->idShop;
        $raiz = defined('_PS_ROOT_DIR_') ? _PS_ROOT_DIR_ : dirname(_PS_MODULE_DIR_);
        $mapas = glob($raiz . '/*sitemap*.xml');
        $tema = EscFront::tema($s);
        $robots = EscFront::robots();
        return array(
            'friendly_url' => (int) Configuration::get('PS_REWRITING_SETTINGS', null, null, $s) === 1,
            'ssl_everywhere' => (int) Configuration::get('PS_SSL_ENABLED_EVERYWHERE', null, null, $s) === 1 || (int) Configuration::get('PS_SSL_ENABLED', null, null, $s) === 1,
            'canonical_redirect' => (int) Configuration::get('PS_CANONICAL_REDIRECT', null, null, $s),
            'shop_enabled' => (int) Configuration::get('PS_SHOP_ENABLE', null, null, $s) === 1,
            'sitemap' => Module::isEnabled('gsitemap') || (is_array($mapas) && count($mapas) > 0),
            'robots' => is_file($raiz . '/robots.txt'),
            'llms' => is_file($raiz . '/llms.txt'),
            'smarty_cache' => (int) Configuration::get('PS_SMARTY_CACHE', null, null, $s) === 1,
            'idioma_defecto' => isset($this->idiomas[$this->idLangDef]) ? $this->idiomas[$this->idLangDef] : '',
            'redirect_defecto' => (string) Configuration::get('PS_PRODUCT_REDIRECTION_DEFAULT', null, null, $s) ?: '404',
            'url_producto_segura' => EscFields::urlSegura('producto', $s),
            'url_categoria_segura' => EscFields::urlSegura('categoria', $s),
            'indexnow' => (int) EscClient::cfg('ECOMSEOCONNECT_INDEXNOW', $s, 0) === 1,
            'nombre_tienda' => (string) Configuration::get('PS_SHOP_NAME', null, null, $s),
            // Especificaciones 007, 008 y 012: lo que trae el tema, lo que publica el modulo y el robots.txt.
            'hreflang_tema' => $tema['hreflang'],
            'xdefault' => $tema['xdefault'] || (int) EscClient::cfg('ECOMSEOCONNECT_XDEFAULT', $s, 0) === 1,
            'jsonld_tema' => $tema['tipos'],
            'jsonld_producto' => in_array('Product', $tema['tipos'], true) || (int) EscClient::cfg('ECOMSEOCONNECT_JSONLD_PRODUCTO', $s, 0) === 1,
            'robots_bloquea_todo' => $robots['bloquea'],
            'robots_sitemap' => $robots['sitemap'],
        );
    }
}
